// ==================================================
// MICHAEL'S FOUNDATIONS
// Russian Foundations
// Greetings & Introductions — REMAKE
// ==================================================

console.log("Greetings & Introductions REMAKE connected!");


// ==================================================
// TEXT NORMALIZATION
// ==================================================

const normalize = (s) =>
    (s || "")
        .toLowerCase()
        .replace(/[.,!?;:«»"']/g, "")
        .replace(/\s+/g, " ")
        .trim();


// ==================================================
// RUSSIAN AUDIO — LISTEN BUTTONS
// ==================================================

function speakRussian(text) {

    if (!("speechSynthesis" in window)) {
        return;
    }

    speechSynthesis.cancel();

    const u = new SpeechSynthesisUtterance(text);

    u.lang = "ru-RU";
    u.rate = 0.86;

    const voices = speechSynthesis.getVoices();

    const ru = voices.find(
        (v) =>
            v.lang &&
            v.lang.toLowerCase().startsWith("ru")
    );

    if (ru) {
        u.voice = ru;
    }

    speechSynthesis.speak(u);
}


// Any button with class="listen" uses its data-speak value.
document.addEventListener("click", (e) => {

    const b = e.target.closest(".listen");

    if (b) {
        speakRussian(b.dataset.speak);
    }

});


// ==================================================
// SPEAKING PRACTICE — SAY IT BUTTONS
// ==================================================

const SR =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

document.querySelectorAll(".say").forEach((btn) => {

    btn.addEventListener("click", () => {

        const originalButtonText = btn.textContent.trim();

        const container =
            btn.closest(".phrase-card") ||
            btn.parentElement;

        const heardBox =
            container?.querySelector(".speech-heard");

        const fb =
            container?.querySelector(".speech-feedback");

        if (!SR) {

            if (fb) {
                fb.textContent =
                    "Speaking practice is not available in this browser.";

                fb.className =
                    "speech-feedback bad";
            }

            return;
        }

        const r = new SR();

        r.lang = "ru-RU";
        r.interimResults = false;
        r.maxAlternatives = 3;

        btn.disabled = true;
        btn.textContent = "🎙️ Listening…";

        r.onresult = (ev) => {
            console.log("SAY IT RESULT:", ev.results[0][0].transcript);

            const heard =
                [...ev.results[0]].map(
                    (x) => x.transcript
                );

            const target =
                normalize(btn.dataset.target);

            const isPersonalName =
                target === normalize("Меня зовут");

            const ok =
                heard.some((x) => {

                    const recognized =
                        normalize(x);

                    if (isPersonalName) {
                        return recognized.includes(
                            normalize("Меня зовут")
                        );
                    }

                    return (
                        recognized.includes(target) ||
                        target.includes(recognized)
                    );

                });

            if (heardBox) {
                heardBox.textContent =
                    `I heard: ${heard[0]}`;
            }

            if (fb) {
                fb.textContent =
                    ok
                        ? "Well done!"
                        : "Not quite — listen and try again.";

                fb.className =
                    "speech-feedback " +
                    (ok ? "good" : "bad");
            }

        };

        r.onerror = (event) => {
            console.log("SAY IT ERROR:", event.error);

            if (fb) {

                fb.textContent =
                    "I couldn't hear that clearly. Check microphone permission and try again.";

                fb.className =
                    "speech-feedback bad";
            }

        };

        r.onend = () => {

            btn.disabled = false;

            btn.textContent = originalButtonText;

        };

        try {
            r.start();
        } catch { }

    });

});


// ==================================================
// CHOICE ACTIVITIES
// ==================================================

document.querySelectorAll(".choice-set").forEach((set) => {

    set.querySelectorAll("button").forEach((btn) => {

        btn.addEventListener("click", () => {

            set.querySelectorAll("button").forEach((x) => {
                x.classList.remove("selected");
            });

            btn.classList.add("selected");


            const fb =
                set.nextElementSibling;

            const ok =
                normalize(btn.textContent) ===
                normalize(set.dataset.answer);


            fb.textContent =
                ok
                    ? "Well done! That fits the situation."
                    : "Not quite. Think about what the situation is asking for.";

            fb.className =
                "feedback " +
                (ok ? "good" : "bad");

        });

    });

});


// ==================================================
// WORD BUILDERS
// ==================================================

document.querySelectorAll(".builder").forEach((builder) => {

    const answer =
        builder.querySelector(".builder__answer");

    const buttons =
        builder.querySelectorAll(".word-bank button");

    const selectedWords = [];

    const nameInput =
        builder.querySelector(".name-input");

    buttons.forEach((btn) => {

        btn.addEventListener("click", () => {

            const word =
                btn.textContent.trim();

            if (btn.classList.contains("selected")) {

                btn.classList.remove("selected");

                const wordIndex =
                    selectedWords.indexOf(word);

                if (wordIndex !== -1) {
                    selectedWords.splice(wordIndex, 1);
                }

            } else {

                btn.classList.add("selected");

                selectedWords.push(word);
            }

            const typedName =
                nameInput ? nameInput.value.trim() : "";

            answer.textContent =
                [selectedWords.join(" "), typedName]
                    .filter(Boolean)
                    .join(" ");

        });

    });

    if (nameInput) {

        nameInput.addEventListener("input", () => {

            const typedName =
                nameInput.value.trim();

            answer.textContent =
                [selectedWords.join(" "), typedName]
                    .filter(Boolean)
                    .join(" ");

        });

    }


    builder
        .querySelector(".check-builder")
        .addEventListener("click", () => {

            const fb =
                builder.querySelector(".feedback");

            const ok =
                builder.classList.contains("name-builder")
                    ? (
                        normalize(selectedWords.join(" ")) ===
                        normalize(builder.dataset.answer) &&
                        nameInput.value.trim() !== ""
                    )
                    : (
                        normalize(answer.textContent) ===
                        normalize(builder.dataset.answer)
                    );


            fb.textContent =
                ok
                    ? (
                        builder.classList.contains("name-builder")
                            ? "Excellent. Now add your own first name."
                            : "Excellent — you built it correctly."
                    )
                    : "Not quite. Look at the relationship and word order, then try again.";

            fb.className =
                "feedback " +
                (ok ? "good" : "bad");

        });

});


// ==================================================
// CONVERSATION BUILDERS
// ==================================================

document
    .querySelectorAll(".conversation-builder")
    .forEach((box) => {

        let active = null;

        const blanks =
            [...box.querySelectorAll(".blank")];

        const phrases =
            [...box.querySelectorAll(".phrase-bank button")];


        blanks.forEach((b) => {

            b.addEventListener("click", () => {

                active = b;

                blanks.forEach((x) => {
                    x.classList.remove("selected");
                });

                b.classList.add("selected");

            });

        });


        phrases.forEach((p) => {

            p.addEventListener("click", () => {

                if (!active) {

                    active =
                        blanks.find(
                            (b) =>
                                b.textContent.includes("_")
                        ) ||
                        blanks[0];

                }


                active.textContent =
                    p.textContent;

                active.classList.remove("selected");

                active = null;

            });

        });


        box
            .querySelector(".check-conversation")
            .addEventListener("click", () => {

                const expected =
                    box.dataset.answers
                        .split("|")
                        .map(normalize);

                const actual =
                    blanks.map(
                        (b) =>
                            normalize(b.textContent)
                    );

                const ok =
                    expected.every(
                        (x, i) =>
                            x === actual[i]
                    );

                const fb =
                    box.querySelector(".feedback");


                fb.textContent =
                    ok
                        ? "Excellent! The conversation fits together naturally."
                        : "Not quite. Check which phrase belongs in each turn.";

                fb.className =
                    "feedback " +
                    (ok ? "good" : "bad");

            });

    });


// ==================================================
// PRACTICE — CYRILLIC KEYBOARD
// ==================================================

// Define the Russian keyboard in three familiar Cyrillic rows.
const cyrillicRows = [
    ["Й", "Ц", "У", "К", "Е", "Н", "Г", "Ш", "Щ", "З", "Х", "Ъ"],
    ["Ф", "Ы", "В", "А", "П", "Р", "О", "Л", "Д", "Ж", "Э"],
    ["Я", "Ч", "С", "М", "И", "Т", "Ь", "Б", "Ю", "Ё"]
];

// Keep a flat copy of the letters for the current keyboard code.
const keys =
    cyrillicRows.flat();

document
    .querySelectorAll(".russian-keyboard")
    .forEach((kb) => {

        let target = null;

        document
            .querySelectorAll("input")
            .forEach((i) => {

                i.addEventListener("focus", () => {
                    target = i;
                });

            });

        // Build the three visible Cyrillic keyboard rows.
        cyrillicRows.forEach((row) => {

            const rowElement =
                document.createElement("div");

            rowElement.classList.add(
                "cyrillic-keyboard__row"
            );

            row.forEach((letter) => {

                const keyButton =
                    document.createElement("button");

                keyButton.type = "button";

                keyButton.classList.add(
                    "cyrillic-keyboard__key"
                );

                keyButton.textContent = letter;

                keyButton.addEventListener("mousedown", (e) => {
                    e.preventDefault();
                });

                keyButton.addEventListener("click", () => {

                    if (!target) {
                        return;
                    }

                    target.value +=
                        letter.toLowerCase();

                    target.focus();

                });

                rowElement.appendChild(keyButton);

            });

            kb.appendChild(rowElement);

        });

        // Build a separate keyboard-controls row.
        const controlsRow =
            document.createElement("div");

        controlsRow.classList.add(
            "cyrillic-keyboard__controls"
        );

        ["Back", "SPACE", "Clear"].forEach((label) => {

            const controlButton =
                document.createElement("button");

            controlButton.type = "button";

            controlButton.classList.add(
                "cyrillic-keyboard__control"
            );

            controlButton.textContent = label;

            // Same focus-protection the individual letter
            // keys already have above — without this, clicking
            // Back/SPACE/Clear blurs the input a moment before
            // the click itself runs, which can fire an input's
            // own blur-triggered checker too early.
            controlButton.addEventListener("mousedown", (e) => {
                e.preventDefault();
            });

            controlButton.addEventListener("click", () => {

                if (!target) {
                    return;
                }


                if (label === "SPACE") {

                    target.value += " ";

                } else if (label === "Back") {

                    target.value =
                        target.value.slice(0, -1);

                } else if (label === "Clear") {

                    target.value = "";

                }

                target.focus();

            });

            controlsRow.appendChild(controlButton);

        });


        kb.appendChild(controlsRow);

    });


// ==================================================
// PRACTICE ACTIVITY 1 — TYPE WHAT YOU KNOW
// Per-item checking: each row checks itself on
// blur or Enter. No batch "Check" button.
// ==================================================

document
    .querySelectorAll(".practice1-input")
    .forEach((input) => {

        const row =
            input.closest(".practice1-row");

        const fb =
            row?.querySelector(
                ".memory-response__feedback"
            );

        function checkRow() {

            if (!fb) {
                return;
            }

            if (!input.value.trim()) {

                fb.textContent = "";

                fb.classList.remove(
                    "memory-response__feedback--success",
                    "memory-response__feedback--try-again"
                );

                return;
            }

            const ok =
                normalize(input.value) ===
                normalize(input.dataset.answer);

            fb.textContent =
                ok
                    ? "Excellent! You remembered it."
                    : "Not quite — try again, or press Listen to hear it.";

            fb.classList.toggle(
                "memory-response__feedback--success",
                ok
            );

            fb.classList.toggle(
                "memory-response__feedback--try-again",
                !ok
            );

        }

        input.addEventListener("blur", checkRow);

        input.addEventListener("keydown", (e) => {

            if (e.key === "Enter") {

                e.preventDefault();
                checkRow();

            }

        });

    });


// ==================================================
// PRACTICE ACTIVITY 3 — ESCALATING SAY-IT FEEDBACK
// The shared .say handler above (used by Build too)
// always shows the same "Not quite" message. Activity
// 3's Outline calls for a different message on the
// 2nd+ miss. Rather than change that shared handler —
// which would also change Build's already-approved
// wording — this watches each row's own feedback text
// and swaps the wording in afterward, only inside
// Activity 3. Build is never touched.
// ==================================================

document
    .querySelectorAll("#practice-3 .say")
    .forEach((btn) => {

        const container =
            btn.closest(".phrase-card") ||
            btn.parentElement;

        const fb =
            container?.querySelector(".speech-feedback");

        if (!fb) {
            return;
        }

        let missCount = 0;

        const watchFeedback = new MutationObserver(() => {

            if (fb.classList.contains("good")) {

                missCount = 0;
                return;
            }

            if (fb.classList.contains("bad")) {

                missCount++;

                fb.textContent =
                    missCount === 1
                        ? "Not quite — try again."
                        : "Still not quite — press Listen and try repeating it.";

            }

        });

        watchFeedback.observe(fb, {
            attributes: true,
            attributeFilter: ["class"],
            childList: true
        });

    });


// ==================================================
// PRACTICE — MATCH WHAT YOU KNOW
// ==================================================

const pairs = [
    ["Это мой брат.", "This is my brother."],
    ["Это моя сестра.", "This is my sister."],
    ["Это моя мама и мой папа.", "This is my mom and my dad."],
    ["Это не мой брат, но это моя сестра.", "That's not my brother, but that's my sister."],
    ["Это мои родители.", "These are my parents."],
    ["Это моё имя.", "This is my name."],
    ["Это моя мать.", "This is my mother."],
    ["Это мой отец.", "This is my father."],
    ["Это моя семья.", "This is my family."]
];


const ru =
    document.querySelector(".match-col.russian");

const en =
    document.querySelector(".match-col.english");

let selected = null;
let matched = 0;


function shuffle(a) {

    return [...a].sort(
        () =>
            Math.random() - 0.5
    );

}


function buildMatch() {

    if (!ru) {
        return;
    }


    ru.innerHTML = "";
    en.innerHTML = "";

    selected = null;
    matched = 0;


    shuffle(pairs).forEach(([r]) => {

        // Each Russian card is now a phrase button plus its
        // own always-on Listen button, wrapped together so
        // the two can sit side by side.
        const item =
            document.createElement("div");

        item.className = "match-item";

        const b =
            document.createElement("button");

        b.type = "button";
        b.textContent = r;
        b.dataset.key = r;


        b.onclick = () => {

            if (
                b.classList.contains("matched")
            ) {
                return;
            }


            ru
                .querySelectorAll(".active")
                .forEach((x) => {

                    x.classList.remove("active");

                });


            b.classList.add("active");
            selected = b;

        };

        const listenButton =
            document.createElement("button");

        listenButton.type = "button";
        listenButton.className = "listen";
        listenButton.dataset.speak = r;
        listenButton.textContent = "🔊";

        item.append(b, listenButton);

        ru.appendChild(item);

    });


    shuffle(pairs).forEach(([r, e]) => {

        const b =
            document.createElement("button");

        b.textContent = e;
        b.dataset.key = r;


        b.onclick = () => {

            if (
                !selected ||
                b.classList.contains("matched")
            ) {
                return;
            }


            const fb =
                document.querySelector(
                    "#practice-2 .feedback"
                );


            if (
                selected.dataset.key ===
                b.dataset.key
            ) {

                selected.classList.add("matched");
                b.classList.add("matched");

                selected.classList.remove("active");

                selected = null;
                matched++;


                fb.textContent =
                    matched === pairs.length
                        ? "Excellent — every pair is matched!"
                        : "Correct match.";

                fb.className =
                    "feedback good";

            } else {

                fb.textContent =
                    "Not quite — try another meaning.";

                fb.className =
                    "feedback bad";

            }

        };


        en.appendChild(b);

    });

}


buildMatch();


document
    .querySelector(".reset-match")
    ?.addEventListener("click", () => {

        // Rebuild and reshuffle the matching activity.
        buildMatch();

        // Clear feedback from the previous attempt.
        const feedback =
            document.querySelector("#practice-2 .feedback");

        if (feedback) {
            feedback.textContent = "";
            feedback.className = "feedback";
        }

    });


// ==================================================
// JOURNEY RAIL — PROGRESS COUNTS
// ==================================================

function updateProgress() {

    const lessons =
        [
            ...document.querySelectorAll(
                ".lesson-complete"
            )
        ].filter(
            (x) => x.checked
        ).length;


    const practice =
        [
            ...document.querySelectorAll(
                ".practice-complete"
            )
        ].filter(
            (x) => x.checked
        ).length;


    const passes =
        [
            ...document.querySelectorAll(
                ".pass-complete"
            )
        ].filter(
            (x) => x.checked
        ).length;


    document.querySelector(
        "#lesson-progress-count"
    ).textContent =
        `${lessons}/3`;


    document.querySelector(
        "#practice-progress-count"
    ).textContent =
        `${practice}/3`;


    document.querySelector(
        "#pass-progress-count"
    ).textContent =
        `${passes}/3`;

    // Show or remove Journey Rail completion checkmarks.
    document.querySelectorAll(".lesson-complete").forEach((box) => {

        const link = document.querySelector(
            `.journey-rail a[href="#lesson-${box.dataset.lesson}"]`
        );

        const check = link?.querySelector(".journey-check");

        if (check) {
            check.textContent = box.checked ? "✓" : "";
        }

    });

    document.querySelectorAll(".practice-complete").forEach((box) => {

        const link = document.querySelector(
            `.journey-rail a[href="#practice-${box.dataset.practice}"]`
        );

        const check = link?.querySelector(".journey-check");

        if (check) {
            check.textContent = box.checked ? "✓" : "";
        }

    });

    document.querySelectorAll(".pass-complete").forEach((box) => {

        const link = document.querySelector(
            `.journey-rail a[href="#pass-${box.dataset.pass}"]`
        );

        const check = link?.querySelector(".journey-check");

        if (check) {
            check.textContent = box.checked ? "✓" : "";
        }

    });

    document.querySelectorAll(".variation-complete").forEach((box) => {
        const link = document.querySelector(
            `.journey-rail a[href="#variation-${box.dataset.variation}"]`
        );
        const check = link?.querySelector(".journey-check");
        if (check) {
            check.textContent = box.checked ? "✓" : "";
        }
    });

}

document
    .querySelectorAll(
        ".lesson-complete,.practice-complete,.variation-complete,.pass-complete"
    )
    .forEach((x) => {

        x.addEventListener(
            "change",
            updateProgress
        );

    });

updateProgress();

// ==================================================
// STAGE TABS + JOURNEY RAIL — SCROLL TRACKING
// ==================================================

const banners =
    [
        ...document.querySelectorAll(
            ".phase-banner"
        )
    ];

const tabs =
    [
        ...document.querySelectorAll(
            ".stage-tab"
        )
    ];

const rail =
    [
        ...document.querySelectorAll(
            ".journey-rail__section[data-stage]"
        )
    ];


function setStage(name) {

    tabs.forEach((t) => {

        t.classList.toggle(
            "stage-tab--active",
            t.dataset.stage === name
        );

    });


    rail.forEach((r) => {

        r.classList.toggle(
            "journey-rail__section--current",
            r.dataset.stage === name
        );

    });

}


function track() {

    const point =
        window.innerHeight * 0.35;

    let current =
        "learn";


    banners.forEach((b) => {

        if (
            b.getBoundingClientRect().top <=
            point
        ) {

            current =
                b
                    .closest(".learning-stage")
                    .dataset.stage;

        }

    });


    setStage(current);

}


window.addEventListener(
    "scroll",
    track,
    {
        passive: true
    }
);


track();


// ==================================================
// RIGHT-SIDE STAGE TABS — CLICK NAVIGATION
// ==================================================

tabs.forEach((t) => {

    t.addEventListener("click", () => {

        document
            .querySelector(
                `#${t.dataset.stage}-banner`
            )
            ?.scrollIntoView(
                {
                    behavior: "smooth",
                    block: "start"
                }
            );

    });

});



// ==================================================
// USE — FAMILY TREE PUZZLE — STAGE 1: IMMEDIATE FAMILY
// REVEAL THE EVIDENCE -> SOLVE THE RELATIONSHIP -> PROVE YOU UNDERSTAND THE TREE
// Click-to-fill word bank — no typing, so spelling and Cyrillic input
// are never the obstacle. The reasoning is still the whole exercise.
// ==================================================

(() => {

    const stage =
        document.querySelector("#variation-1");

    if (!stage) {
        return;
    }

    const boxes =
        [...stage.querySelectorAll(".tree-box")];

    const challenge =
        stage.querySelector("#tree-1-challenge");

    const resetButton =
        stage.querySelector("#tree-1-reset");

    const bankRoot =
        stage.querySelector("#tree-1-word-bank");


    function shuffle(arr) {

        for (let i = arr.length - 1; i > 0; i--) {

            const j =
                Math.floor(Math.random() * (i + 1));

            [arr[i], arr[j]] = [arr[j], arr[i]];

        }

        return arr;

    }


    // Every real piece the tree needs, each paired with a distractor that
    // looks right but isn't — either a real Russian word one letter off
    // (мать/мат, брат/брать), or a spelling that breaks an actual rule
    // (младшый instead of младший). Both flavors train close reading,
    // not just recall.
    const PIECES =
        ["отец", "отес", "мать", "мат", "брат", "брать", "сестра", "сестора",
            "старший", "старшый", "младший", "младшый",
            "старшая", "старшыя", "младшая", "младшыя",
            "мой", "моя"];


    // Set once Stage 1's boxes are all solved — while it's non-null, bank
    // clicks route to the Кто это? challenge instead of to a tree box.
    let challengeHandler = null;

    let activeBox = null;


    // A bank click either fills the current target's next open blank
    // (correct), does nothing (the piece is already satisfied there — no
    // penalty for a redundant click), or counts as a wrong attempt.
    function handleBankClick(word) {

        if (challengeHandler) {
            challengeHandler(word);
            return;
        }

        if (!activeBox) {
            return;
        }

        const blanks =
            blanksOf(activeBox);

        const openBlank =
            blanks.find(
                (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (openBlank) {

            openBlank.textContent = word;
            openBlank.classList.add("is-filled");

            if (isBoxSolved(activeBox)) {
                lockBoxSolved(activeBox);
            }

            return;

        }

        const alreadySatisfied =
            blanks.some(
                (b) => b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (alreadySatisfied) {
            return;
        }

        registerWrongAttempt(activeBox);

    }


    // ---- Build the shared word bank (shuffled once per page load) ----

    shuffle([...PIECES]).forEach((word) => {

        const button =
            document.createElement("button");

        button.type = "button";
        button.dataset.value = word;
        button.textContent = word;

        button.addEventListener("click", () => {
            handleBankClick(word);
        });

        bankRoot.appendChild(button);

    });


    function blanksOf(box) {
        return [...box.querySelectorAll(".use-blank")];
    }


    function isBoxSolved(box) {
        return blanksOf(box).every((b) => b.classList.contains("is-filled"));
    }


    // The full tree is visible from the start (every box shows its clue),
    // but only one box at a time accepts clicks. The order is randomized
    // on every load — since all the clues are already on screen, the order
    // solved doesn't change what there is to understand. `order` is `let`,
    // not `const`, because Reset Stage reshuffles a fresh one.
    let order =
        shuffle([...boxes]);

    let current = 0;


    function activateNext() {

        if (current >= order.length) {

            activeBox = null;
            startChallenge();
            return;

        }

        activeBox = order[current];

        activeBox.classList.remove("tree-box--pending");
        activeBox.classList.add("tree-box--active");

    }


    function lockBoxSolved(box) {

        box.classList.remove("tree-box--active");
        box.classList.add("tree-box--solved");

        box.querySelector(".tree-box__help").hidden = true;
        box.querySelector(".feedback").textContent = "";

        current++;
        activateNext();

    }


    function registerWrongAttempt(box) {

        const attempts =
            Number(box.dataset.attempts) + 1;

        box.dataset.attempts = String(attempts);

        const feedback =
            box.querySelector(".feedback");

        feedback.textContent =
            "Not quite — try again.";

        feedback.className =
            "feedback bad";

        if (attempts >= 2) {
            box.querySelector(".tree-box__help").hidden = false;
        }

    }


    boxes.forEach((box) => {

        box.classList.add("tree-box--pending");
        box.dataset.attempts = "0";

        box.querySelector(".tree-box__hint")
            ?.addEventListener("click", () => {

                const feedback =
                    box.querySelector(".feedback");

                feedback.textContent =
                    box.dataset.hint || "";

                feedback.className =
                    "feedback hint";

            });

        box.querySelector(".tree-box__escape")
            ?.addEventListener("click", () => {

                blanksOf(box).forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                lockBoxSolved(box);

            });

    });


    activateNext();


    // Puts this Stage back to exactly how it looked on page load: every
    // box unsolved with a fresh random order, the Кто это? step hidden
    // again, and this Stage's own "done" styling removed. Doesn't touch
    // any other Stage.
    function resetStage() {

        boxes.forEach((box) => {

            box.classList.remove("tree-box--active", "tree-box--solved");
            box.classList.add("tree-box--pending");
            box.dataset.attempts = "0";

            box.querySelector(".tree-box__help").hidden = true;

            const feedback =
                box.querySelector(".feedback");

            feedback.textContent = "";
            feedback.className = "feedback";

            blanksOf(box).forEach((blank) => {
                blank.classList.remove("is-filled");
                blank.textContent = "______";
            });

        });

        stage.classList.remove("tree-stage--done");

        challenge.hidden = true;
        challenge.querySelector("#tree-1-challenge-blanks").innerHTML = "";

        challengeHandler = null;
        activeBox = null;
        current = 0;
        order = shuffle([...boxes]);

        activateNext();

        document.dispatchEvent(
            new CustomEvent("tree-stage-reset", { detail: { stage: 1 } })
        );

    }

    resetButton?.addEventListener("click", resetStage);


    // ==================================================
    // "PROVE YOU UNDERSTAND THE TREE" — Кто это?
    // Runs once, after every box in this Stage is solved.
    // Reuses the same word bank — no typing here either.
    // ==================================================

    // One masculine example and one feminine example, every time — so the
    // learner always practices both мой and моя, instead of leaving it to
    // chance which gender a single random pick would land on. Which one
    // comes first is still randomized.
    function startChallenge() {

        challenge.hidden = false;

        const masculine =
            boxes.filter((b) => b.dataset.possessive === "мой");

        const feminine =
            boxes.filter((b) => b.dataset.possessive === "моя");

        const pickOne =
            (list) => list[Math.floor(Math.random() * list.length)];

        const targets =
            shuffle([pickOne(masculine), pickOne(feminine)]);

        let round = 0;


        function runRound() {

            const target =
                targets[round];

            round++;

            challenge.querySelector("#tree-1-round").textContent =
                `Question ${round} of ${targets.length}`;

            const targetClue =
                target.querySelector(".tree-box__clue").textContent;

            challenge.querySelector("#tree-1-target").textContent =
                `→ ${targetClue}`;

            const possessive =
                target.dataset.possessive;

            const phraseWords =
                blanksOf(target).map((b) => b.dataset.accept);

            const blanksHost =
                challenge.querySelector("#tree-1-challenge-blanks");

            blanksHost.innerHTML = "";

            function makeBlank(accept) {

                const blank =
                    document.createElement("button");

                blank.type = "button";
                blank.className = "use-blank";
                blank.dataset.accept = accept;
                blank.textContent = "______";

                blanksHost.appendChild(blank);

                return blank;

            }

            const possBlank =
                makeBlank(possessive);

            const phraseBlanks =
                phraseWords.map(makeBlank);

            const challengeBlanks =
                [possBlank, ...phraseBlanks];

            const feedback =
                challenge.querySelector(".feedback");

            const help =
                challenge.querySelector(".tree-challenge__help");

            feedback.textContent = "";
            feedback.className = "feedback";
            help.hidden = true;

            let attempts = 0;


            function checkComplete() {

                if (!challengeBlanks.every((b) => b.classList.contains("is-filled"))) {
                    return;
                }

                help.hidden = true;

                if (round < targets.length) {

                    feedback.textContent =
                        "Right! Now the other one.";

                    feedback.className =
                        "feedback good";

                    runRound();
                    return;

                }

                feedback.textContent =
                    "That's right! On to the next part of your family.";

                feedback.className =
                    "feedback good";

                challengeHandler = null;

                // This Stage is done — shrink it out of the way (the tree
                // stays visible, just smaller). Stage 2 is already visible
                // (Stages 1 and 2 don't depend on each other), so we just
                // announce completion for the Stage 3 lock to hear.
                stage.classList.add("tree-stage--done");

                document.dispatchEvent(
                    new CustomEvent("tree-stage-complete", { detail: { stage: 1 } })
                );

            }


            challengeHandler = (word) => {

                const openBlank =
                    challengeBlanks.find(
                        (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (openBlank) {

                    openBlank.textContent = word;
                    openBlank.classList.add("is-filled");

                    checkComplete();
                    return;

                }

                const alreadySatisfied =
                    challengeBlanks.some(
                        (b) => b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (alreadySatisfied) {
                    return;
                }

                attempts++;

                feedback.textContent =
                    "Not quite — try again.";

                feedback.className =
                    "feedback bad";

                if (attempts >= 2) {
                    help.hidden = false;
                }

            };


            // .onclick (not addEventListener) — these buttons are static
            // and reused every round, so this replaces last round's
            // handler instead of stacking a new one on top of it.
            help.querySelector(".tree-challenge__hint").onclick = () => {

                const genderWord =
                    possessive === "мой" ? "masculine" : "feminine";

                feedback.textContent =
                    `Hint: “${phraseWords.join(" ")}” is ${genderWord} — that decides мой or моя.`;

                feedback.className =
                    "feedback hint";

            };

            help.querySelector(".tree-challenge__escape").onclick = () => {

                challengeBlanks.forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                checkComplete();

            };

        }

        runRound();

    }

})();

// ==================================================
// USE — FAMILY TREE PUZZLE — STAGE 2: EXTENDED FAMILY
// Same mechanic as Stage 1 — click-to-fill, one box active at a time in
// random order, then prove it with a masculine and a feminine Кто это?.
// ==================================================

(() => {

    const stage =
        document.querySelector("#tree-stage-2");

    if (!stage) {
        return;
    }

    const boxes =
        [...stage.querySelectorAll(".tree-box")];

    const challenge =
        stage.querySelector("#tree-2-challenge");

    const resetButton =
        stage.querySelector("#tree-2-reset");

    const bankRoot =
        stage.querySelector("#tree-2-word-bank");


    function shuffle(arr) {

        for (let i = arr.length - 1; i > 0; i--) {

            const j =
                Math.floor(Math.random() * (i + 1));

            [arr[i], arr[j]] = [arr[j], arr[i]];

        }

        return arr;

    }


    // дедушка and бабушка each answer two boxes here (father's father /
    // mother's father both go to дедушка) — the bank buttons are reusable,
    // so that's not a problem. Distractors follow the same two flavors as
    // Stage 1: a plain look-alike typo (дедушока, бабушока).
    const PIECES =
        ["дедушка", "дедушока", "бабушка", "бабушока", "мой", "моя"];


    let challengeHandler = null;

    let activeBox = null;


    function handleBankClick(word) {

        if (challengeHandler) {
            challengeHandler(word);
            return;
        }

        if (!activeBox) {
            return;
        }

        const blanks =
            blanksOf(activeBox);

        const openBlank =
            blanks.find(
                (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (openBlank) {

            openBlank.textContent = word;
            openBlank.classList.add("is-filled");

            if (isBoxSolved(activeBox)) {
                lockBoxSolved(activeBox);
            }

            return;

        }

        const alreadySatisfied =
            blanks.some(
                (b) => b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (alreadySatisfied) {
            return;
        }

        registerWrongAttempt(activeBox);

    }


    shuffle([...PIECES]).forEach((word) => {

        const button =
            document.createElement("button");

        button.type = "button";
        button.dataset.value = word;
        button.textContent = word;

        button.addEventListener("click", () => {
            handleBankClick(word);
        });

        bankRoot.appendChild(button);

    });


    function blanksOf(box) {
        return [...box.querySelectorAll(".use-blank")];
    }


    function isBoxSolved(box) {
        return blanksOf(box).every((b) => b.classList.contains("is-filled"));
    }


    // `order` is `let`, not `const`, because Reset Stage reshuffles a
    // fresh one.
    let order =
        shuffle([...boxes]);

    let current = 0;


    function activateNext() {

        if (current >= order.length) {

            activeBox = null;
            startChallenge();
            return;

        }

        activeBox = order[current];

        activeBox.classList.remove("tree-box--pending");
        activeBox.classList.add("tree-box--active");

    }


    function lockBoxSolved(box) {

        box.classList.remove("tree-box--active");
        box.classList.add("tree-box--solved");

        box.querySelector(".tree-box__help").hidden = true;
        box.querySelector(".feedback").textContent = "";

        current++;
        activateNext();

    }


    function registerWrongAttempt(box) {

        const attempts =
            Number(box.dataset.attempts) + 1;

        box.dataset.attempts = String(attempts);

        const feedback =
            box.querySelector(".feedback");

        feedback.textContent =
            "Not quite — try again.";

        feedback.className =
            "feedback bad";

        if (attempts >= 2) {
            box.querySelector(".tree-box__help").hidden = false;
        }

    }


    boxes.forEach((box) => {

        box.classList.add("tree-box--pending");
        box.dataset.attempts = "0";

        box.querySelector(".tree-box__hint")
            ?.addEventListener("click", () => {

                const feedback =
                    box.querySelector(".feedback");

                feedback.textContent =
                    box.dataset.hint || "";

                feedback.className =
                    "feedback hint";

            });

        box.querySelector(".tree-box__escape")
            ?.addEventListener("click", () => {

                blanksOf(box).forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                lockBoxSolved(box);

            });

    });


    activateNext();


    // Puts this Stage back to exactly how it looked on page load: every
    // box unsolved with a fresh random order, the Кто это? step hidden
    // again, and this Stage's own "done" styling removed. Doesn't touch
    // any other Stage.
    function resetStage() {

        boxes.forEach((box) => {

            box.classList.remove("tree-box--active", "tree-box--solved");
            box.classList.add("tree-box--pending");
            box.dataset.attempts = "0";

            box.querySelector(".tree-box__help").hidden = true;

            const feedback =
                box.querySelector(".feedback");

            feedback.textContent = "";
            feedback.className = "feedback";

            blanksOf(box).forEach((blank) => {
                blank.classList.remove("is-filled");
                blank.textContent = "______";
            });

        });

        stage.classList.remove("tree-stage--done");

        challenge.hidden = true;
        challenge.querySelector("#tree-2-challenge-blanks").innerHTML = "";

        challengeHandler = null;
        activeBox = null;
        current = 0;
        order = shuffle([...boxes]);

        activateNext();

        document.dispatchEvent(
            new CustomEvent("tree-stage-reset", { detail: { stage: 2 } })
        );

    }

    resetButton?.addEventListener("click", resetStage);


    function startChallenge() {

        challenge.hidden = false;

        const masculine =
            boxes.filter((b) => b.dataset.possessive === "мой");

        const feminine =
            boxes.filter((b) => b.dataset.possessive === "моя");

        const pickOne =
            (list) => list[Math.floor(Math.random() * list.length)];

        const targets =
            shuffle([pickOne(masculine), pickOne(feminine)]);

        let round = 0;


        function runRound() {

            const target =
                targets[round];

            round++;

            challenge.querySelector("#tree-2-round").textContent =
                `Question ${round} of ${targets.length}`;

            const targetClue =
                target.querySelector(".tree-box__clue").textContent;

            challenge.querySelector("#tree-2-target").textContent =
                `→ ${targetClue}`;

            const possessive =
                target.dataset.possessive;

            const phraseWords =
                blanksOf(target).map((b) => b.dataset.accept);

            const blanksHost =
                challenge.querySelector("#tree-2-challenge-blanks");

            blanksHost.innerHTML = "";

            function makeBlank(accept) {

                const blank =
                    document.createElement("button");

                blank.type = "button";
                blank.className = "use-blank";
                blank.dataset.accept = accept;
                blank.textContent = "______";

                blanksHost.appendChild(blank);

                return blank;

            }

            const possBlank =
                makeBlank(possessive);

            const phraseBlanks =
                phraseWords.map(makeBlank);

            const challengeBlanks =
                [possBlank, ...phraseBlanks];

            const feedback =
                challenge.querySelector(".feedback");

            const help =
                challenge.querySelector(".tree-challenge__help");

            feedback.textContent = "";
            feedback.className = "feedback";
            help.hidden = true;

            let attempts = 0;


            function checkComplete() {

                if (!challengeBlanks.every((b) => b.classList.contains("is-filled"))) {
                    return;
                }

                help.hidden = true;

                if (round < targets.length) {

                    feedback.textContent =
                        "Right! Now the other one.";

                    feedback.className =
                        "feedback good";

                    runRound();
                    return;

                }

                feedback.textContent =
                    "That's right! Stage 2 complete.";

                feedback.className =
                    "feedback good";

                challengeHandler = null;

                // This Stage is done — shrink it out of the way (the tree
                // stays visible, just smaller). Stage 3 stays locked until
                // Stage 1 is ALSO done — the lock panel's own listener
                // handles that, we just announce completion here.
                stage.classList.add("tree-stage--done");

                document.dispatchEvent(
                    new CustomEvent("tree-stage-complete", { detail: { stage: 2 } })
                );

            }


            challengeHandler = (word) => {

                const openBlank =
                    challengeBlanks.find(
                        (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (openBlank) {

                    openBlank.textContent = word;
                    openBlank.classList.add("is-filled");

                    checkComplete();
                    return;

                }

                const alreadySatisfied =
                    challengeBlanks.some(
                        (b) => b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (alreadySatisfied) {
                    return;
                }

                attempts++;

                feedback.textContent =
                    "Not quite — try again.";

                feedback.className =
                    "feedback bad";

                if (attempts >= 2) {
                    help.hidden = false;
                }

            };


            help.querySelector(".tree-challenge__hint").onclick = () => {

                const genderWord =
                    possessive === "мой" ? "masculine" : "feminine";

                feedback.textContent =
                    `Hint: “${phraseWords.join(" ")}” is ${genderWord} — that decides мой or моя.`;

                feedback.className =
                    "feedback hint";

            };

            help.querySelector(".tree-challenge__escape").onclick = () => {

                challengeBlanks.forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                checkComplete();

            };

        }

        runRound();

    }

})();


// ==================================================
// USE — FAMILY TREE PUZZLE — STAGE 3: YOUR DAD'S FAMILY
// (TOTAL RECALL CAPSTONE)
// Same mechanic again. This is the last Stage — solving it checks the
// overall "Family Tree Puzzle" completion box, which lives at the end
// of this Stage's markup rather than its own.
// ==================================================

(() => {

    const stage =
        document.querySelector("#tree-stage-3");

    if (!stage) {
        return;
    }

    const boxes =
        [...stage.querySelectorAll(".tree-box")];

    const challenge =
        stage.querySelector("#tree-3-challenge");

    const completeCheckbox =
        stage.querySelector("#tree-complete-checkbox");

    const resetButton =
        stage.querySelector("#tree-3-reset");

    const bankRoot =
        stage.querySelector("#tree-3-word-bank");


    function shuffle(arr) {

        for (let i = arr.length - 1; i > 0; i--) {

            const j =
                Math.floor(Math.random() * (i + 1));

            [arr[i], arr[j]] = [arr[j], arr[i]];

        }

        return arr;

    }


    // брат/сестра reuse the exact same distractors as Stage 1 (брать,
    // сестора) — same words, same confusion, no reason to invent new ones.
    // двоюродный/двоюродная get an akanye-style distractor (о written as
    // а) — a real, common beginner spelling slip in unstressed syllables,
    // not just a random typo.
    const PIECES =
        ["дядя", "дяддя", "тётя", "тёття",
            "двоюродный", "двоюрадный", "двоюродная", "двоюрадная",
            "брат", "брать", "сестра", "сестора",
            "мой", "моя"];


    let challengeHandler = null;

    let activeBox = null;


    function handleBankClick(word) {

        if (challengeHandler) {
            challengeHandler(word);
            return;
        }

        if (!activeBox) {
            return;
        }

        const blanks =
            blanksOf(activeBox);

        const openBlank =
            blanks.find(
                (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (openBlank) {

            openBlank.textContent = word;
            openBlank.classList.add("is-filled");

            if (isBoxSolved(activeBox)) {
                lockBoxSolved(activeBox);
            }

            return;

        }

        const alreadySatisfied =
            blanks.some(
                (b) => b.classList.contains("is-filled") && b.dataset.accept === word
            );

        if (alreadySatisfied) {
            return;
        }

        registerWrongAttempt(activeBox);

    }


    shuffle([...PIECES]).forEach((word) => {

        const button =
            document.createElement("button");

        button.type = "button";
        button.dataset.value = word;
        button.textContent = word;

        button.addEventListener("click", () => {
            handleBankClick(word);
        });

        bankRoot.appendChild(button);

    });


    function blanksOf(box) {
        return [...box.querySelectorAll(".use-blank")];
    }


    function isBoxSolved(box) {
        return blanksOf(box).every((b) => b.classList.contains("is-filled"));
    }


    // `order` is `let`, not `const`, because Reset Stage reshuffles a
    // fresh one.
    let order =
        shuffle([...boxes]);

    let current = 0;


    function activateNext() {

        if (current >= order.length) {

            activeBox = null;
            startChallenge();
            return;

        }

        activeBox = order[current];

        activeBox.classList.remove("tree-box--pending");
        activeBox.classList.add("tree-box--active");

    }


    function lockBoxSolved(box) {

        box.classList.remove("tree-box--active");
        box.classList.add("tree-box--solved");

        box.querySelector(".tree-box__help").hidden = true;
        box.querySelector(".feedback").textContent = "";

        current++;
        activateNext();

    }


    function registerWrongAttempt(box) {

        const attempts =
            Number(box.dataset.attempts) + 1;

        box.dataset.attempts = String(attempts);

        const feedback =
            box.querySelector(".feedback");

        feedback.textContent =
            "Not quite — try again.";

        feedback.className =
            "feedback bad";

        if (attempts >= 2) {
            box.querySelector(".tree-box__help").hidden = false;
        }

    }


    boxes.forEach((box) => {

        box.classList.add("tree-box--pending");
        box.dataset.attempts = "0";

        box.querySelector(".tree-box__hint")
            ?.addEventListener("click", () => {

                const feedback =
                    box.querySelector(".feedback");

                feedback.textContent =
                    box.dataset.hint || "";

                feedback.className =
                    "feedback hint";

            });

        box.querySelector(".tree-box__escape")
            ?.addEventListener("click", () => {

                blanksOf(box).forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                lockBoxSolved(box);

            });

    });


    activateNext();


    // Puts this Stage back to exactly how it looked on page load: every
    // box unsolved with a fresh random order, the Кто это? step hidden
    // again, and this Stage's own "done" styling removed. Doesn't touch
    // any other Stage. Stage 3's reset also unchecks the overall "Family
    // Tree Puzzle Complete" checkbox if it was checked — resetting the
    // capstone means the puzzle genuinely isn't complete anymore.
    function resetStage() {

        boxes.forEach((box) => {

            box.classList.remove("tree-box--active", "tree-box--solved");
            box.classList.add("tree-box--pending");
            box.dataset.attempts = "0";

            box.querySelector(".tree-box__help").hidden = true;

            const feedback =
                box.querySelector(".feedback");

            feedback.textContent = "";
            feedback.className = "feedback";

            blanksOf(box).forEach((blank) => {
                blank.classList.remove("is-filled");
                blank.textContent = "______";
            });

        });

        stage.classList.remove("tree-stage--done");

        challenge.hidden = true;
        challenge.querySelector("#tree-3-challenge-blanks").innerHTML = "";

        challengeHandler = null;
        activeBox = null;
        current = 0;
        order = shuffle([...boxes]);

        activateNext();

        if (completeCheckbox && completeCheckbox.checked) {
            completeCheckbox.checked = false;
            completeCheckbox.dispatchEvent(new Event("change"));
        }

        document.dispatchEvent(
            new CustomEvent("tree-stage-reset", { detail: { stage: 3 } })
        );

    }

    resetButton?.addEventListener("click", resetStage);


    function startChallenge() {

        challenge.hidden = false;

        const masculine =
            boxes.filter((b) => b.dataset.possessive === "мой");

        const feminine =
            boxes.filter((b) => b.dataset.possessive === "моя");

        const pickOne =
            (list) => list[Math.floor(Math.random() * list.length)];

        const targets =
            shuffle([pickOne(masculine), pickOne(feminine)]);

        let round = 0;


        function runRound() {

            const target =
                targets[round];

            round++;

            challenge.querySelector("#tree-3-round").textContent =
                `Question ${round} of ${targets.length}`;

            const targetClue =
                target.querySelector(".tree-box__clue").textContent;

            challenge.querySelector("#tree-3-target").textContent =
                `→ ${targetClue}`;

            const possessive =
                target.dataset.possessive;

            const phraseWords =
                blanksOf(target).map((b) => b.dataset.accept);

            const blanksHost =
                challenge.querySelector("#tree-3-challenge-blanks");

            blanksHost.innerHTML = "";

            function makeBlank(accept) {

                const blank =
                    document.createElement("button");

                blank.type = "button";
                blank.className = "use-blank";
                blank.dataset.accept = accept;
                blank.textContent = "______";

                blanksHost.appendChild(blank);

                return blank;

            }

            const possBlank =
                makeBlank(possessive);

            const phraseBlanks =
                phraseWords.map(makeBlank);

            const challengeBlanks =
                [possBlank, ...phraseBlanks];

            const feedback =
                challenge.querySelector(".feedback");

            const help =
                challenge.querySelector(".tree-challenge__help");

            feedback.textContent = "";
            feedback.className = "feedback";
            help.hidden = true;

            let attempts = 0;


            function checkComplete() {

                if (!challengeBlanks.every((b) => b.classList.contains("is-filled"))) {
                    return;
                }

                help.hidden = true;

                if (round < targets.length) {

                    feedback.textContent =
                        "Right! Now the other one.";

                    feedback.className =
                        "feedback good";

                    runRound();
                    return;

                }

                feedback.textContent =
                    "That's right! You've built the whole family tree.";

                feedback.className =
                    "feedback good";

                challengeHandler = null;

                stage.classList.add("tree-stage--done");

                if (completeCheckbox) {
                    completeCheckbox.checked = true;
                    completeCheckbox.dispatchEvent(new Event("change"));
                }

                document.dispatchEvent(
                    new CustomEvent("tree-stage-complete", { detail: { stage: 3 } })
                );

            }


            challengeHandler = (word) => {

                const openBlank =
                    challengeBlanks.find(
                        (b) => !b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (openBlank) {

                    openBlank.textContent = word;
                    openBlank.classList.add("is-filled");

                    checkComplete();
                    return;

                }

                const alreadySatisfied =
                    challengeBlanks.some(
                        (b) => b.classList.contains("is-filled") && b.dataset.accept === word
                    );

                if (alreadySatisfied) {
                    return;
                }

                attempts++;

                feedback.textContent =
                    "Not quite — try again.";

                feedback.className =
                    "feedback bad";

                if (attempts >= 2) {
                    help.hidden = false;
                }

            };


            help.querySelector(".tree-challenge__hint").onclick = () => {

                const genderWord =
                    possessive === "мой" ? "masculine" : "feminine";

                feedback.textContent =
                    `Hint: “${phraseWords.join(" ")}” is ${genderWord} — that decides мой or моя.`;

                feedback.className =
                    "feedback hint";

            };

            help.querySelector(".tree-challenge__escape").onclick = () => {

                challengeBlanks.forEach((blank) => {

                    if (!blank.classList.contains("is-filled")) {
                        blank.textContent = blank.dataset.accept;
                        blank.classList.add("is-filled");
                    }

                });

                checkComplete();

            };

        }

        runRound();

    }

})();


// ==================================================
// USE — VARIATION 1 COORDINATOR
// Stage 1 and Stage 2 are independent and both visible
// from page load. Stage 3 (the capstone) stays behind a
// manual "Reveal Stage 3" button, which unlocks only once
// BOTH Stage 1 and Stage 2 have been completed. Once
// revealed, Stage 3 stays revealed even if Stage 1 or 2 is
// later reset — this only tracks whether the button itself
// should be enabled, and unchecks the overall "complete"
// checkbox whenever any stage is reset.
// ==================================================

(() => {

    const lockPanel =
        document.querySelector("#tree-3-lock");

    const revealButton =
        document.querySelector("#tree-3-reveal");

    const lockNote =
        document.querySelector("#tree-3-lock-note");

    const stage3 =
        document.querySelector("#tree-stage-3");

    const completeCheckbox =
        document.querySelector("#tree-complete-checkbox");

    if (!lockPanel || !revealButton || !stage3) {
        return;
    }

    const done = { 1: false, 2: false };


    function updateLock() {

        const ready = done[1] && done[2];

        revealButton.disabled = !ready;

        if (lockNote) {
            lockNote.textContent = ready
                ? "Ready — click to begin the capstone."
                : "Complete Stage 1 and Stage 2 to unlock this stage.";
        }

    }


    document.addEventListener("tree-stage-complete", (event) => {

        const stageNum = event.detail?.stage;

        if (stageNum === 1 || stageNum === 2) {
            done[stageNum] = true;
            updateLock();
        }

    });


    document.addEventListener("tree-stage-reset", (event) => {

        const stageNum = event.detail?.stage;

        if (stageNum === 1 || stageNum === 2) {
            done[stageNum] = false;
            updateLock();
        }

        // Any stage resetting means the whole puzzle is genuinely no
        // longer complete — uncheck the overall box if it was checked.
        if (completeCheckbox && completeCheckbox.checked) {
            completeCheckbox.checked = false;
            completeCheckbox.dispatchEvent(new Event("change"));
        }

    });


    revealButton.addEventListener("click", () => {

        lockPanel.hidden = true;
        stage3.hidden = false;
        stage3.scrollIntoView({ behavior: "smooth", block: "start" });

    });


    updateLock();

})();





// ==================================================
// THE LISTENING ROOM — 6-ENCOUNTER LISTEN/BUILD/RESPOND VERSION
// Replaces the old "Part A/B/C" Listening Room JS.
// Wrapped in an IIFE to match this file's existing scoping convention.
// NOTE 1: .feedback class renamed to .encounter-feedback throughout to
// avoid colliding with the site-wide .feedback class used elsewhere.
// NOTE 2 (2026-09-10 fix): scrollTo(top:0) calls changed to scroll the
// .listening-room wrapper into view instead of the whole page — see
// integration notes for why.
// ==================================================
(() => {
    const encounters = [
        {
            // Encounter 1 — Lesson 1: любить + possessives
            primary: "Я очень люблю мою семью, а моя семья любит меня.",
            variation: "Моя семья любит меня, и я люблю мою семью.",
            catch: ["я", "меня", "моя семья", "мою семью", "любит", "люблю", "родители", "брат", "сестра"],
            meaningQuestion: "Who loves whom?",
            meaningChoices: [
                "I love my family, and my family loves me.",
                "My family loves me, but I do not love my family.",
                "My family loves another family."
            ],
            meaningAnswer: 0,
            inferQuestion: "Did the direction of the love change when the people were mentioned in a different order?",
            inferChoices: ["No.", "Yes.", "The speaker does not say."],
            inferAnswer: 0,
            respondQuestion: "Кого ты любишь?",
            respondChoices: ["Я люблю мою семью.", "Я люблю маму.", "Я люблю папу."],
            respondAnswer: 0,
            support: "Listen for я люблю = \"I love\" and любит меня = \"loves me.\"",
            transcript: "Я очень люблю мою семью, а моя семья любит меня."
        },
        {
            // Encounter 2 — Lesson 2: Сколько? + family size
            primary: "Сколько человек в вашей семье? В моей семье шесть человек.",
            variation: "Сколько человек в вашей семье? Нас в семье шестеро.",
            catch: ["сколько", "человек", "семье", "шесть", "три", "четыре", "пять", "семь", "девять", "десять"],
            meaningQuestion: "How many people are in the speaker's family?",
            meaningChoices: ["Four", "Six", "Seven"],
            meaningAnswer: 1,
            inferQuestion: "What information was the first speaker asking for?",
            inferChoices: ["The size of the family", "Where the family lives", "Who is the oldest"],
            inferAnswer: 0,
            respondQuestion: "Сколько человек в твоей семье?",
            respondChoices: ["один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять", "десять", "10+"],
            respondAcceptsAny: true,
            support: "Listen for Сколько человек...? Then listen for the number in the response.",
            transcript: "Сколько человек в вашей семье? В моей семье шесть человек."
        },
        {
            // Encounter 3 — Lesson 2: counting siblings
            primary: "У меня есть два брата и одна сестра.",
            variation: "У меня одна сестра и два брата.",
            catch: ["один брат", "два брата", "три брата", "одна сестра", "две сестры", "четыре сестры"],
            meaningQuestion: "Who does the speaker have in the family?",
            meaningChoices: ["Two brothers and one sister", "One brother and two sisters", "Two brothers and two sisters"],
            meaningAnswer: 0,
            inferQuestion: "If the speaker says the sister first, does the family information change?",
            inferChoices: ["No, the same siblings are described", "Yes, the family changes", "We cannot tell"],
            inferAnswer: 0,
            respondQuestion: "У тебя есть брат или сестра?",
            respondChoices: ["Да, у меня есть брат.", "Да, у меня есть сестра.", "Да, у меня есть братья и сёстры.", "Нет."],
            respondAnswer: 0,
            // NOTE: also a free-response-style item in spirit — learner picks whichever is true for them.
            support: "Listen separately for the number and the family word.",
            transcript: "У меня есть два брата и одна сестра."
        },
        {
            // Encounter 4 — Lesson 2: identification dialogue
            primary: "Кто это? Твой брат? — Нет, это моя сестра.",
            variation: "Это твоя сестра? — Нет, это мой брат.",
            catch: ["брат", "сестра", "мама", "папа", "дедушка", "дядя"],
            meaningQuestion: "Who is the person?",
            meaningChoices: ["The speaker's brother", "The speaker's sister", "The speaker's mother"],
            meaningAnswer: 1,
            inferQuestion: "Was the first speaker's guess correct?",
            inferChoices: ["No", "Yes", "We don't know"],
            inferAnswer: 0,
            respondQuestion: "Кто это?",
            respondChoices: ["Это мой брат.", "Это моя сестра.", "Это моя мама.", "Это мой папа."],
            respondAnswer: 1,
            support: "Don't stop when you hear брат. Listen for what comes after нет.",
            transcript: "Кто это? Твой брат? — Нет, это моя сестра."
        },
        {
            // Encounter 5 — Lesson 2: жить + location contrast
            primary: "Мои бабушка и дедушка живут в Москве, а я живу здесь.",
            variation: "Я живу здесь, а мои бабушка с дедушкой — в Москве.",
            catch: ["Москва", "здесь", "бабушка и дедушка", "я", "Санкт-Петербург", "дядя", "тётя"],
            meaningQuestion: "Where do the grandparents live?",
            meaningChoices: ["In Moscow", "Here with the speaker", "The speaker doesn't say"],
            meaningAnswer: 0,
            inferQuestion: "Does the speaker live in the same place as the grandparents?",
            inferChoices: ["No", "Yes", "We cannot tell"],
            inferAnswer: 0,
            respondQuestion: "Где живут твои бабушка и дедушка?",
            respondChoices: ["Они живут в ___.", "Они живут здесь.", "Я не знаю."],
            respondAnswer: 0,
            // NOTE: free-response fill-in for the blank.
            support: "Listen for живут with бабушка и дедушка and живу with я.",
            transcript: "Мои бабушка и дедушка живут в Москве, а я живу здесь."
        },
        {
            // Encounter 6 — Lesson 3: любить (completed forms) + pronoun их
            primary: "Ты любишь бабушку и дедушку? Да, я их очень люблю.",
            variation: "Ты любишь бабушку и дедушку? Конечно. Я их очень люблю.",
            catch: ["я", "их", "бабушку", "дедушку", "люблю", "дядя", "тётя", "родители"],
            meaningQuestion: "Who does их refer to?",
            meaningChoices: ["The grandmother and grandfather", "The speaker", "The speaker's whole family"],
            meaningAnswer: 0,
            inferQuestion: "How does the answer avoid repeating бабушку и дедушку?",
            inferChoices: ["It uses их", "It uses я", "It uses ты"],
            inferAnswer: 0,
            respondQuestion: "Ты любишь твою семью?",
            respondChoices: ["Да, я очень люблю мою семью.", "Да, очень.", "Конечно."],
            respondAnswer: 0,
            support: "Listen to the people named in the question. Then ask yourself who их replaces in the answer.",
            transcript: "Ты любишь бабушку и дедушку? Да, я их очень люблю."
        }
    ];

    const moves = [
        {
            label: "HEAR",
            prompt: "Listen once. Do not try to catch every word.",
            purpose: "First, listen for the overall shape of the message."
        },
        {
            label: "CATCH",
            prompt: "What did your ears catch?",
            purpose: "Recognize familiar Russian without requiring the whole sentence."
        },
        {
            label: "LISTEN AGAIN",
            prompt: "Listen again with a purpose.",
            purpose: "This time, listen for the days and the actions."
        },
        {
            label: "BUILD MEANING",
            prompt: "Put the pieces together.",
            purpose: "Use what you understood to decide what the message means."
        },
        {
            label: "INFER",
            prompt: "Listen for what changed.",
            purpose: "The Russian changed naturally. Follow the meaning, not a memorized sentence."
        },
        {
            label: "RESPOND",
            prompt: "Respond to what you understood.",
            purpose: "Use the meaning you built to choose the response that fits."
        }
    ];

    const el = {
        room: document.querySelector(".listening-room"),
        landing: document.getElementById("landingScreen"),
        experience: document.getElementById("experienceScreen"),
        completion: document.getElementById("completionScreen"),
        enter: document.getElementById("enterButton"),
        listen: document.getElementById("listenButton"),
        slower: document.getElementById("slowerButton"),
        audioStatus: document.getElementById("audioStatus"),

        navigator: document.getElementById("encounterNavigator"),
        navigatorButtons: [...document.querySelectorAll(".encounter-nav-button")],
        navigatorStatus: document.getElementById("encounterNavigatorStatus"),
        moveLabel: document.getElementById("moveLabel"),
        movePrompt: document.getElementById("movePrompt"),
        movePurpose: document.getElementById("movePurpose"),
        catchPanel: document.getElementById("catchPanel"),
        catchGrid: document.getElementById("catchGrid"),
        catchContinue: document.getElementById("catchContinueButton"),
        meaningPanel: document.getElementById("meaningPanel"),
        meaningQuestion: document.getElementById("meaningQuestion"),
        meaningChoices: document.getElementById("meaningChoices"),
        meaningFeedback: document.getElementById("meaningFeedback"),
        inferPanel: document.getElementById("inferPanel"),
        inferQuestion: document.getElementById("inferQuestion"),
        inferChoices: document.getElementById("inferChoices"),
        inferFeedback: document.getElementById("inferFeedback"),
        respondPanel: document.getElementById("respondPanel"),
        respondQuestion: document.getElementById("respondQuestion"),
        respondChoices: document.getElementById("respondChoices"),
        respondFeedback: document.getElementById("respondFeedback"),
        supportPanel: document.getElementById("supportPanel"),
        supportText: document.getElementById("supportText"),
        supportButton: document.getElementById("supportButton"),
        revealTranscript: document.getElementById("revealTranscriptButton"),
        transcript: document.getElementById("transcriptText"),
        nextMove: document.getElementById("nextMoveButton"),
        nextEncounter: document.getElementById("nextEncounterButton"),
        reset: document.getElementById("resetButton"),
        restart: document.getElementById("restartButton")
    };

    let encounterIndex = 0;
    let moveIndex = 0;
    let lastSpokenText = "";
    let lastRate = 0.86;

    // Completion belongs to individual encounters, not to their position
    // in a forced sequence. A learner may jump around freely; an encounter
    // is earned only after its final RESPOND choice is completed successfully.
    const completedEncounters = new Set();

    function updateEncounterNavigator() {
        el.navigatorButtons.forEach((button) => {
            const index = Number(button.dataset.encounterIndex);
            const isCurrent = index === encounterIndex;
            const isComplete = completedEncounters.has(index);
            const state = button.querySelector(".encounter-nav-button__state");

            button.classList.toggle("encounter-nav-button--current", isCurrent);
            button.classList.toggle("encounter-nav-button--complete", isComplete);

            if (isCurrent) {
                button.setAttribute("aria-current", "step");
            } else {
                button.removeAttribute("aria-current");
            }

            if (state) {
                if (isCurrent && isComplete) {
                    state.textContent = "✓ Complete • You are here";
                } else if (isCurrent) {
                    state.textContent = "You are here";
                } else if (isComplete) {
                    state.textContent = "✓ Complete";
                } else {
                    state.textContent = "Open";
                }
            }
        });

        if (el.navigatorStatus) {
            el.navigatorStatus.textContent =
                `You are in Encounter ${encounterIndex + 1}. Completed: ${completedEncounters.size} of ${encounters.length}.`;
        }
    }

    function jumpToEncounter(index) {
        if (index < 0 || index >= encounters.length) {
            return;
        }

        window.speechSynthesis?.cancel();
        encounterIndex = index;

        // Version 1 rule: if a learner leaves an unfinished encounter midway,
        // returning to it restarts that encounter at HEAR rather than preserving
        // every internal Listening Move state.
        moveIndex = 0;
        renderMove();
    }

    function markCurrentEncounterComplete() {
        completedEncounters.add(encounterIndex);
        updateEncounterNavigator();

        el.nextMove.hidden = true;
        el.nextEncounter.hidden = false;
        el.nextEncounter.textContent =
            completedEncounters.size === encounters.length
                ? "Finish Listening Room"
                : "Next Encounter";
    }

    function nextRecommendedEncounterIndex() {
        // Keep the normal recommended forward path when possible. If the learner
        // is at Encounter 6 but earlier encounters remain unfinished, wrap to the
        // first unfinished encounter instead of falsely completing the Room.
        for (let offset = 1; offset <= encounters.length; offset += 1) {
            const candidate = (encounterIndex + offset) % encounters.length;
            if (!completedEncounters.has(candidate)) {
                return candidate;
            }
        }

        return null;
    }

    function speak(text, rate = 0.86) {
        if (!("speechSynthesis" in window)) {
            el.audioStatus.textContent = "Speech synthesis is not available in this browser.";
            return;
        }

        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "ru-RU";
        utterance.rate = rate;

        const voices = window.speechSynthesis.getVoices();
        const russianVoice = voices.find((voice) => voice.lang && voice.lang.toLowerCase().startsWith("ru"));
        if (russianVoice) {
            utterance.voice = russianVoice;
        }

        utterance.onstart = () => {
            el.audioStatus.textContent = "Listening...";
        };

        utterance.onend = () => {
            el.audioStatus.textContent = "Ready to listen again.";
        };

        utterance.onerror = () => {
            el.audioStatus.textContent = "The browser could not play this Russian audio.";
        };

        lastSpokenText = text;
        lastRate = rate;
        window.speechSynthesis.speak(utterance);
    }

    function clearPanels() {
        [
            el.catchPanel,
            el.meaningPanel,
            el.inferPanel,
            el.respondPanel,
            el.supportPanel
        ].forEach((panel) => {
            panel.hidden = true;
        });

        el.slower.hidden = true;
        el.supportButton.hidden = true;
        el.nextMove.hidden = true;
        el.nextEncounter.hidden = true;

        el.meaningFeedback.textContent = "";
        el.meaningFeedback.className = "encounter-feedback";
        el.inferFeedback.textContent = "";
        el.inferFeedback.className = "encounter-feedback";
        el.respondFeedback.textContent = "";
        el.respondFeedback.className = "encounter-feedback";
    }

    function makeChoiceButtons(
        container,
        choices,
        answerIndex,
        feedbackEl,
        successText,
        acceptAny = false,
        onSuccess = null,
        showNextMove = true
    ) {
        container.innerHTML = "";

        choices.forEach((choice, index) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "choice-button";
            button.textContent = choice;

            button.addEventListener("click", () => {
                if (acceptAny || index === answerIndex) {
                    feedbackEl.textContent = successText;
                    feedbackEl.className = "encounter-feedback encounter-feedback--success";
                    [...container.querySelectorAll("button")].forEach((item) => {
                        item.disabled = true;
                    });
                    if (showNextMove) {
                        el.nextMove.hidden = false;
                    }

                    if (onSuccess) {
                        onSuccess();
                    }
                } else {
                    feedbackEl.textContent = "Not quite. Listen again and use what you do understand.";
                    feedbackEl.className = "encounter-feedback encounter-feedback--try";
                }
            });

            container.appendChild(button);
        });
    }

    function renderCatch(encounter) {
        el.catchGrid.innerHTML = "";

        encounter.catch.forEach((word) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "catch-chip";
            button.textContent = word;
            button.setAttribute("aria-pressed", "false");

            button.addEventListener("click", () => {
                const pressed = button.getAttribute("aria-pressed") === "true";
                button.setAttribute("aria-pressed", String(!pressed));
            });

            el.catchGrid.appendChild(button);
        });
    }

    function renderMove() {
        const encounter = encounters[encounterIndex];
        const move = moves[moveIndex];

        clearPanels();

        updateEncounterNavigator();
        el.moveLabel.textContent = move.label;
        el.movePrompt.textContent = move.prompt;
        el.movePurpose.textContent = move.purpose;
        el.audioStatus.textContent = "Ready when you are.";

        if (moveIndex === 0) {
            el.listen.onclick = () => speak(encounter.primary, 0.86);
            el.nextMove.hidden = false;
        }

        if (moveIndex === 1) {
            renderCatch(encounter);
            el.catchPanel.hidden = false;
            el.listen.onclick = () => speak(encounter.primary, 0.86);
            el.catchContinue.onclick = () => {
                moveIndex += 1;
                renderMove();
            };
        }

        if (moveIndex === 2) {
            el.listen.onclick = () => speak(encounter.primary, 0.86);
            el.slower.hidden = false;
            el.slower.onclick = () => speak(encounter.primary, 0.68);
            el.supportButton.hidden = false;
            el.nextMove.hidden = false;
        }

        if (moveIndex === 3) {
            el.meaningPanel.hidden = false;
            el.meaningQuestion.textContent = encounter.meaningQuestion;
            makeChoiceButtons(
                el.meaningChoices,
                encounter.meaningChoices,
                encounter.meaningAnswer,
                el.meaningFeedback,
                "Yes. You followed the meaning."
            );
            el.listen.onclick = () => speak(encounter.primary, 0.86);
            el.supportButton.hidden = false;
        }

        if (moveIndex === 4) {
            el.inferPanel.hidden = false;
            el.inferQuestion.textContent = encounter.inferQuestion;
            makeChoiceButtons(
                el.inferChoices,
                encounter.inferChoices,
                encounter.inferAnswer,
                el.inferFeedback,
                "Exactly. You followed the change without needing the original wording."
            );
            el.listen.onclick = () => speak(encounter.variation, 0.86);
            el.slower.hidden = false;
            el.slower.onclick = () => speak(encounter.variation, 0.68);
            el.supportButton.hidden = false;
        }

        if (moveIndex === 5) {
            el.respondPanel.hidden = false;
            el.respondQuestion.textContent = encounter.respondQuestion;
            makeChoiceButtons(
                el.respondChoices,
                encounter.respondChoices,
                encounter.respondAnswer,
                el.respondFeedback,
                "Well done. You responded to what you understood.",
                Boolean(encounter.respondAcceptsAny),
                markCurrentEncounterComplete,
                false
            );
            el.listen.onclick = () => speak(encounter.variation, 0.86);
            el.supportButton.hidden = false;
        }

        el.supportText.textContent = encounter.support;
        el.transcript.textContent = encounter.transcript;
        el.transcript.hidden = true;

        if (moveIndex === 5) {
            el.nextMove.hidden = true;
        }
    }

    function advanceMove() {
        if (moveIndex < moves.length - 1) {
            moveIndex += 1;
            renderMove();
            return;
        }

        el.nextEncounter.hidden = false;
    }


    function showCompletion() {
        window.speechSynthesis?.cancel();
        el.landing.hidden = true;
        el.experience.hidden = true;
        el.completion.hidden = false;
        el.room?.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    function resetRoom() {
        window.speechSynthesis?.cancel();
        completedEncounters.clear();
        encounterIndex = 0;
        moveIndex = 0;
        updateEncounterNavigator();
        el.completion.hidden = true;
        el.landing.hidden = false;
        el.experience.hidden = true;
        el.room?.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    el.enter.addEventListener("click", () => {
        el.landing.hidden = true;
        el.completion.hidden = true;
        el.experience.hidden = false;
        completedEncounters.clear();
        encounterIndex = 0;
        moveIndex = 0;
        renderMove();
        el.room?.scrollIntoView({ behavior: "smooth", block: "start" });
    });

    el.nextMove.addEventListener("click", advanceMove);

    el.nextEncounter.addEventListener("click", () => {
        if (completedEncounters.size === encounters.length) {
            showCompletion();
            return;
        }

        const nextIndex = nextRecommendedEncounterIndex();
        if (nextIndex !== null) {
            jumpToEncounter(nextIndex);
        }
    });

    el.navigatorButtons.forEach((button) => {
        button.addEventListener("click", () => {
            jumpToEncounter(Number(button.dataset.encounterIndex));
        });
    });

    el.supportButton.addEventListener("click", () => {
        el.supportPanel.hidden = false;
    });

    el.revealTranscript.addEventListener("click", () => {
        el.transcript.hidden = false;
    });

    el.reset.addEventListener("click", resetRoom);
    el.restart.addEventListener("click", resetRoom);

    el.slower.addEventListener("click", () => {
        if (lastSpokenText) {
            speak(lastSpokenText, 0.68);
        }
    });
})();
// END THE LISTENING ROOM

// ==================================================
// EXPLORE — DOOR NAVIGATION
// ==================================================

const exploreHallway =
    document.querySelector("#explore-hallway");

const explorePersonalRoom =
    document.querySelector("#explore-personal");


// Open Door 1 — Make It More Personal
document
    .querySelector('.explore-door[data-door="personal"]')
    ?.addEventListener("click", () => {

        if (exploreHallway) {
            exploreHallway.hidden = true;
        }

        if (explorePersonalRoom) {
            explorePersonalRoom.hidden = false;

            explorePersonalRoom.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }

    });


// Return from Door 1 to the EXPLORE hallway
document
    .querySelectorAll("#explore-personal .explore-return-hallway")
    .forEach((button) => {

        button.addEventListener("click", () => {

            if (explorePersonalRoom) {
                explorePersonalRoom.hidden = true;
            }

            if (exploreHallway) {
                exploreHallway.hidden = false;

                exploreHallway.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }

        });

    });

// BEGIN DISCOVERY 1 ACTUAL

// ==================================================
// EXPLORE — DOOR 1 DISCOVERY ONE
// STAGE 2 — WARM-UP CARDS — CHECK MY ANSWER
// ==================================================

const personalWarmups = [1, 2, 3].map((n) => ({
    input: document.querySelector(`#personal-warmup-${n}-input`),
    check: document.querySelector(`#personal-warmup-${n}-check`),
    feedback: document.querySelector(`#personal-warmup-${n}-feedback`),
    answer: document.querySelector(`#personal-warmup-${n}-answer`)
}));

function checkPersonalWarmup(warmup) {

    if (!warmup.input || !warmup.answer) {
        return;
    }

    const response =
        warmup.input.value.trim();

    if (!response) {

        if (warmup.feedback) {
            warmup.feedback.textContent =
                "Type your best guess first — there's no wrong way to try.";
        }

        warmup.input.focus();
        return;
    }

    if (warmup.feedback) {
        warmup.feedback.textContent =
            "Nice try! Compare your answer with the Russian below.";
    }

    warmup.answer.hidden = false;

    warmup.answer.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

}

personalWarmups.forEach((warmup) => {

    warmup.check?.addEventListener(
        "click",
        () => checkPersonalWarmup(warmup)
    );

    warmup.input?.addEventListener(
        "keydown",
        (event) => {

            if (event.key === "Enter") {
                event.preventDefault();
                checkPersonalWarmup(warmup);
            }

        }
    );

});

// ==================================================
// EXPLORE — DOOR 1 DISCOVERY ONE
// STAGE 3 — SPOT THE PATTERN (RECOGNITION ROUNDS)
// ==================================================

// Shuffle each round's options into random order on load,
// so the correct pair never sits in a predictable position.
document.querySelectorAll(".personal-recognize-options").forEach((group) => {

    const options =
        Array.from(group.children);

    for (let i = options.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [options[i], options[j]] = [options[j], options[i]];
    }

    options.forEach((option) => group.appendChild(option));

});

// Toggle selection on click (does nothing once a round is solved).
document.querySelectorAll(".personal-recognize-option").forEach((option) => {
    option.addEventListener("click", () => {
        if (option.disabled) return;
        option.classList.toggle("selected");
    });
});

const personalRecognizeRounds = [1, 2].map((n) => ({
    round: document.querySelector(`#personal-recognize-${n}`),
    check: document.querySelector(`#personal-recognize-${n}-check`),
    feedback: document.querySelector(`#personal-recognize-${n}-feedback`)
}));

function checkPersonalRecognize(entry) {

    if (!entry.round) return;

    const options =
        Array.from(entry.round.querySelectorAll(".personal-recognize-option"));

    const selected =
        options.filter((option) => option.classList.contains("selected"));

    const selectedCorrectly =
        selected.length === 2 &&
        selected.every((option) => option.dataset.correct === "true");

    if (selectedCorrectly) {

        selected.forEach((option) => {
            option.classList.add("correct");
            option.disabled = true;
        });

        options.forEach((option) => {
            if (!option.classList.contains("correct")) {
                option.disabled = true;
            }
        });

        if (entry.feedback) {
            entry.feedback.textContent = "YES!";
        }

    } else {

        if (entry.feedback) {
            entry.feedback.textContent = "Let's try again.";
        }

    }

}

personalRecognizeRounds.forEach((entry) => {
    entry.check?.addEventListener(
        "click",
        () => checkPersonalRecognize(entry)
    );
});

// END DISCOVERY 1 ACTUAL

// ==================================================
// EXPLORE — DOOR 1 DISCOVERY TWO
// NEW WORDS — CLICK TO REVEAL (четыре / шесть)
// ==================================================

const personalNewWords =
    document.querySelectorAll("#personal-discovery-2 .explore-new-word");

personalNewWords.forEach((word) => {
    word.addEventListener("click", () => {
        const target = document.getElementById(word.dataset.revealTarget);
        if (target) {
            target.hidden = false;
        }
    });
});

// ==================================================
// EXPLORE — DOOR 1 DISCOVERY TWO
// REVEAL THE MEANING
// ==================================================

const personalReveal2 =
    document.querySelector("#personal-reveal-2");

const personalMeaning2 =
    document.querySelector("#personal-meaning-2");

const personalExploreMore2 =
    document.querySelector("#personal-explore-more-2");

const personalQuestionWordsExplorer2 =
    document.querySelector("#personal-question-words-explorer-2");

const personalPrediction2 =
    document.querySelector("#personal-prediction-2");

personalReveal2?.addEventListener("click", () => {
    if (!personalMeaning2) return;
    personalMeaning2.hidden = false;
});

// ==================================================
// EXPLORE — DOOR 1
// EXPLORE MORE — QUESTION WORD FAMILY
// ==================================================

personalExploreMore2?.addEventListener("click", () => {
    if (!personalQuestionWordsExplorer2) return;

    const willShow = personalQuestionWordsExplorer2.hidden;
    personalQuestionWordsExplorer2.hidden = !willShow;
    personalExploreMore2.textContent = willShow ? "Close Explore More" : "🍬 Explore More";

    if (willShow) {
        personalQuestionWordsExplorer2.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
});

const personalQuestionWordDetails = {
    "что": { word: "Что?", meaning: "What?", example: "Что это?", english: "What is this?", note: "Use it when you are asking what something is." },
    "как": { word: "Как?", meaning: "How?", example: "Как вас зовут?", english: "What is your name?", note: "You already know this from asking someone's name." },
    "когда": { word: "Когда?", meaning: "When?", example: "Когда?", english: "When?", note: "Use it when you are asking about time." },
    "почему": { word: "Почему?", meaning: "Why?", example: "Почему?", english: "Why?", note: "Use it when you want to know the reason." },
    "откуда": { word: "Откуда?", meaning: "From where?", example: "Откуда вы?", english: "Where are you from?", note: "It points toward where someone or something comes from." },
    "кто": { word: "Кто?", meaning: "Who?", example: "Кто это?", english: "Who is this?", note: "Use it when you are asking about a person." },
    "куда": { word: "Куда?", meaning: "Where to?", example: "Куда?", english: "Where to?", note: "It points toward a destination or direction." },
    "где": { word: "Где?", meaning: "Where?", example: "Где вы живёте?", english: "Where do you live?", note: "Use it when you are asking where someone or something is." },
    "сколько": { word: "Сколько?", meaning: "How many / how much?", example: "Сколько человек в вашей семье?", english: "How many people are in your family?", note: "This is the featured question word in Family Relationships. You already used it in Discovery Two to ask how many people are in someone's family.", featured: true, candyReady: true }
};

const personalQuestionWordInfo2 =
    document.querySelector("#personal-question-word-info-2");

const personalKakCandy =
    document.querySelector("#personal-kak-candy");

document
    .querySelectorAll("#personal-question-words-explorer-2 .question-word-tile")
    .forEach((button) => {
        button.addEventListener("click", () => {
            document
                .querySelectorAll("#personal-question-words-explorer-2 .question-word-tile")
                .forEach((tile) => tile.classList.remove("selected"));

            button.classList.add("selected");

            const detail =
                personalQuestionWordDetails[button.dataset.personalQuestionWord];

            if (!detail || !personalQuestionWordInfo2) return;

            personalQuestionWordInfo2.innerHTML = `
                <div class="question-word-info__detail">
                    <h5 lang="ru">${detail.word}</h5>
                    <p class="question-word-info__meaning">${detail.meaning}</p>
                    <div class="question-word-info__example">
                        <strong lang="ru">${detail.example}</strong>
                        <span>${detail.english}</span>
                    </div>
                    <p class="question-word-info__note">${detail.note}</p>
                    ${detail.featured && detail.candyReady ? '<button type="button" class="question-word-info__candy-button" id="open-personal-kak-candy">🍬 Unlock the Grammar Candy</button>' : ''}
                </div>`;

            document
                .querySelector("#open-personal-kak-candy")
                ?.addEventListener("click", () => {
                    if (!personalKakCandy) return;
                    personalKakCandy.hidden = false;
                    personalKakCandy.scrollIntoView({ behavior: "smooth", block: "nearest" });
                });
        });
    });

// ==================================================
// EXPLORE — DOOR 1
// КАК? GRAMMAR CANDY — INFORMAL / FORMAL SWITCH
// ==================================================

const personalKakGraphic =
    document.querySelector("#personal-kak-candy-graphic");

const personalKakListen =
    document.querySelector("#personal-kak-listen");

const personalKakStates = {
    informal: {
        src: "../../Images/grammar-candy-missing-Человека.svg",
        alt: "Informal Grammar Candy card explaining Как тебя зовут?",
        speak: "Как тебя зовут?"
    },
    formal: {
        src: "../../Images/grammar-candy-ВАШЕЙ.svg",
        alt: "Formal Grammar Candy card explaining Как вас зовут?",
        speak: "Как вас зовут?"
    }
};

function setPersonalKakState(register, animate = true) {
    const state = personalKakStates[register];
    if (!state) return;

    document
        .querySelectorAll(".personal-kak-choice")
        .forEach((button) => {
            button.classList.toggle("selected", button.dataset.kakRegister === register);
        });

    if (personalKakListen) {
        personalKakListen.dataset.speak = state.speak;
    }

    if (!personalKakGraphic) return;

    const applyGraphic = () => {
        personalKakGraphic.src = state.src;
        personalKakGraphic.alt = state.alt;
        personalKakGraphic.classList.remove("is-changing");
    };

    if (animate) {
        personalKakGraphic.classList.add("is-changing");
        window.setTimeout(applyGraphic, 140);
    } else {
        applyGraphic();
    }
}

document.querySelectorAll(".personal-kak-choice").forEach((button) => {
    button.addEventListener("click", () => {
        setPersonalKakState(button.dataset.kakRegister, true);
    });
});

document.querySelector("#personal-kak-reset")?.addEventListener("click", () => {
    setPersonalKakState("informal", false);

    if (personalKakCandy) {
        personalKakCandy.hidden = true;
    }
});

// ==================================================
// EXPLORE — DOOR 1 - RESTORE THIS DOOR
// ==================================================

document
    .querySelectorAll("#explore-personal .explore-reset-room")
    .forEach((button) => {
        button.addEventListener("click", () => {

            // BEGIN DISCOVERY 1 ACTUAL
            personalWarmups.forEach((warmup) => {
                if (warmup.input) {
                    warmup.input.value = "";
                }
                if (warmup.answer) {
                    warmup.answer.hidden = true;
                }
                if (warmup.feedback) {
                    warmup.feedback.textContent = "";
                }
            });

            personalRecognizeRounds.forEach((entry) => {
                if (!entry.round) return;
                entry.round.querySelectorAll(".personal-recognize-option").forEach((option) => {
                    option.classList.remove("selected", "correct");
                    option.disabled = false;
                });
                if (entry.feedback) {
                    entry.feedback.textContent = "";
                }
            });
            // END DISCOVERY 1 ACTUAL

            personalNewWords.forEach((word) => {
                const target = document.getElementById(word.dataset.revealTarget);
                if (target) {
                    target.hidden = true;
                }
            });

            if (personalPrediction2) {
                personalPrediction2.value = "";
            }

            if (personalMeaning2) {
                personalMeaning2.hidden = true;
            }

            if (personalQuestionWordsExplorer2) {
                personalQuestionWordsExplorer2.hidden = true;
            }

            if (personalExploreMore2) {
                personalExploreMore2.textContent = "🍬 Explore More";
            }

            if (personalQuestionWordInfo2) {
                personalQuestionWordInfo2.innerHTML = `
                    <div class="question-word-info__prompt">
                        <span class="question-word-info__icon">?</span>
                        <strong>Select a Question Word</strong>
                        <p>You'll see what it means, a short example, and how it's used.</p>
                    </div>`;
            }

            document
                .querySelectorAll("#personal-question-words-explorer-2 .question-word-tile")
                .forEach((tile) => tile.classList.remove("selected"));

            setPersonalKakState("informal", false);

            if (personalKakCandy) {
                personalKakCandy.hidden = true;
            }
        });
    });


// ==================================================
// EXPLORE — DOOR 2 - SAME FAMILY, DIFFERENT FEELING
// ==================================================

const explorePeopleRoom =
    document.querySelector("#explore-people");


// Open Door 2 — Same Family, Different Feeling.
document
    .querySelector('.explore-door[data-door="people"]')
    ?.addEventListener("click", () => {

        if (exploreHallway) {
            exploreHallway.hidden = true;
        }

        if (explorePeopleRoom) {
            explorePeopleRoom.hidden = false;

            explorePeopleRoom.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }

    });


// Return from Door 2 to the EXPLORE hallway
document
    .querySelectorAll("#explore-people .explore-return-hallway")
    .forEach((button) => {

        button.addEventListener("click", () => {

            if (explorePeopleRoom) {
                explorePeopleRoom.hidden = true;
            }

            if (exploreHallway) {
                exploreHallway.hidden = false;

                exploreHallway.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }

        });

    });

// ==================================================
// EXPLORE — DOOR 2
// DISCOVERY ONE — REVEAL
// ==================================================

const peoplePrediction1 =
    document.querySelector("#people-prediction-1");

const peopleReveal1 =
    document.querySelector("#people-reveal-1");

const peopleMeaning1 =
    document.querySelector("#people-meaning-1");

peopleReveal1?.addEventListener("click", () => {

    if (!peopleMeaning1) {
        return;
    }

    peopleMeaning1.hidden = false;

    peopleMeaning1.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

});


// ==================================================
// EXPLORE — DOOR 2
// DISCOVERY TWO — REVEAL
// ==================================================

const peoplePrediction2 =
    document.querySelector("#people-prediction-2");

const peopleReveal2 =
    document.querySelector("#people-reveal-2");

const peopleMeaning2 =
    document.querySelector("#people-meaning-2");

peopleReveal2?.addEventListener("click", () => {

    if (!peopleMeaning2) {
        return;
    }

    peopleMeaning2.hidden = false;

    peopleMeaning2.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

});


// ==================================================
// EXPLORE — DOOR 2
// DISCOVERY THREE — REVEAL
// ==================================================

const peoplePrediction3 =
    document.querySelector("#people-prediction-3");

const peopleReveal3 =
    document.querySelector("#people-reveal-3");

const peopleMeaning3 =
    document.querySelector("#people-meaning-3");

peopleReveal3?.addEventListener("click", () => {

    if (!peopleMeaning3) {
        return;
    }

    peopleMeaning3.hidden = false;

    peopleMeaning3.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

});

// Discovery Three — Grammar Candy (same family, different endings)

const peopleExploreMoreEndings =
    document.querySelector("#people-explore-more-endings");

const peopleExploreMoreEndingsReveal =
    document.querySelector("#people-explore-more-endings-reveal");

peopleExploreMoreEndings?.addEventListener("click", () => {

    if (!peopleExploreMoreEndingsReveal) {
        return;
    }

    const isHidden = peopleExploreMoreEndingsReveal.hasAttribute("hidden");

    if (isHidden) {
        peopleExploreMoreEndingsReveal.removeAttribute("hidden");
        peopleExploreMoreEndings.textContent = "🍬 Hide Grammar Candy";
    } else {
        peopleExploreMoreEndingsReveal.setAttribute("hidden", "");
        peopleExploreMoreEndings.textContent = "🍬 Explore More";
    }

});

// Discovery Five — sneaky "why Я люблю" reveal

const peopleExploreMorePronoun =
    document.querySelector("#people-explore-more-pronoun");

const peopleExploreMorePronounReveal =
    document.querySelector("#people-explore-more-pronoun-reveal");

peopleExploreMorePronoun?.addEventListener("click", () => {

    if (!peopleExploreMorePronounReveal) {
        return;
    }

    const isHidden = peopleExploreMorePronounReveal.hasAttribute("hidden");

    if (isHidden) {
        peopleExploreMorePronounReveal.removeAttribute("hidden");
        peopleExploreMorePronoun.textContent = "Hide";
    } else {
        peopleExploreMorePronounReveal.setAttribute("hidden", "");
        peopleExploreMorePronoun.textContent = "Explore More";
    }

});


// ==================================================
// EXPLORE — DOOR 2
// DISCOVERY FOUR — BUILD THE SENTENCE (TAP TO PLACE)
// ==================================================

const peopleBlanks =
    Array.from(document.querySelectorAll("#people-discovery-4 .explore-construct__blank"));

const peopleConstructTiles =
    Array.from(document.querySelectorAll("#people-discovery-4 .explore-construct__tile"));

const peopleReveal4 =
    document.querySelector("#people-reveal-4");

const peopleMeaning4 =
    document.querySelector("#people-meaning-4");

// Tracks which tile element currently fills each blank, so the exact
// tile (not just a matching word) returns to the bank when cleared.
const peopleBlankFill = new Map();

function fillPeopleBlank(blank, tile) {
    blank.textContent = tile.dataset.word;
    blank.classList.add("is-filled");
    tile.classList.add("is-used");
    peopleBlankFill.set(blank, tile);
}

function clearPeopleBlank(blank) {
    const tile = peopleBlankFill.get(blank);
    if (tile) {
        tile.classList.remove("is-used");
    }
    peopleBlankFill.delete(blank);
    blank.textContent = "?";
    blank.classList.remove("is-filled");
}

peopleConstructTiles.forEach((tile) => {
    tile.addEventListener("click", () => {

        if (tile.classList.contains("is-used")) {
            return;
        }

        const nextBlank = peopleBlanks.find((b) => !b.classList.contains("is-filled"));

        if (!nextBlank) {
            return;
        }

        fillPeopleBlank(nextBlank, tile);

    });
});

peopleBlanks.forEach((blank) => {
    blank.addEventListener("click", () => {

        if (blank.classList.contains("is-filled")) {
            clearPeopleBlank(blank);
        }

    });
});

peopleReveal4?.addEventListener("click", () => {

    const unfilled = peopleBlanks.filter((b) => !b.classList.contains("is-filled"));

    if (unfilled.length > 0) {

        unfilled.forEach((blank) => {
            blank.classList.add("explore-construct__blank--nudge");
            setTimeout(() => {
                blank.classList.remove("explore-construct__blank--nudge");
            }, 600);
        });

        return;
    }

    if (!peopleMeaning4) {
        return;
    }

    peopleMeaning4.hidden = false;

    peopleMeaning4.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

});


// ==================================================
// EXPLORE — DOOR 2
// DISCOVERY SIX — REVEAL
// (Discovery Five is reflective — no reveal state to manage.)
// ==================================================

const peopleMeaningTetushka =
    document.querySelector("#people-meaning-tetushka");

const peopleReasoningTetushka =
    document.querySelector("#people-reasoning-tetushka");

const peopleMeaningDyadyushka =
    document.querySelector("#people-meaning-dyadyushka");

const peopleReasoningDyadyushka =
    document.querySelector("#people-reasoning-dyadyushka");

const peopleReveal6 =
    document.querySelector("#people-reveal-6");

const peopleMeaning6 =
    document.querySelector("#people-meaning-6");

peopleReveal6?.addEventListener("click", () => {

    if (!peopleMeaning6) {
        return;
    }

    peopleMeaning6.hidden = false;

    peopleMeaning6.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });

});


// ==================================================
// EXPLORE — DOOR 2
// RESTORE THIS DOOR
// ==================================================

document
    .querySelectorAll("#explore-people .explore-reset-room")
    .forEach((button) => {

        button.addEventListener("click", () => {

            // Stop any Russian audio that may be playing.
            window.speechSynthesis?.cancel?.();

            const predictions = [
                peoplePrediction1, peoplePrediction2, peoplePrediction3,
                peopleMeaningTetushka, peopleReasoningTetushka,
                peopleMeaningDyadyushka, peopleReasoningDyadyushka
            ];

            predictions.forEach((field) => {
                if (field) {
                    field.value = "";
                }
            });

            const meanings = [
                peopleMeaning1, peopleMeaning2, peopleMeaning3,
                peopleMeaning4, peopleMeaning6
            ];

            meanings.forEach((meaning) => {
                if (meaning) {
                    meaning.hidden = true;
                }
            });

            peopleBlanks.forEach((blank) => clearPeopleBlank(blank));

            if (peopleExploreMoreEndingsReveal) {
                peopleExploreMoreEndingsReveal.setAttribute("hidden", "");
            }

            if (peopleExploreMoreEndings) {
                peopleExploreMoreEndings.textContent = "🍬 Explore More";
            }

            if (peopleExploreMorePronounReveal) {
                peopleExploreMorePronounReveal.setAttribute("hidden", "");
            }

            if (peopleExploreMorePronoun) {
                peopleExploreMorePronoun.textContent = "Explore More";
            }

            resetDoorTwoVault();

            // ------------------------------------------
            // RETURN TO THE TOP OF DOOR 2
            // ------------------------------------------

            if (explorePeopleRoom) {

                explorePeopleRoom.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    });


// ==================================================
// EXPLORE — DOOR 3
// WHERE CAN THIS TAKE ME?
// ==================================================

const exploreConversationRoom =
    document.querySelector("#explore-conversation");


// Open Door 3 — Where Can This Take Me?
document
    .querySelector('.explore-door[data-door="conversation"]')
    ?.addEventListener("click", () => {

        if (exploreHallway) {
            exploreHallway.hidden = true;
        }

        if (exploreConversationRoom) {
            exploreConversationRoom.hidden = false;

            exploreConversationRoom.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }

    });


// Return from Door 3 to the EXPLORE hallway
document
    .querySelectorAll("#explore-conversation .explore-return-hallway")
    .forEach((button) => {

        button.addEventListener("click", () => {

            if (exploreConversationRoom) {
                exploreConversationRoom.hidden = true;
            }

            if (exploreHallway) {
                exploreHallway.hidden = false;

                exploreHallway.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }

        });

    });



// ==================================================
// DOOR 3 — PIRATE PORTRAITS
// Every portrait spot has a "role" (hero, sister, family, ...). Each role
// belongs to one group (male, female, or a fixed group picture). When the
// page loads, the faces in each group are shuffled and handed out to the
// roles, so the cast changes from visit to visit but stays steady while
// the learner clicks around.
// ==================================================

const PIRATE_FOLDER = "../../Images/door-three/";

const PIRATE_FILES = {
    male: ["image-pirate-male-1.png", "image-pirate-male-2.png", "image-pirate-male-3.png",
        "image-pirate-male-4.png", "image-pirate-male-5.png"],
    female: ["image-pirate-female-1.png", "image-pirate-female-2.png", "image-pirate-female-3.png",
        "image-pirate-female-4.png", "image-pirate-female-5.png"],
    family: ["image-pirate-family.png"],
    children: ["image-pirate-children.png"],
    kids: ["image-pirate-bro-sis.png", "image-pirate-bro-sis-2.png"],
    they: ["image-pirate-they-have-a-sister.png"],
    sisters: ["image-pirate-two-sisters.png"]
};

// Which group each role belongs to
const PIRATE_ROLES = {
    // male faces
    hero: "male", i: "male", he: "male", brother: "male", "older-brother": "male",
    father: "male", grandfather: "male", uncle: "male", cousin: "male", son: "male", "boat-boy": "male",
    // female faces
    scarf: "female", you: "female", she: "female", sister: "female", "younger-sister": "female",
    mother: "female", grandmother: "female", aunt: "female", daughter: "female",
    // group pictures
    family: "family", "family-large": "family", parents: "family",
    "family-small": "kids", we: "kids",
    children: "children", grandchildren: "children",
    they: "they"
};

const PIRATE_CAST = {};

// Shuffle a copy of a list
function pirateShuffle(list) {
    const copy = list.slice();
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}

// Hand out faces: each role in a group gets the next face in that group's
// shuffled deck. If a group has more roles than faces, the deck starts over.
(function castPirates() {

    const decks = {};
    const spot = {};

    Object.keys(PIRATE_ROLES).forEach((role) => {

        const group = PIRATE_ROLES[role];

        if (!decks[group] || spot[group] >= decks[group].length) {
            decks[group] = pirateShuffle(PIRATE_FILES[group]);
            spot[group] = 0;
        }

        PIRATE_CAST[role] = decks[group][spot[group]];
        spot[group] += 1;

    });

})();

// The picture address for a role (hero, sister, family, ...)
function pirateUrl(role) {
    const file = PIRATE_CAST[role];
    return file ? `url("${PIRATE_FOLDER}${file}")` : "";
}

// Fill in every portrait spot that names its role in data-pirate
document.querySelectorAll("[data-pirate]").forEach((spot) => {
    spot.style.backgroundImage = pirateUrl(spot.dataset.pirate);
});

// ==================================================
// DOOR 3 — THE COMPASS & MAP
// CONTROLLED-RANDOM COMPASS (NO REPEATS UNTIL ALL FOUR APPEAR)
// ==================================================

const compassMapScreen = document.querySelector("#compass-map");
const compassDiscoveryScreen = document.querySelector("#compass-discovery");
const compassDial = document.querySelector("#compass-dial");
const compassNeedle = document.querySelector("#compass-needle");
const compassPrompt = document.querySelector("#compass-prompt");
const compassMarkers = document.querySelectorAll(".compass-marker");

// Where the needle points for each direction (0° = straight up = North)
const COMPASS_ANGLES = { north: 0, east: 90, south: 180, west: 270 };

const COMPASS_TITLES = {
    north: { sign: "NORTH", title: "I Have a Family Member", sub: "Learn the basic form: У меня есть …" },
    east: { sign: "EAST", title: "What If I Don't Have One?", sub: "" },
    south: { sign: "SOUTH", title: "Wait… Do We Always Need есть?", sub: "" },
    west: { sign: "WEST", title: "Talking About Other People", sub: "" }
};

// SHUFFLE BAG. To the learner every spin looks random, but behind the scenes
// the compass deals from a pre-shuffled "bag": three cycles of all four
// directions, each cycle in its own random order. No direction repeats
// until all four have been dealt in that cycle.
const COMPASS_CYCLES_PER_BAG = 3;

let compassBag = [];

// The needle's total rotation so far. It only ever grows,
// so the needle always keeps spinning forward and never rewinds.
let compassTotalAngle = 0;

let compassSpinning = false;
let compassLitDirection = null;


// Fisher–Yates shuffle of one copy of the four directions
function shuffledCompassCycle() {

    const cycle = Object.keys(COMPASS_ANGLES);

    for (let i = cycle.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cycle[i], cycle[j]] = [cycle[j], cycle[i]];
    }

    return cycle;

}


// Fill the bag with several shuffled cycles, back to back.
// A new cycle never opens with the direction that closed the one before it.
function refillCompassBag(lastDealt) {

    compassBag = [];
    let previous = lastDealt || null;

    for (let n = 0; n < COMPASS_CYCLES_PER_BAG; n++) {

        const cycle = shuffledCompassCycle();

        if (previous && cycle[0] === previous) {
            [cycle[0], cycle[1]] = [cycle[1], cycle[0]];
        }

        compassBag.push(...cycle);
        previous = cycle[cycle.length - 1];

    }

}


// Deal the next direction. Clicking the compass again, even before the
// glowing marker has been visited, simply deals the next one.
function drawCompassDirection() {

    if (compassBag.length === 0) {
        refillCompassBag(compassLastDealt);
    }

    compassLastDealt = compassBag[0];

    return compassBag.shift();

}

let compassLastDealt = null;


function setCompassPrompt(text) {
    if (compassPrompt) {
        compassPrompt.textContent = text;
    }
}


// Turn every marker back to its quiet, unlit state
function clearCompassGlow() {

    compassMarkers.forEach((marker) => {
        marker.classList.remove("is-lit");
        marker.disabled = true;
    });

    compassLitDirection = null;

}


// Light one marker and make it clickable
function lightCompassMarker(direction) {

    clearCompassGlow();

    const marker =
        document.querySelector(`.compass-marker[data-direction="${direction}"]`);

    if (marker) {
        marker.classList.add("is-lit");
        marker.disabled = false;
    }

    compassLitDirection = direction;

    setCompassPrompt("Follow the glow — click the lit direction on the map.");

}


// Spin the needle to the chosen direction, then light that marker
function spinCompass() {

    // Ignore clicks only while the needle is spinning.
    // A glowing marker does not block the compass: click again to choose again.
    if (compassSpinning) {
        return;
    }

    const direction = drawCompassDirection();

    // The old glow goes quiet while the needle chooses
    clearCompassGlow();

    const reduceMotion =
        window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Three full turns, then land exactly on the chosen direction
    const currentPosition = compassTotalAngle % 360;
    const distanceToTarget =
        (COMPASS_ANGLES[direction] - currentPosition + 360) % 360;

    compassTotalAngle += (reduceMotion ? 0 : 360 * 3) + distanceToTarget;

    const spinSeconds = reduceMotion ? 0.3 : 3.4;

    compassSpinning = true;
    setCompassPrompt("The compass is choosing…");

    if (compassNeedle) {
        compassNeedle.style.transition =
            `transform ${spinSeconds}s cubic-bezier(0.12, 0.7, 0.2, 1)`;
        compassNeedle.style.transform = `rotate(${compassTotalAngle}deg)`;
    }

    // Light the marker once the spin has finished
    window.setTimeout(() => {
        compassSpinning = false;
        lightCompassMarker(direction);
    }, spinSeconds * 1000 + 150);

}

compassDial?.addEventListener("click", spinCompass);



// Show the shared cabin screen with the right sign and content
function showCompassDiscovery(direction) {

    const info = COMPASS_TITLES[direction];

    const signImage = document.querySelector("#cd-sign-img");
    const title = document.querySelector("#cd-title");
    const sub = document.querySelector("#cd-sub");

    // The sign is a picture: directional-marker-title-N / S / E / W
    if (signImage) {
        signImage.src =
            `../../Images/door-three/directional-marker-title-${direction.charAt(0).toUpperCase()}.png`;
    }

    if (title) title.textContent = info.title;
    if (sub) sub.textContent = info.sub;

    // Show this direction's content, or the "coming next" panel
    const hasContent =
        document.querySelector(`.cd-content[data-content="${direction}"]`);

    document.querySelectorAll(".cd-content").forEach((block) => {
        const wanted = hasContent ? direction : "soon";
        block.hidden = block.dataset.content !== wanted;
    });

}

// Click a glowing marker → enter that direction's discovery
compassMarkers.forEach((marker) => {

    marker.addEventListener("click", () => {

        const direction = marker.dataset.direction;
        const info = COMPASS_TITLES[direction];

        if (!info || marker.disabled) {
            return;
        }

        showCompassDiscovery(direction);

        showCompassScreen(compassDiscoveryScreen);

    });

});



// ==================================================
// DOOR 3 — NORTH DISCOVERY
// I HAVE A FAMILY MEMBER:  У меня есть …
// ==================================================

const NORTH_FAMILY = [
    { label: "Brother (брат)", ru: "брат", en: "a brother" },
    { label: "Sister (сестра)", ru: "сестра", en: "a sister" },
    { label: "Father (папа)", ru: "папа", en: "a father" },
    { label: "Mother (мама)", ru: "мама", en: "a mother" },
    { label: "Grandfather (дедушка)", ru: "дедушка", en: "a grandfather" },
    { label: "Grandmother (бабушка)", ru: "бабушка", en: "a grandmother" },
    { label: "Uncle (дядя)", ru: "дядя", en: "an uncle" },
    { label: "Aunt (тётя)", ru: "тётя", en: "an aunt" },
    { label: "Cousin (двоюродный брат/сестра)", ru: "двоюродный брат", en: "a cousin" },
    { label: "Son (сын)", ru: "сын", en: "a son" },
    { label: "Daughter (дочь)", ru: "дочь", en: "a daughter" },
    { label: "Parents (родители)", ru: "родители", en: "parents" },
    { label: "Children (дети)", ru: "дети", en: "children" },
    { label: "Grandchildren (внуки)", ru: "внуки", en: "grandchildren" },
    { label: "Family (семья)", ru: "семья", en: "a family" }
];

const northSelect = document.querySelector("#north-select");

// Put the word "есть" in a highlighted span
function northHighlight(text) {
    return text.replace("есть", '<span class="cd-hl">есть</span>');
}

// The English half of each sentence
function northEnglish(member) {
    return member.en;
}

function renderNorth() {

    if (!northSelect) return;

    const member = NORTH_FAMILY[Number(northSelect.value)] || NORTH_FAMILY[0];

    const sentenceRu = `У меня есть ${member.ru}.`;
    const questionRu = `У вас есть ${member.ru}?`;
    const answerRu = `Да, у меня есть ${member.ru}.`;

    document.querySelector("#north-sentence").innerHTML = northHighlight(sentenceRu);
    document.querySelector("#north-sentence-en").textContent = `I have ${member.en}.`;

    document.querySelector("#north-tile-ru").textContent = member.ru;
    document.querySelector("#north-tile-en").textContent = member.en;

    document.querySelector("#north-q").innerHTML = northHighlight(questionRu);
    document.querySelector("#north-q-en").textContent = `Do you have ${member.en}?`;

    document.querySelector("#north-a").innerHTML = northHighlight(answerRu);
    document.querySelector("#north-a-en").textContent = `Yes, I have ${member.en}.`;

}

if (northSelect) {

    NORTH_FAMILY.forEach((member, index) => {
        const option = document.createElement("option");
        option.value = String(index);
        option.textContent = member.label;
        northSelect.appendChild(option);
    });

    northSelect.addEventListener("change", renderNorth);
    renderNorth();

    // Hear buttons read the text that is on the screen right now
    [
        ["#north-speak-sentence", "#north-sentence"],
        ["#north-speak-q", "#north-q"],
        ["#north-speak-a", "#north-a"]
    ].forEach(([buttonSelector, textSelector]) => {
        document.querySelector(buttonSelector)?.addEventListener("click", () => {
            speakRussianWord(document.querySelector(textSelector).textContent);
        });
    });

}


// ==================================================
// DOOR 3 — SOUTH DISCOVERY
// DO WE ALWAYS NEED есть?
// ==================================================

// g = grammatical gender (m / f). "more" lists the "Tell me more" choices
// that sound natural for that person.
const SOUTH_PEOPLE = [
    { label: "Brother (брат)", ru: "брат", en: "brother", g: "m", more: ["older", "younger", "twin"] },
    { label: "Sister (сестра)", ru: "сестра", en: "sister", g: "f", more: ["older", "younger", "twin"] },
    { label: "Father (папа)", ru: "папа", en: "father", g: "m", more: [] },
    { label: "Mother (мама)", ru: "мама", en: "mother", g: "f", more: [] },
    { label: "Grandfather (дедушка)", ru: "дедушка", en: "grandfather", g: "m", more: [] },
    { label: "Grandmother (бабушка)", ru: "бабушка", en: "grandmother", g: "f", more: [] },
    { label: "Uncle (дядя)", ru: "дядя", en: "uncle", g: "m", more: [] },
    { label: "Aunt (тётя)", ru: "тётя", en: "aunt", g: "f", more: [] },
    { label: "Cousin (двоюродный брат)", ru: "двоюродный брат", en: "cousin", g: "m", more: ["older", "younger"] },
    { label: "Son (сын)", ru: "сын", en: "son", g: "m", more: ["older", "younger"] },
    { label: "Daughter (дочь)", ru: "дочь", en: "daughter", g: "f", more: ["older", "younger"] }
];

const southWho = document.querySelector("#south-who");
const southMore = document.querySelector("#south-more");

// The wording of each "Tell me more" choice, for a masculine or feminine person
function southModifier(kind, person) {

    const feminine = person.g === "f";

    if (kind === "older") return { ru: feminine ? "старшая" : "старший", en: "an older" };
    if (kind === "younger") return { ru: feminine ? "младшая" : "младший", en: "a younger" };
    if (kind === "twin") {
        return {
            ru: null,
            noun: feminine ? "сестра-близнец" : "брат-близнец",
            en: "a twin"
        };
    }
    return null;

}

function southMoreLabel(kind, person) {

    const none = { none: "Just say I have one" };

    if (kind === "none") return none.none;

    if (kind === "twin") {
        return `Twin (${person.g === "f" ? "сестра-близнец" : "брат-близнец"})`;
    }

    const word = southModifier(kind, person).ru;
    return `${kind === "older" ? "Older" : "Younger"} (${word})`;

}

// Rebuild the "Tell me more" menu so it only offers natural choices for this person
function fillSouthMore(keepValue) {

    const person = SOUTH_PEOPLE[Number(southWho.value)];
    const kinds = ["none", ...person.more];

    southMore.innerHTML = "";

    kinds.forEach((kind) => {
        const option = document.createElement("option");
        option.value = kind;
        option.textContent = southMoreLabel(kind, person);
        southMore.appendChild(option);
    });

    southMore.value = kinds.includes(keepValue) ? keepValue : "none";

}

function renderSouth() {

    const person = SOUTH_PEOPLE[Number(southWho.value)];
    const kind = southMore.value;
    const mod = southModifier(kind, person);

    let ru;
    let en;

    if (!mod) {
        // Just say I have one → есть appears
        ru = `У меня <span class="cd-hl">есть</span> ${person.ru}.`;
        en = `I have a${"aeiou".includes(person.en[0]) ? "n" : ""} ${person.en}.`;
    } else if (mod.noun) {
        // Twin → the noun itself changes, есть drops out
        const twinNoun = person.g === "f" ? "сестра-близнец" : "брат-близнец";
        ru = `У меня <span class="cd-hl cd-hl--yellow">${twinNoun}</span>.`;
        en = `I have ${mod.en} ${person.en}.`;
    } else {
        ru = `У меня <span class="cd-hl cd-hl--yellow">${mod.ru}</span> ${person.ru}.`;
        en = `I have ${mod.en} ${person.en}.`;
    }

    document.querySelector("#south-sentence").innerHTML = ru;
    document.querySelector("#south-sentence-en").textContent = en;

}

if (southWho && southMore) {

    SOUTH_PEOPLE.forEach((person, index) => {
        const option = document.createElement("option");
        option.value = String(index);
        option.textContent = person.label;
        southWho.appendChild(option);
    });

    fillSouthMore("none");
    renderSouth();

    southWho.addEventListener("change", () => {
        fillSouthMore(southMore.value);
        renderSouth();
    });

    southMore.addEventListener("change", renderSouth);

    // Try Another: pick a different, natural-sounding combination at random
    document.querySelector("#south-another")?.addEventListener("click", () => {

        const combos = [];

        SOUTH_PEOPLE.forEach((person, index) => {
            ["none", ...person.more].forEach((kind) => {
                combos.push({ index, kind });
            });
        });

        const current = {
            index: Number(southWho.value),
            kind: southMore.value
        };

        const others = combos.filter(
            (c) => !(c.index === current.index && c.kind === current.kind)
        );

        const next = others[Math.floor(Math.random() * others.length)];

        southWho.value = String(next.index);
        fillSouthMore(next.kind);
        renderSouth();

    });

    document.querySelector("#south-speak")?.addEventListener("click", () => {
        speakRussianWord(document.querySelector("#south-sentence").textContent);
    });

}

// Every example sentence on the South screen has its own Hear button
document.querySelectorAll('.cd-content[data-content="south"] .cd-speak[data-say]').forEach((button) => {
    button.addEventListener("click", () => {
        speakRussianWord(button.dataset.say);
    });
});


// ==================================================
// DOOR 3 — EAST DISCOVERY
// WHAT IF I DON'T HAVE ONE?   У меня нет … (+ the family word changes)
// ==================================================

// "gen" is the family word after нет (genitive). We only ask the learner to NOTICE it.
const EAST_PEOPLE = [
    { key: "brother", label: "Brother (брат)", gen: "брата", en: "a brother" },
    { key: "sister", label: "Sister (сестра)", gen: "сестры", en: "a sister" },
    { key: "father", label: "Father (отец)", gen: "отца", en: "a father" },
    { key: "mother", label: "Mother (мать)", gen: "матери", en: "a mother" },
    { key: "grandfather", label: "Grandfather (дедушка)", gen: "дедушки", en: "a grandfather" },
    { key: "grandmother", label: "Grandmother (бабушка)", gen: "бабушки", en: "a grandmother" },
    { key: "uncle", label: "Uncle (дядя)", gen: "дяди", en: "an uncle" },
    { key: "aunt", label: "Aunt (тётя)", gen: "тёти", en: "an aunt" },
    { key: "cousin", label: "Cousin (двоюродный брат)", gen: "двоюродного брата", en: "a cousin" },
    { key: "son", label: "Son (сын)", gen: "сына", en: "a son" },
    { key: "daughter", label: "Daughter (дочь)", gen: "дочери", en: "a daughter" },
    { key: "parents", label: "Parents (родители)", gen: "родителей", en: "parents" },
    { key: "children", label: "Children (дети)", gen: "детей", en: "children" },
    { key: "grandchildren", label: "Grandchildren (внуки)", gen: "внуков", en: "grandchildren" }
];

// Two choosers: "a" drives the main sentence, "b" is "try another person"
const eastState = { a: 0, b: 1 };

function eastSentence(person) {
    return `У меня нет ${person.gen}.`;
}

function renderEast() {

    ["a", "b"].forEach((side) => {

        const person = EAST_PEOPLE[eastState[side]];
        const portrait = document.querySelector(`#east-${side}-portrait`);
        const select = document.querySelector(`#east-${side}-select`);

        if (select) select.value = String(eastState[side]);

        // Show this person's pirate face
        if (portrait) {
            portrait.style.backgroundImage = pirateUrl(person.key);
        }

    });

    const personA = EAST_PEOPLE[eastState.a];
    const personB = EAST_PEOPLE[eastState.b];

    const sentence = document.querySelector("#east-sentence");
    const sentenceEn = document.querySelector("#east-sentence-en");
    const sentenceB = document.querySelector("#east-sentence-b");

    if (sentence) {
        sentence.innerHTML =
            eastSentence(personA).replace("нет", '<span class="cd-hl cd-hl--red">нет</span>');
    }

    if (sentenceEn) {
        sentenceEn.textContent = `I don't have ${personA.en}.`;
    }

    if (sentenceB) {
        sentenceB.innerHTML =
            eastSentence(personB).replace("нет", '<span class="cd-hl cd-hl--red">нет</span>');
    }

}

if (document.querySelector("#east-a-select")) {

    ["a", "b"].forEach((side) => {

        const select = document.querySelector(`#east-${side}-select`);

        EAST_PEOPLE.forEach((person, index) => {
            const option = document.createElement("option");
            option.value = String(index);
            option.textContent = person.label;
            select.appendChild(option);
        });

        select.addEventListener("change", () => {
            eastState[side] = Number(select.value);
            renderEast();
        });

        // Arrows step through the people and wrap around at the ends
        document.querySelector(`#east-${side}-prev`)?.addEventListener("click", () => {
            eastState[side] = (eastState[side] - 1 + EAST_PEOPLE.length) % EAST_PEOPLE.length;
            renderEast();
        });

        document.querySelector(`#east-${side}-next`)?.addEventListener("click", () => {
            eastState[side] = (eastState[side] + 1) % EAST_PEOPLE.length;
            renderEast();
        });

    });

    document.querySelector("#east-hear-a")?.addEventListener("click", () => {
        speakRussianWord(eastSentence(EAST_PEOPLE[eastState.a]));
    });

    document.querySelector("#east-hear-b")?.addEventListener("click", () => {
        speakRussianWord(eastSentence(EAST_PEOPLE[eastState.b]));
    });

    renderEast();

}


// ==================================================
// DOOR 3 — WEST DISCOVERY
// TALKING ABOUT OTHER PEOPLE:  у меня / у тебя / у него / у неё / у нас / у них + есть
// ==================================================

const WEST_PEOPLE = [
    { key: "i", ru: "у меня", en: "I", subject: "I", verb: "have" },
    { key: "you", ru: "у тебя", en: "you", subject: "You", verb: "have" },
    { key: "he", ru: "у него", en: "he", subject: "He", verb: "has" },
    { key: "she", ru: "у неё", en: "she", subject: "She", verb: "has" },
    { key: "we", ru: "у нас", en: "we", subject: "We", verb: "have" },
    { key: "they", ru: "у них", en: "they", subject: "They", verb: "have" }
];

const WEST_MEMBERS = [
    { key: "brother", ru: "брат", en: "a brother" },
    { key: "sister", ru: "сестра", en: "a sister" },
    { key: "father", ru: "папа", en: "a father" },
    { key: "mother", ru: "мама", en: "a mother" },
    { key: "grandfather", ru: "дедушка", en: "a grandfather" },
    { key: "grandmother", ru: "бабушка", en: "a grandmother" },
    { key: "uncle", ru: "дядя", en: "an uncle" },
    { key: "aunt", ru: "тётя", en: "an aunt" },
    { key: "cousin", ru: "двоюродный брат", en: "a cousin" },
    { key: "son", ru: "сын", en: "a son" },
    { key: "daughter", ru: "дочь", en: "a daughter" },
    { key: "parents", ru: "родители", en: "parents" },
    { key: "children", ru: "дети", en: "children" },
    { key: "grandchildren", ru: "внуки", en: "grandchildren" },
    { key: "family", ru: "семья", en: "a family" }
];

// Start on "he" + "sister", like the concept picture
const westState = { p: 2, m: 1 };

function westSentenceRu() {
    return `${WEST_PEOPLE[westState.p].ru[0].toUpperCase()}${WEST_PEOPLE[westState.p].ru.slice(1)} есть ${WEST_MEMBERS[westState.m].ru}.`;
}

function renderWest() {

    const person = WEST_PEOPLE[westState.p];
    const member = WEST_MEMBERS[westState.m];

    const setPortrait = (id, role) => {
        const el = document.querySelector(id);
        if (el) el.style.backgroundImage = pirateUrl(role);
    };

    setPortrait("#west-p-portrait", person.key);
    setPortrait("#west-m-portrait", member.key);

    document.querySelector("#west-p-ru").textContent = person.ru;
    document.querySelector("#west-p-en").textContent = person.en;
    document.querySelector("#west-m-ru").textContent = member.ru;
    document.querySelector("#west-m-en").textContent = member.en;

    const beginning = `${person.ru[0].toUpperCase()}${person.ru.slice(1)}`;

    document.querySelector("#west-sentence").innerHTML =
        `<span class="cd-hl cd-hl--yellow">${beginning}</span> <span class="cd-hl">есть</span> ${member.ru}.`;

    document.querySelector("#west-sentence-en").textContent =
        `${person.subject} ${person.verb} ${member.en}.`;

}

if (document.querySelector("#west-p-prev")) {

    // Arrows step through the choices and wrap around at the ends
    const wire = (side, list) => {
        document.querySelector(`#west-${side}-prev`)?.addEventListener("click", () => {
            westState[side] = (westState[side] - 1 + list.length) % list.length;
            renderWest();
        });
        document.querySelector(`#west-${side}-next`)?.addEventListener("click", () => {
            westState[side] = (westState[side] + 1) % list.length;
            renderWest();
        });
    };

    wire("p", WEST_PEOPLE);
    wire("m", WEST_MEMBERS);

    document.querySelector("#west-hear")?.addEventListener("click", () => {
        speakRussianWord(westSentenceRu());
    });

    renderWest();

}


// Show only the Map Room (hide every discovery and boat screen)
function showCompassMap() {

    tcReset();

    document
        .querySelectorAll("#explore-conversation .compass-screen")
        .forEach((screen) => {
            screen.hidden = screen !== compassMapScreen;
        });

    exploreConversationRoom?.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}

// Show one screen on its own (a discovery or a boat)
function showCompassScreen(screen) {

    document
        .querySelectorAll("#explore-conversation .compass-screen")
        .forEach((each) => {
            each.hidden = each !== screen;
        });

    exploreConversationRoom?.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


// ==================================================
// DOOR 3 — THE FOUR BOATS
// Optional side trips. Clicking a boat on the map opens its screen.
// "Back to the Map Room" returns to the map WITHOUT ending the compass glow,
// because the boats are separate from the compass.
// ==================================================

const BOAT_RESETTERS = {};

document.querySelectorAll(".compass-boat").forEach((boat) => {

    boat.addEventListener("click", () => {

        const screen = document.querySelector(`#boat-${boat.dataset.boat}`);

        if (!screen) {
            return;
        }

        // Every visit starts fresh
        BOAT_RESETTERS[boat.dataset.boat]?.();

        showCompassScreen(screen);

    });

});

document.querySelectorAll("#explore-conversation .compass-boat-back").forEach((button) => {
    button.addEventListener("click", showCompassMap);
});

// Show Me Why / Hide This Explanation (same button, same screen)
document.querySelectorAll(".boat-screen").forEach((screen) => {

    const toggle = screen.querySelector("[data-why-toggle]");
    const why = screen.querySelector(".bt-why");

    if (!toggle || !why) {
        return;
    }

    const setWhy = (open) => {
        why.hidden = !open;
        screen.classList.toggle("is-why-open", open);
        toggle.setAttribute("aria-label", open ? toggle.dataset.hide : toggle.dataset.show);
    };

    toggle.addEventListener("click", () => setWhy(why.hidden));

    screen.querySelector("[data-why-close]")?.addEventListener("click", () => setWhy(false));

    // Used when the boat screen is reset
    screen._closeWhy = () => setWhy(false);

});


// ---------- NORTH BOAT: THE NAVIGATOR'S STUDY ----------

const bnPics = [
    {
        box: document.querySelector("#bn-pic-1"),
        feedback: document.querySelector("#bn-feedback-1"),
        right: ["Correct!", "The picture shows a brother. Notice: брат stays the same after есть."],
        wrong: ["Not quite. Look again!", "This picture shows a brother. Which sentence says you have a brother?"]
    },
    {
        box: document.querySelector("#bn-pic-2"),
        feedback: document.querySelector("#bn-feedback-2"),
        right: ["Correct!", "Notice how брат changes to брата after нет."],
        wrong: ["Not quite. Look again!", "This picture shows someone who isn't here. Which sentence says you don't have a brother?"]
    }
];

function bnShowFeedback(pic, good, lines) {

    pic.feedback.hidden = false;
    pic.feedback.className = `bt-feedback ${pic.box.classList.contains("bt-pic--left") ? "bt-feedback--left" : "bt-feedback--right"} ${good ? "is-good" : "is-hint"}`;
    pic.feedback.innerHTML = `<strong>${good ? "✓" : "💡"} ${lines[0]}</strong> ${lines[1]}`;

}

bnPics.forEach((pic) => {

    if (!pic.box) {
        return;
    }

    pic.box.querySelectorAll(".bt-choice").forEach((button) => {

        button.addEventListener("click", () => {

            if (pic.box.classList.contains("is-solved")) {
                return;
            }

            if (button.dataset.answer === pic.box.dataset.correct) {

                button.classList.add("is-correct");
                pic.box.classList.add("is-solved");
                pic.box.querySelectorAll(".bt-choice").forEach((each) => { each.disabled = true; });
                bnShowFeedback(pic, true, pic.right);

                // Both pictures solved → show the discovery
                if (bnPics.every((each) => each.box.classList.contains("is-solved"))) {
                    document.querySelector("#bn-found").hidden = false;
                }

            } else {

                // Amber glow for a moment, then the learner can try again
                button.classList.add("is-wrong");
                window.setTimeout(() => button.classList.remove("is-wrong"), 1200);
                bnShowFeedback(pic, false, pic.wrong);

            }

        });

    });

});

BOAT_RESETTERS.north = () => {

    bnPics.forEach((pic) => {
        pic.box?.classList.remove("is-solved");
        pic.box?.querySelectorAll(".bt-choice").forEach((button) => {
            button.disabled = false;
            button.classList.remove("is-correct", "is-wrong");
        });
        if (pic.feedback) pic.feedback.hidden = true;
    });

    const found = document.querySelector("#bn-found");
    if (found) found.hidden = true;

    document.querySelector("#boat-north")?._closeWhy?.();

};


// ---------- SOUTH BOAT: THE CAPTAIN'S FAMILY CABIN ----------

const bsCards = document.querySelectorAll("#boat-south .bs-round .bs-card");

function bsRoundSolved(roundId) {
    return [...document.querySelectorAll(`#${roundId} .bs-card`)]
        .every((card) => card.classList.contains("is-solved"));
}

bsCards.forEach((card) => {

    card.querySelectorAll(".bs-choice").forEach((button) => {

        button.addEventListener("click", () => {

            if (card.classList.contains("is-solved")) {
                return;
            }

            const result = card.querySelector(".bs-card__result");

            if (button.dataset.form === card.dataset.correct) {

                button.classList.add("is-correct");
                card.classList.add("is-solved");
                card.querySelectorAll(".bs-choice").forEach((each) => { each.disabled = true; });

                // The complete phrase appears
                result.innerHTML =
                    `<strong>${card.dataset.phrase}</strong><br><small>(${card.dataset.phraseEn})</small>`;
                result.classList.remove("is-hint");

                if (bsRoundSolved("bs-round-1") && !document.querySelector("#bs-round-1").hidden) {
                    document.querySelector("#bs-cheer-1").hidden = false;
                }

                if (bsRoundSolved("bs-round-2") && !document.querySelector("#bs-round-2").hidden) {
                    document.querySelector("#bs-cheer-2").hidden = false;
                }

            } else {

                // A colour flash and a friendly nudge. No penalty.
                button.classList.add("is-wrong");
                window.setTimeout(() => button.classList.remove("is-wrong"), 1200);

                result.classList.add("is-hint");
                result.textContent =
                    card.querySelector(".bs-card__word").textContent === "папа"
                        ? "Try again! папа ends in -а, but think about who he is."
                        : "Not quite. Try another form of “my.”";

            }

        });

    });

});

// Round 1 → round 2
document.querySelector("#bs-next")?.addEventListener("click", () => {

    document.querySelector("#bs-round-1").hidden = true;
    document.querySelector("#bs-cheer-1").hidden = true;
    document.querySelector("#bs-round-2").hidden = false;

    document.querySelector("#bs-task").textContent =
        "Two more family words. Which form of “my” fits each one?";

});

BOAT_RESETTERS.south = () => {

    bsCards.forEach((card) => {
        card.classList.remove("is-solved");
        card.querySelectorAll(".bs-choice").forEach((button) => {
            button.disabled = false;
            button.classList.remove("is-correct", "is-wrong");
        });
        const result = card.querySelector(".bs-card__result");
        result.textContent = "";
        result.classList.remove("is-hint");
    });

    document.querySelector("#bs-round-1").hidden = false;
    document.querySelector("#bs-round-2").hidden = true;
    document.querySelector("#bs-cheer-1").hidden = true;
    document.querySelector("#bs-cheer-2").hidden = true;

    document.querySelector("#bs-task").textContent =
        "Click the correct form of “my” for each family member.";

    document.querySelector("#boat-south")?._closeWhy?.();

};


// ---------------------------------------------------------------
// EAST BOAT — The Traveler's Cargo Hold
// Six crates. Each opens to show two family members, their Russian
// and English words, and what the relationship means. No score.
// ---------------------------------------------------------------
const EAST_CRATES = {
    stepfamily: {
        title: "Stepfamily",
        people: [
            { role: "uncle", ru: "отчим", en: "stepfather" },
            { role: "aunt", ru: "мачеха", en: "stepmother" }
        ],
        meaning: "Your mother's husband, or your father's wife, who is not your birth parent."
    },
    greatgrand: {
        title: "Grandparents",
        people: [
            { role: "grandfather", ru: "прадедушка", en: "great-grandfather" },
            { role: "grandmother", ru: "прабабушка", en: "great-grandmother" }
        ],
        meaning: "Your grandparents' parents. Add пра- to the grandparent word."
    },
    husband: {
        title: "Husband's Parents",
        people: [
            { role: "he", ru: "свёкор", en: "father-in-law (husband's father)" },
            { role: "she", ru: "свекровь", en: "mother-in-law (husband's mother)" }
        ],
        meaning: "A wife's words for her husband's parents."
    },
    wife: {
        title: "Wife's Parents",
        people: [
            { role: "cousin", ru: "тесть", en: "father-in-law (wife's father)" },
            { role: "you", ru: "тёща", en: "mother-in-law (wife's mother)" }
        ],
        meaning: "A husband's words for his wife's parents."
    },
    stepsib: {
        title: "Step-Siblings",
        people: [
            { role: "boat-boy", ru: "сводный брат", en: "stepbrother" },
            { role: "younger-sister", ru: "сводная сестра", en: "stepsister" }
        ],
        meaning: "Children of your stepparent, who are not your birth siblings."
    },
    other: {
        title: "Other Relationships",
        people: [
            { role: "i", ru: "зять", en: "son-in-law" },
            { role: "daughter", ru: "невестка", en: "daughter-in-law" }
        ],
        meaning: "Married into the family. зять is also a sister's husband; невестка is also a brother's wife."
    }
};

const beCrateButtons = document.querySelectorAll("#boat-east .be-crate");
const beOpen = document.querySelector("#be-open");

function beOpenCrate(key) {

    const crate = EAST_CRATES[key];
    const box = document.querySelector(`#boat-east .be-crate[data-crate="${key}"]`);

    document.querySelector("#be-open-title").textContent = crate.title;
    document.querySelector("#be-open-meaning").textContent = crate.meaning;

    const holder = document.querySelector("#be-open-people");
    holder.innerHTML = "";

    crate.people.forEach((person) => {

        const card = document.createElement("div");
        card.className = "be-person";

        const portrait = document.createElement("div");
        portrait.className = "bs-card__portrait be-person__portrait";
        portrait.style.backgroundImage = pirateUrl(person.role);

        const ru = document.createElement("div");
        ru.className = "be-person__ru";
        ru.textContent = person.ru;

        const en = document.createElement("div");
        en.className = "be-person__en";
        en.textContent = `(${person.en})`;

        const hear = document.createElement("button");
        hear.type = "button";
        hear.className = "be-hear";
        hear.textContent = "🔊 Hear";
        hear.addEventListener("click", () => speakRussianWord(person.ru));

        card.append(portrait, ru, en, hear);
        holder.appendChild(card);

    });

    box.classList.add("is-opened");
    beOpen.hidden = false;
    document.querySelector("#boat-east").classList.add("is-crate-open");

}

function beCloseCrate() {
    beOpen.hidden = true;
    document.querySelector("#boat-east").classList.remove("is-crate-open");
}

beCrateButtons.forEach((button) => {
    button.addEventListener("click", () => beOpenCrate(button.dataset.crate));
});

document.querySelector("#be-close").addEventListener("click", beCloseCrate);

BOAT_RESETTERS.east = () => {

    beCrateButtons.forEach((button) => button.classList.remove("is-opened"));
    beCloseCrate();
    document.querySelector("#boat-east")?._closeWhy?.();

};


// ---------------------------------------------------------------
// WEST BOAT — The Conversation Deck
// Three short conversations: the pirate asks, you answer, you ask
// the question back, and the pirate answers. Repeatable.
// ---------------------------------------------------------------
const WEST_TALKS = [
    {
        role: "brother",
        ask: "У вас есть брат?", askEn: "Do you have a brother?",
        answers: [
            { ru: "Да, у меня есть брат.", en: "Yes, I have a brother." },
            { ru: "Нет, у меня нет брата.", en: "No, I don't have a brother." }
        ],
        reply: "У меня есть брат. Он капитан!", replyEn: "I have a brother. He is a captain!"
    },
    {
        role: "sister",
        ask: "У вас есть сестра?", askEn: "Do you have a sister?",
        answers: [
            { ru: "Да, у меня есть сестра.", en: "Yes, I have a sister." },
            { ru: "Нет, у меня нет сестры.", en: "No, I don't have a sister." }
        ],
        reply: "У меня есть сестра. Она штурман!", replyEn: "I have a sister. She is the navigator!"
    },
    {
        role: "children",
        ask: "У вас есть дети?", askEn: "Do you have children?",
        answers: [
            { ru: "Да, у меня есть дети.", en: "Yes, I have children." },
            { ru: "Нет, у меня нет детей.", en: "No, I don't have children." }
        ],
        reply: "У меня есть дети. Они матросы!", replyEn: "I have children. They are sailors!"
    }
];

const WEST_ASKBACK = [
    { ru: "А у вас?", en: "And do you have (one)?", correct: true },
    { ru: "А вы?", en: "And you?", hint: "А вы? asks about you in general. We want to ask about having, so keep у вас." },
    { ru: "А у меня?", en: "And do I have (one)?", hint: "That asks about you, the speaker. Ask about the pirate: у вас." },
    { ru: "А вас?", en: "And you? (object form)", hint: "Close! We need у вас, “you have,” to ask about having." }
];

let westIndex = 0;

function westBubble(who, ru, en, canHear) {

    const bubble = document.createElement("div");
    bubble.className = `bw-bubble bw-bubble--${who}`;

    const line = document.createElement("div");
    line.className = "bw-bubble__ru";
    line.textContent = ru;

    const english = document.createElement("div");
    english.className = "bw-bubble__en";
    english.textContent = `(${en})`;

    bubble.append(line, english);

    if (canHear) {
        const hear = document.createElement("button");
        hear.type = "button";
        hear.className = "be-hear";
        hear.textContent = "🔊 Hear";
        hear.addEventListener("click", () => speakRussianWord(ru));
        bubble.appendChild(hear);
    }

    document.querySelector("#bw-bubbles").appendChild(bubble);

}

function westChoices(options, onPick) {

    const holder = document.querySelector("#bw-choices");
    holder.innerHTML = "";

    options.forEach((option) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "bw-choice";
        button.textContent = option.ru;
        button.addEventListener("click", () => onPick(option, button));
        holder.appendChild(button);
    });

}

function westStart(index) {

    westIndex = index;
    const talk = WEST_TALKS[index];

    document.querySelector("#bw-bubbles").innerHTML = "";
    document.querySelector("#bw-feedback").textContent = "";
    document.querySelector("#bw-next").hidden = true;
    document.querySelector("#bw-again").hidden = true;
    document.querySelector("#bw-portrait").style.backgroundImage = pirateUrl(talk.role);

    document.querySelectorAll("#bw-dots span").forEach((dot, i) => {
        dot.classList.toggle("is-current", i === index);
        dot.classList.toggle("is-done", i < index);
    });

    document.querySelector("#bw-task").textContent = "Click your answer.";
    westBubble("pirate", talk.ask, talk.askEn, true);

    westChoices(talk.answers, (answer) => {

        westBubble("you", answer.ru, answer.en, false);
        document.querySelector("#bw-task").textContent = "Now ask the pirate the same question.";
        westAskBack(talk);

    });

}

function westAskBack(talk) {

    westChoices(pirateShuffle(WEST_ASKBACK), (option, button) => {

        const feedback = document.querySelector("#bw-feedback");

        if (!option.correct) {
            button.classList.add("is-wrong");
            feedback.textContent = option.hint;
            return;
        }

        feedback.textContent = "";
        westBubble("you", option.ru, option.en, false);
        westBubble("pirate", talk.reply, talk.replyEn, true);
        document.querySelector("#bw-choices").innerHTML = "";

        if (westIndex < WEST_TALKS.length - 1) {
            document.querySelector("#bw-task").textContent = "Well done!";
            document.querySelector("#bw-next").hidden = false;
        } else {
            document.querySelector("#bw-task").textContent = "Three conversations done. You can answer, and you can ask back!";
            document.querySelector("#bw-again").hidden = false;
        }

    });

}

(function wireWestBoat() {

    const dots = document.querySelector("#bw-dots");
    WEST_TALKS.forEach(() => dots.appendChild(document.createElement("span")));

    document.querySelector("#bw-next").addEventListener("click", () => westStart(westIndex + 1));
    document.querySelector("#bw-again").addEventListener("click", () => westStart(0));

})();

BOAT_RESETTERS.west = () => {
    westStart(0);
    document.querySelector("#boat-west")?._closeWhy?.();
};


// ---------------------------------------------------------------
// THE TREASURE CHEST
// States: closed → opening → open → scroll-opening → scroll-preview
// Every timer is tracked so leaving the room can cancel it all.
// ---------------------------------------------------------------
const chestRoom = document.querySelector("#chest-room");
const tcChestBtn = document.querySelector("#tc-chest");
const tcScrolls = document.querySelectorAll("#chest-room .tc-scroll");
const tcCloseBtn = document.querySelector("#tc-close");
const tcSubtitle = document.querySelector("#tc-subtitle");

const TC_IMG = "../../Images/door-three/";
let tcTimers = [];
let tcSelected = null;

function tcLater(delay, work) {
    tcTimers.push(setTimeout(work, delay));
}

function tcCancelTimers() {
    tcTimers.forEach(clearTimeout);
    tcTimers = [];
}

function tcSetState(state) {
    chestRoom.dataset.tcState = state;
}

// The chest has two pictures (closed, fully open) that crossfade through CSS
function tcSetChestOpen(isOpen) {
    tcChestBtn.classList.toggle("is-open", isOpen);
}

function tcSetScrollFrame(scroll, n) {
    scroll.querySelector(".tc-scroll__img").src = `${TC_IMG}image-scroll-frame-${n}.png`;
}

// Scrolls: all closed, undimmed; clickable only when asked
function tcRollAllScrolls(clickable) {
    tcScrolls.forEach((scroll) => {
        scroll.classList.remove("is-selected", "is-dim", "is-ready");
        tcSetScrollFrame(scroll, 1);
        scroll.disabled = !clickable;
    });
    tcSelected = null;
    tcCloseBtn.hidden = true;
}

// Back to the first moment: closed chest, nothing running
function tcReset() {
    tcCancelTimers();
    sbReset();
    tcSetState("closed");
    tcSetChestOpen(false);
    tcSubtitle.textContent = "The Final Discovery";
    tcRollAllScrolls(false);
}

// Click the chest: it crossfades open, then the scrolls appear (no extra click)
tcChestBtn.addEventListener("click", () => {

    if (chestRoom.dataset.tcState !== "closed") {
        return;   // ignore duplicate clicks while it opens
    }

    tcSetState("opening");

    tcSetChestOpen(true);

    tcLater(900, () => {
        tcSubtitle.textContent = "Choose Your Treasure";
        tcRollAllScrolls(true);
        tcSetState("open");
    });

});

// Click a scroll: it comes forward and unrolls through four frames
tcScrolls.forEach((scroll) => {

    scroll.addEventListener("click", () => {

        const state = chestRoom.dataset.tcState;

        // Preview is showing: the parchment is the way in
        if (state === "scroll-preview" && scroll === tcSelected) {
            tcEnterContent(scroll.dataset.scroll);
            return;
        }

        if (state !== "open") {
            return;   // locked while moving or unrolling
        }

        tcSelected = scroll;
        tcSetState("scroll-opening");

        tcScrolls.forEach((each) => {
            each.disabled = true;
            each.classList.toggle("is-dim", each !== scroll);
        });

        scroll.classList.add("is-selected");

        [2, 3, 4].forEach((frame, i) => {
            tcLater(500 + i * 450, () => tcSetScrollFrame(scroll, frame));
        });

        tcLater(2000, () => {
            scroll.classList.add("is-ready");
            scroll.disabled = false;
            tcCloseBtn.hidden = false;
            tcSetState("scroll-preview");
        });

    });

});

// Close Scroll: back to the open chest, every scroll rolled up and clickable
tcCloseBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    tcCancelTimers();
    tcRollAllScrolls(true);
    tcSetState("open");
});

// Entering a scroll's full screen (built in the next step)
function tcEnterContent(number) {
    const screen = document.querySelector(`#chest-content-${number}`);
    if (number === "3") {
        sbReset();
    }
    if (screen) {
        showCompassScreen(screen);
    }
}



// ---------------------------------------------------------------
// SCROLL 3 — PUT YOUR RUSSIAN TO WORK!
// Five sentence-building challenges. One shared word bank, reshuffled
// every time a challenge begins. Tiles are never used up.
// ---------------------------------------------------------------
const SB_BANK = [
    "у", "меня", "тебя", "него", "неё", "нас", "вас", "них", "есть", "нет",
    "брат", "брата", "сестра", "сестры", "сын", "сына", "дочь", "дочери", "дети", "детей",
    "старший", "старшая", "старше", "младший", "младшая", "младше", "младшие",
    "две", "три", "трое", "ребёнка"
];

// "optionalEst": есть may be left out or kept (У меня есть сестра / У меня сестра)
const SB_CHALLENGES = [
    {
        en: "I have an older sister.",
        answers: [["у", "меня", "есть", "старшая", "сестра"]], optionalEst: true
    },
    {
        en: "She doesn’t have a brother.",
        answers: [["у", "неё", "нет", "брата"]]
    },
    {
        en: "I don’t have a son.",
        answers: [["у", "меня", "нет", "сына"]]
    },
    {
        en: "I have two younger sisters.",
        answers: [["у", "меня", "есть", "две", "младшие", "сестры"]], optionalEst: true
    },
    {
        en: "She has three children.",
        answers: [["у", "неё", "трое", "детей"], ["у", "неё", "три", "ребёнка"]],
        optionalEst: true, another: true
    }
];

const sbBank = document.querySelector("#sb-bank");
const sbAnswer = document.querySelector("#sb-answer");
const sbFeedback = document.querySelector("#sb-feedback");
const sbNext = document.querySelector("#sb-next");
const sbCheck = document.querySelector("#sb-check");
const sbAnother = document.querySelector("#sb-another");

let sbIndex = 0;
let sbWords = [];
let sbSolved = false;

// How a sentence is shown: first letter capital, final period
function sbShow(words) {
    const text = words.join(" ");
    return `${text.charAt(0).toUpperCase()}${text.slice(1)}.`;
}

function sbNormalize(words, challenge) {
    return challenge.optionalEst ? words.filter((word) => word !== "есть") : words;
}

function sbDraw() {

    sbAnswer.innerHTML = "";

    if (sbWords.length === 0) {
        sbAnswer.innerHTML = '<span class="sb-answer__empty">Your words will appear here…</span>';
        return;
    }

    sbWords.forEach((word, i) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "sb-chip";
        chip.textContent = (i === 0) ? word.charAt(0).toUpperCase() + word.slice(1) : word;
        chip.disabled = sbSolved;
        chip.addEventListener("click", () => {
            sbWords.splice(i, 1);
            sbFeedback.textContent = "";
            sbDraw();
        });
        sbAnswer.appendChild(chip);
    });

}

// A fresh Fisher–Yates shuffle of the whole bank (pirateShuffle is exactly that)
function sbBuildBank() {

    sbBank.innerHTML = "";

    pirateShuffle(SB_BANK).forEach((word) => {
        const tile = document.createElement("button");
        tile.type = "button";
        tile.className = "sb-tile";
        tile.textContent = word;
        tile.addEventListener("click", () => {
            if (sbSolved) {
                return;
            }
            sbWords.push(word);
            sbFeedback.textContent = "";
            sbDraw();
        });
        sbBank.appendChild(tile);
    });

}

function sbStart(index) {

    sbIndex = index;
    sbWords = [];
    sbSolved = false;

    const number = index + 1;
    document.querySelector("#sb-english").textContent = SB_CHALLENGES[index].en;
    document.querySelector("#sb-num").textContent = number;
    document.querySelector("#sb-count").textContent = `Challenge ${number} of 5`;
    document.querySelector("#sb-plaque-n").textContent = `Challenge ${number}`;

    document.querySelectorAll("#sb-dots span").forEach((dot, i) => {
        dot.classList.toggle("is-current", i === index);
        dot.classList.toggle("is-done", i < index);
    });

    sbFeedback.textContent = "";
    sbFeedback.classList.remove("is-good");
    sbAnother.hidden = true;
    sbNext.disabled = true;
    sbNext.textContent = "Next Challenge ›";
    sbCheck.disabled = false;

    sbBuildBank();
    sbDraw();

}

// Clear My Answer: only the learner's sentence goes away
document.querySelector("#sb-clear").addEventListener("click", () => {
    if (sbSolved) {
        return;
    }
    sbWords = [];
    sbFeedback.textContent = "";
    sbDraw();
});

// Check My Sentence
sbCheck.addEventListener("click", () => {

    if (sbSolved) {
        return;
    }

    if (sbWords.length === 0) {
        sbFeedback.textContent = "Click some Russian words first.";
        sbFeedback.classList.remove("is-good");
        return;
    }

    const challenge = SB_CHALLENGES[sbIndex];
    const mine = sbNormalize(sbWords, challenge).join(" ");

    const matchIndex = challenge.answers.findIndex(
        (answer) => sbNormalize(answer, challenge).join(" ") === mine
    );

    if (matchIndex === -1) {
        sbFeedback.textContent = "Not quite. Check the words and their endings, then try again.";
        sbFeedback.classList.remove("is-good");
        return;
    }

    sbSolved = true;
    sbFeedback.textContent = "Correct! Well done!";
    sbFeedback.classList.add("is-good");
    sbCheck.disabled = true;
    sbNext.disabled = false;
    sbDraw();

    // Challenge 5 has two correct answers: show the other one as a discovery
    if (challenge.another && challenge.answers.length > 1) {
        const other = challenge.answers[matchIndex === 0 ? 1 : 0];
        document.querySelector("#sb-another-ru").textContent = sbShow(other);
        document.querySelector("#sb-another-en").textContent = challenge.en.replace(/\.$/, "");
        sbAnother.hidden = false;
    }

    document.querySelectorAll("#sb-dots span")[sbIndex].classList.add("is-done");

    if (sbIndex === SB_CHALLENGES.length - 1) {
        sbNext.textContent = "Finish Challenges ›";
        sbFeedback.textContent = "Correct! Well done! You built all five sentences!";
    }

});

// Next Challenge / Finish Challenges
sbNext.addEventListener("click", () => {

    if (sbNext.disabled) {
        return;
    }

    if (sbIndex < SB_CHALLENGES.length - 1) {
        sbStart(sbIndex + 1);
    } else {
        document.querySelector("#chest-content-3 .tc-back-chest").click();
    }

});

// Every visit to Scroll 3 starts at Challenge 1 with a fresh shuffle
function sbReset() {
    sbStart(0);
}

// Back to Treasure Chest (from any scroll's full screen):
// the chest stays open and all three scrolls are rolled up again
document.querySelectorAll(".tc-back-chest").forEach((button) => {
    button.addEventListener("click", () => {
        tcCancelTimers();
        tcRollAllScrolls(true);
        tcSetState("open");
        sbReset();
        showCompassScreen(chestRoom);
    });
});

// Hear buttons on the scroll screens
document.querySelectorAll("#explore-conversation .cc-hear").forEach((button) => {
    button.addEventListener("click", () => speakRussianWord(button.dataset.say));
});

// Map Room marker: opens the CLOSED landing screen
document.querySelector("#compass-chest-marker").addEventListener("click", () => {
    tcReset();
    showCompassScreen(chestRoom);
});

// Back to the Map: the glow ends and the compass is ready again
document
    .querySelectorAll("#explore-conversation .compass-back-to-map")
    .forEach((button) => {

        button.addEventListener("click", () => {

            clearCompassGlow();
            setCompassPrompt("Click the compass to find where to go next.");

            showCompassMap();

        });

    });


// Reset / Start Over: a fresh shuffled cycle and a resting needle
document
    .querySelectorAll("#explore-conversation .compass-reset")
    .forEach((button) => {

        button.addEventListener("click", () => {

            compassBag = [];
            compassLastDealt = null;
            compassTotalAngle = 0;
            compassSpinning = false;

            clearCompassGlow();
            setCompassPrompt("Click the compass to find where to go next.");

            if (compassNeedle) {
                compassNeedle.style.transition = "none";
                compassNeedle.style.transform = "rotate(0deg)";
            }

        });

    });


// ============================================================
// BEGIN DOOR FOUR — RUSSIAN LANGUAGE LABORATORY
// Main landing screen: independent, future-ready hotspots.
// ============================================================
(() => {
    const lab = document.getElementById('door-four-laboratory');
    if (!lab) return;
    const status = lab.querySelector('.door-four__status');
    const room = document.getElementById('explore-russian');
    const hallway = document.getElementById('explore-hallway');
    document.querySelector('.explore-door[data-door="russian"]')?.addEventListener('click', () => {
        if (hallway) hallway.hidden = true;
        if (room) {
            room.hidden = false;
            room.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
    // BEGIN LABORATORY LANDING — IMAGE BUTTON RETURNS THROUGH EXISTING NAVIGATION
    lab.querySelector('.door-four__landing-back')?.addEventListener('click', () => {
        lab.querySelector('.door-four__return')?.click();
    });
    // END LABORATORY LANDING — IMAGE BUTTON RETURNS THROUGH EXISTING NAVIGATION
    lab.querySelector('.door-four__return')?.addEventListener('click', () => {
        if (room) room.hidden = true;
        if (hallway) {
            hallway.hidden = false;
            hallway.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
    const messages = {
        'tube': 'Explore What’s Inside — the experiment entry will be connected later.',
        'cylinder-blue': 'A new blue-cylinder discovery is being prepared!',
        'cylinder-green': 'A new green-cylinder discovery is being prepared!',
        'cylinder-purple': 'A new purple-cylinder discovery is being prepared!',
        'red': 'Play & Listen — learning activity coming soon.',
        'blue': 'Compare — learning activity coming soon.',
        'green': 'Change & Observe — learning activity coming soon.',
        'purple': 'Test a Theory — learning activity coming soon.',
        'gold': 'Try It Yourself — learning activity coming soon.',
        'gears': 'How It Works? — experience coming soon.',
        'gauge': 'The Pressure Gauge — experience coming soon.',
        'lamp': 'Small Discoveries — experience coming soon.',
        'drawer-examples': 'Examples drawer — content coming soon.',
        'drawer-special': 'Special Cases drawer — content coming soon.',
        'drawer-real': 'Real World Use drawer — content coming soon.',
        'drawer-notes': 'Notes & Insights drawer — content coming soon.',
        'previous': 'Previous Experiment — available when experiments are connected.',
        'reset': 'Reset Experiment — available when experiments are connected.',
        'next': 'Next Experiment — available when experiments are connected.'
    };
    // BEGIN UNDER THE MICROSCOPE — interactive first experiment
    // BEGIN DRAWERS SECONDARY SCREEN — independent of Microscope
    const interior = lab.querySelector('.door-four__drawer-interior');
    const interiorTabs = [...interior.querySelectorAll('[data-drawer-tab]')];
    const sentenceSpotlight = interior.querySelector('#ls-scene');
    const curiosityCabinet = interior.querySelector('#cc-scene');
    function hideCuriosityCabinet() { if (curiosityCabinet) curiosityCabinet.hidden = true; }
    function hideSentenceSpotlight() { if (sentenceSpotlight) sentenceSpotlight.hidden = true; }

    // BEGIN DRAWER THREE — SIGNS EXPLORER (NO SHARED DRAWER CHANGES)
    const signsExplorer = interior.querySelector('#rw-signs');
    const signsData = [
      {ru:'Детский сад',en:'Kindergarten',img:'signs-kindergarten.png',alt:'Children learning in a kindergarten classroom',caption:'A kindergarten classroom — the Russian expression is displayed separately.',words:[['Детский','For children / children’s','DET-skee','The ending -ий matches the masculine noun сад.'],['сад','Garden; in this expression, kindergarten','saht','Together, детский сад names a kindergarten, not an ordinary garden.']]},
      {ru:'Детская площадка',en:'Children’s playground',img:'signs-playground.png',alt:'Outdoor playground with climbing equipment and slide',caption:'A playground — the Russian expression is displayed separately.',words:[['Детская','For children / children’s','DET-ska-ya','The ending -ая matches the feminine noun площадка.'],['площадка','Area, grounds; here, playground','pla-SHCHAT-ka','Together, детская площадка means a children’s playground.']]},
      {ru:'Детская поликлиника',en:'Children’s outpatient clinic',img:'signs-childrens-clinic.png',alt:'Children’s clinic building with the Russian words Детская поликлиника on its entrance',caption:'Authentic Russian lettering is visible above the entrance.',words:[['Детская','For children / children’s','DET-ska-ya','Compare детский сад and детская поликлиника: the ending changes with the noun.'],['поликлиника','Outpatient clinic','pa-lee-KLEE-nee-ka','A поликлиника provides outpatient medical care.']]},
      {ru:'Семейная клиника',en:'Family clinic',img:'signs-family-clinic.png',alt:'White clinic building',caption:'A clinic building — the Russian expression is displayed separately.',words:[['Семейная','Family / relating to a family','see-MEY-na-ya','Семейная comes from семья, the Russian word for family.'],['клиника','Clinic','KLEE-nee-ka','Клиника is a feminine noun, so семейная has the ending -ая.']]}
    ];
    const signsWords = signsExplorer.querySelector('#rw-signs-words');
    const signsDiscovery = signsExplorer.querySelector('#rw-signs-discovery');
    const signsMeaning = signsExplorer.querySelector('#rw-signs-meaning');
    let activeSign = 0;
    function renderSign(index){
      activeSign=index;
      const item=signsData[index];
      signsExplorer.querySelector('#rw-signs-photo').src='../../Images/door-four/'+item.img;
      signsExplorer.querySelector('#rw-signs-photo').alt=item.alt;
      signsExplorer.querySelector('#rw-signs-caption').textContent=item.caption;
      signsWords.replaceChildren();
      item.words.forEach(([word,meaning,pronunciation,note])=>{
        const button=document.createElement('button');button.type='button';button.textContent=word;button.setAttribute('aria-pressed','false');
        button.addEventListener('click',()=>{
          signsWords.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
          signsDiscovery.replaceChildren();
          const title=document.createElement('strong');title.textContent=word+' — '+meaning;
          const detail=document.createElement('p');detail.textContent='Pronunciation: '+pronunciation+'. '+note;
          signsDiscovery.append(title,detail);
        });signsWords.appendChild(button);
      });
      signsDiscovery.textContent='Select a word above to discover its meaning and a little language surprise.';
      signsMeaning.hidden=true;signsMeaning.textContent=item.ru+' — '+item.en;
    }
    signsExplorer.querySelectorAll('input[name="rw-sign-choice"]').forEach(input=>input.addEventListener('change',()=>{if(input.checked)renderSign(Number(input.value));}));
    signsExplorer.querySelector('#rw-signs-listen').addEventListener('click',()=>speakRussian(signsData[activeSign].ru));
    signsExplorer.querySelector('#rw-signs-reveal').addEventListener('click',()=>{signsMeaning.hidden=!signsMeaning.hidden;});
    signsExplorer.querySelector('#rw-signs-back').addEventListener('click',()=>{signsExplorer.hidden=true;});
    interior.querySelector('[data-rw-spot="signs"]').addEventListener('click',()=>{if(interior.dataset.activeDrawer!=='real')return;renderSign(Number(signsExplorer.querySelector('input[name="rw-sign-choice"]:checked').value));signsExplorer.hidden=false;signsExplorer.scrollTop=0;});
    renderSign(0);
    // END DRAWER THREE — SIGNS EXPLORER


    // BEGIN DRAWER THREE — MESSAGES / INTERACTIVE BRANCHING ENGINE
    // Each node contains the sender's message and meaningful response directions.
    // Unknown/off-topic responses share ONE universal clarification and do not advance.
    const messagesExplorer = interior.querySelector('#rw-messages');
    const messengerThread = messagesExplorer.querySelector('#rw-messages-thread');
    const messengerReplies = messagesExplorer.querySelector('#rw-messages-replies');
    const messengerDiscovery = messagesExplorer.querySelector('#rw-messages-discovery');
    const messengerInstruction = messagesExplorer.querySelector('#rw-messages-instruction');
    const messengerSend = messagesExplorer.querySelector('#rw-messages-send');
    const messengerClear = messagesExplorer.querySelector('#rw-messages-clear');
    const messengerRewind = messagesExplorer.querySelector('#rw-messages-rewind');
    const universalClarification = 'Извини, я не понимаю. Попробуй ещё раз!';
    // Each distinct message has its own short, contextual explanation.
    const messengerGrammarNotes = {
    "Ты придёшь сегодня на ужин?": "<strong>Ты</strong> is informal “you,” natural with family. <strong>придёшь</strong> means “will you come” (from прийти). <strong>на ужин</strong> means “for dinner.”",
    "Да, конечно!": "<strong>Да</strong> means “yes”; <strong>конечно</strong> adds “of course.” A warm, confident acceptance.",
    "Во сколько?": "A compact way to ask “At what time?” <strong>во</strong> is used before <strong>сколько</strong> in this expression.",
    "Сегодня не могу.": "<strong>Сегодня</strong> means “today.” <strong>не могу</strong> means “I can’t”; Russian can omit the verb that English would repeat.",
    "Меня зовут Майкл.": "<strong>Меня зовут</strong> literally means “they call me.” It introduces your name, but does not answer a dinner invitation.",
    "Отлично! Приходи в шесть часов.": "<strong>Приходи</strong> is a friendly informal invitation or instruction: “Come.” <strong>в шесть часов</strong> gives the time: “at six o’clock.”",
    "Что-нибудь купить?": "<strong>Что-нибудь</strong> means “something/anything.” <strong>купить</strong> is “to buy.” The short question leaves “Should I” understood.",
    "Спасибо! До вечера!": "<strong>Спасибо</strong> is “thank you.” <strong>до вечера</strong> literally points to “until evening,” a natural farewell.",
    "В шесть часов.": "<strong>в</strong> marks a specific time. <strong>шесть</strong> is six; <strong>часов</strong> is the form used after numbers like six.",
    "Хорошо! Я приду.": "<strong>Хорошо</strong> means “okay/good.” <strong>приду</strong> means “I will come,” a future form of прийти.",
    "Жаль! Может быть, завтра?": "<strong>Жаль</strong> expresses regret (“What a shame”). <strong>Может быть</strong> means “maybe”; <strong>завтра</strong> means “tomorrow.”",
    "Да, завтра могу!": "<strong>Завтра</strong> means “tomorrow”; <strong>могу</strong> means “I can.” The action is understood from context.",
    "Извини, завтра тоже не могу.": "<strong>Извини</strong> is informal “sorry.” <strong>тоже</strong> means “also/either”; <strong>не могу</strong> is “I can’t.”",
    "Нет, спасибо! Всё готово.": "<strong>Нет, спасибо</strong> politely declines. <strong>Всё готово</strong> means “Everything is ready.”",
    "Хорошо! До вечера!": "<strong>Хорошо</strong> is “okay”; <strong>до вечера</strong> is a friendly “see you this evening.”",
    "Отлично! Тогда до завтра!": "<strong>Тогда</strong> means “then/in that case.” <strong>до завтра</strong> is “see you tomorrow.”",
    "Ничего страшного! Увидимся в другой раз.": "<strong>Ничего страшного</strong> reassures: “No problem.” <strong>Увидимся</strong> means “we’ll see each other”; <strong>в другой раз</strong> means “another time.”",
    "До вечера! Обнимаю!": "<strong>До вечера</strong> means “see you this evening.” <strong>Обнимаю</strong> literally means “I hug (you),” a warm sign-off.",
    "Что ты делаешь в субботу?": "<strong>Что ты делаешь</strong> is “what are you doing?” <strong>в субботу</strong> means “on Saturday.”",
    "Пока ничего. А что?": "<strong>Пока</strong> means “so far/yet”; <strong>ничего</strong> means “nothing.” <strong>А что?</strong> naturally asks “Why?/What’s up?”",
    "Я свободен в субботу.": "<strong>Свободен</strong> means “free/available” for a male speaker; a female speaker says <strong>свободна</strong>. <strong>в субботу</strong> means “on Saturday.”",
    "У меня уже есть планы.": "<strong>У меня есть</strong> is a common Russian way to say “I have.” <strong>уже</strong> means “already”; <strong>планы</strong> means “plans.”",
    "Пойдём в парк всей семьёй!": "<strong>Пойдём</strong> suggests “Let’s go.” <strong>в парк</strong> gives the destination; <strong>всей семьёй</strong> means “as a whole family.”",
    "Мама и папа тоже пойдут?": "<strong>тоже</strong> means “too/also.” <strong>пойдут</strong> means “will go” for several people.",
    "Отлично! Я приду!": "<strong>Отлично</strong> means “great!” <strong>Я приду</strong> means “I will come,” a future form of прийти.",
    "Отличная идея! Я приду!": "<strong>Отличная идея</strong> means “great idea”; <strong>отличная</strong> agrees with feminine <strong>идея</strong>. <strong>приду</strong> means “I’ll come.”",
    "Да, и бабушка с дедушкой!": "<strong>с дедушкой</strong> means “with Grandpa”; after <strong>с</strong>, дедушка changes to дедушкой. <strong>и</strong> adds “and.”",
    "Во сколько встречаемся?": "<strong>Во сколько</strong> asks “at what time?” <strong>встречаемся</strong> means “are we meeting?”",
    "В два часа дня, у входа.": "<strong>в два часа дня</strong> means “at two in the afternoon.” <strong>у входа</strong> means “by/near the entrance.”",
    "Хорошо! До субботы!": "<strong>До субботы</strong> means “see you Saturday.” After <strong>до</strong>, суббота changes to субботы.",
    "Понятно! Может быть, в воскресенье?": "<strong>Понятно</strong> means “I see/understood.” <strong>в воскресенье</strong> means “on Sunday.”",
    "В воскресенье могу!": "<strong>в воскресенье</strong> means “on Sunday”; <strong>могу</strong> means “I can,” with the rest understood.",
    "В эти выходные не могу.": "<strong>эти выходные</strong> means “this weekend.” <strong>не могу</strong> means “I can’t.”",
    "Отлично! Тогда договорились!": "<strong>Договорились</strong> is a natural way to say “Agreed!/It’s a plan!” <strong>Тогда</strong> means “then.”",
    "Хорошо! Увидимся в другой раз.": "<strong>Увидимся</strong> means “we’ll see each other”; <strong>в другой раз</strong> means “another time.”",
    "Ура! До встречи!": "<strong>Ура</strong> is “Hooray!” <strong>До встречи</strong> is a common “See you!” farewell.",
    "Сегодня день рождения дедушки!": "<strong>Сегодня</strong> means “today.” <strong>день рождения</strong> is “birthday” (literally “day of birth”). <strong>дедушки</strong> means “Grandpa’s”; its ending marks whose birthday.",
    "Ой! Я забыл!": "<strong>Ой</strong> is an exclamation (“Oh!”). <strong>забыл</strong> means “forgot,” said by a male speaker; a female speaker uses <strong>забыла</strong>.",
    "Ой! Я забыла!": "<strong>Ой</strong> is “Oh!” <strong>забыла</strong> means “forgot,” said by a female speaker; a male speaker uses <strong>забыл</strong>.",
    "Я помню! Позвоню ему.": "<strong>помню</strong> means “I remember.” <strong>позвоню</strong> means “I’ll call”; <strong>ему</strong> means “him/to him.”",
    "Позвони ему сегодня.": "<strong>Позвони</strong> is an informal command: “Call!” <strong>ему</strong> means “him”; <strong>сегодня</strong> means “today.”",
    "Хорошо! Сейчас позвоню.": "<strong>Сейчас</strong> means “now/right away.” <strong>позвоню</strong> means “I’ll call,” with “I” understood.",
    "А какой у него номер?": "<strong>какой</strong> asks “what/which kind.” <strong>у него</strong> means “he has”; <strong>номер</strong> is “number.”",
    "Я пришлю тебе его номер.": "<strong>пришлю</strong> means “I’ll send.” <strong>тебе</strong> means “to you” informally; <strong>его номер</strong> is “his number.”",
    "Спасибо! Сейчас позвоню.": "<strong>Спасибо</strong> means “thanks.” <strong>сейчас позвоню</strong> means “I’ll call right now.”",
    "Передай ему привет от меня!": "<strong>Передай</strong> means “pass along.” <strong>ему привет</strong> is “greetings to him”; <strong>от меня</strong> means “from me.”",
    "Конечно, мама!": "<strong>Конечно</strong> means “of course.” <strong>мама</strong> is a familiar way to address Mom.",
    "Обязательно!": "<strong>Обязательно</strong> means “definitely/certainly.” It works as a complete, enthusiastic answer.",
    "Спасибо! Обнимаю!": "<strong>Спасибо</strong> is “thanks”; <strong>обнимаю</strong> is a warm sign-off meaning “hugs.”",
    "Извини, я не понимаю. Попробуй ещё раз!": "<strong>Извини</strong> is informal “sorry.” <strong>я не понимаю</strong> means “I don’t understand”; <strong>попробуй ещё раз</strong> means “try again.” These forms do not depend on the speaker’s gender."
};
    const messengerGrammarBody = messagesExplorer.querySelector('#rw-messages-grammar-body');
    const messengerGrammarToggle = messagesExplorer.querySelector('#rw-messages-grammar-toggle');
    let messengerSelectedMessage = null;
    function messengerShowGrammar(ru) {
      messengerSelectedMessage = ru;
      messengerGrammarBody.replaceChildren();
      const title = document.createElement('p');
      title.className = 'rw-messages__grammar-phrase';
      title.lang = 'ru'; title.textContent = ru;
      const detail = document.createElement('p');
      // Authored local HTML notes contain only trusted <strong> emphasis.
      detail.innerHTML = messengerGrammarNotes[ru] || 'Look at the words and endings in this message. Listen, compare, and try the phrase in context.';
      messengerGrammarBody.append(title, detail);
    }
    messengerGrammarToggle.addEventListener('click', () => {
      const opening = messengerGrammarBody.hidden;
      messengerGrammarBody.hidden = !opening;
      messengerGrammarToggle.setAttribute('aria-expanded', String(opening));
      messengerGrammarToggle.textContent = opening ? 'Close explanation ▴' : 'Explore this message ▾';
    });

    const messengerConversations = [
      {contact:'Бабушка',avatar:'👵',start:'invite',nodes:{
        invite:{say:'Ты придёшь сегодня на ужин?',en:'Are you coming to dinner today?',replies:[
          {ru:'Да, конечно!',en:'Yes, of course!',next:'yes'},
          {ru:'Во сколько?',en:'What time?',next:'time'},
          {ru:'Сегодня не могу.',en:'I can’t today.',next:'no'},
          {ru:'Меня зовут Майкл.',en:'My name is Michael.',unknown:true}]},
        yes:{say:'Отлично! Приходи в шесть часов.',en:'Wonderful! Come at six o’clock.',replies:[
          {ru:'Что-нибудь купить?',en:'Should I buy anything?',next:'bring'},
          {ru:'Спасибо! До вечера!',en:'Thanks! See you tonight!',next:'bye'},
          {ru:'Во сколько?',en:'What time?',next:'time'}]},
        time:{say:'В шесть часов.',en:'At six o’clock.',replies:[
          {ru:'Хорошо! Я приду.',en:'Okay! I’ll come.',next:'bring'},
          {ru:'Спасибо! До вечера!',en:'Thanks! See you tonight!',next:'bye'},
          {ru:'Сегодня не могу.',en:'I can’t today.',next:'no'}]},
        no:{say:'Жаль! Может быть, завтра?',en:'That’s a shame! Maybe tomorrow?',replies:[
          {ru:'Да, завтра могу!',en:'Yes, I can tomorrow!',next:'tomorrow'},
          {ru:'Извини, завтра тоже не могу.',en:'Sorry, I can’t tomorrow either.',next:'another'}]},
        bring:{say:'Нет, спасибо! Всё готово.',en:'No, thanks! Everything is ready.',replies:[
          {ru:'Хорошо! До вечера!',en:'Okay! See you tonight!',next:'bye'}]},
        tomorrow:{say:'Отлично! Тогда до завтра!',en:'Great! See you tomorrow, then!',replies:[]},
        another:{say:'Ничего страшного! Увидимся в другой раз.',en:'No worries! We’ll see each other another time.',replies:[]},
        bye:{say:'До вечера! Обнимаю!',en:'See you tonight! Hugs!',replies:[]}
      }},
      {contact:'Сестра',avatar:'👩',start:'weekend',nodes:{
        weekend:{say:'Что ты делаешь в субботу?',en:'What are you doing on Saturday?',replies:[
          {ru:'Пока ничего. А что?',en:'Nothing yet. Why?',next:'park'},
          {ru:'Я свободен в субботу.',en:'I’m free on Saturday (masculine).',next:'park'},
          {ru:'У меня уже есть планы.',en:'I already have plans.',next:'busy'},
          {ru:'Меня зовут Майкл.',en:'My name is Michael.',unknown:true}]},
        park:{say:'Пойдём в парк всей семьёй!',en:'Let’s go to the park with the whole family!',replies:[
          {ru:'Мама и папа тоже пойдут?',en:'Are Mom and Dad coming too?',next:'parents'},
          {ru:'Отличная идея! Я приду!',en:'Great idea! I’ll come!',next:'great'},
          {ru:'Во сколько?',en:'At what time?',next:'parkTime'}]},
        parents:{say:'Да, и бабушка с дедушкой!',en:'Yes, and Grandma and Grandpa too!',replies:[
          {ru:'Отлично! Я приду!',en:'Great! I’ll come!',next:'great'},
          {ru:'Во сколько встречаемся?',en:'What time are we meeting?',next:'parkTime'}]},
        parkTime:{say:'В два часа дня, у входа.',en:'At two in the afternoon, by the entrance.',replies:[
          {ru:'Хорошо! До субботы!',en:'Okay! See you Saturday!',next:'great'}]},
        busy:{say:'Понятно! Может быть, в воскресенье?',en:'I see! Maybe on Sunday?',replies:[
          {ru:'В воскресенье могу!',en:'I can on Sunday!',next:'sunday'},
          {ru:'В эти выходные не могу.',en:'I can’t this weekend.',next:'later'}]},
        sunday:{say:'Отлично! Тогда договорились!',en:'Great! It’s a plan!',replies:[]},
        later:{say:'Хорошо! Увидимся в другой раз.',en:'Okay! We’ll see each other another time.',replies:[]},
        great:{say:'Ура! До встречи!',en:'Hooray! See you!',replies:[]}
      }},
      {contact:'Мама',avatar:'👩',start:'birthday',nodes:{
        birthday:{say:'Сегодня день рождения дедушки!',en:'Today is Grandpa’s birthday!',replies:[
          {ru:'Ой! Я забыл!',en:'Oh! I forgot! (masculine)',next:'call'},
          {ru:'Ой! Я забыла!',en:'Oh! I forgot! (feminine)',next:'call'},
          {ru:'Я помню! Позвоню ему.',en:'I remember! I’ll call him.',next:'greeting'},
          {ru:'Меня зовут Майкл.',en:'My name is Michael.',unknown:true}]},
        call:{say:'Позвони ему сегодня.',en:'Call him today.',replies:[
          {ru:'Хорошо! Сейчас позвоню.',en:'Okay! I’ll call now.',next:'greeting'},
          {ru:'А какой у него номер?',en:'What’s his number?',next:'number'}]},
        number:{say:'Я пришлю тебе его номер.',en:'I’ll send you his number.',replies:[
          {ru:'Спасибо! Сейчас позвоню.',en:'Thanks! I’ll call now.',next:'greeting'}]},
        greeting:{say:'Передай ему привет от меня!',en:'Say hello to him for me!',replies:[
          {ru:'Конечно, мама!',en:'Of course, Mom!',next:'love'},
          {ru:'Обязательно!',en:'Absolutely!',next:'love'}]},
        love:{say:'Спасибо! Обнимаю!',en:'Thanks! Hugs!',replies:[]}
      }}
    ];
    let messengerIndex = 0;
    let messengerNode = 'invite';
    let messengerHistory = [];
    let messengerDraft = null;
    let messengerMessages = [];
    let messengerClarificationShown = false;
    function messengerBubble(side,ru,en,isDraft=false){
      const bubble=document.createElement('button');bubble.type='button';
      bubble.className='rw-messages__bubble rw-messages__bubble--'+(side==='in'?'incoming':'outgoing')+(isDraft?' rw-messages__bubble--draft':'');
      bubble.lang='ru';bubble.textContent=ru;
      bubble.title='Tap to discover the meaning and hear Russian';
      bubble.addEventListener('click',()=>{
        messengerDiscovery.replaceChildren();
        const phrase=document.createElement('strong');phrase.lang='ru';phrase.textContent=ru;
        const meaning=document.createElement('p');meaning.textContent=en;
        const listen=document.createElement('button');listen.type='button';listen.textContent='🔊 Listen';
        listen.className='rw-messages__discovery-listen';listen.addEventListener('click',()=>speakRussian(ru));
        messengerDiscovery.append(phrase,meaning,listen);
        messengerShowGrammar(ru);
        messengerGrammarBody.hidden = false;
        messengerGrammarToggle.setAttribute('aria-expanded','true');
        messengerGrammarToggle.textContent = 'Close explanation ▴';
      });
      return bubble;
    }
    function messengerRender(){
      const conversation=messengerConversations[messengerIndex];
      const node=conversation.nodes[messengerNode];
      messagesExplorer.querySelector('#rw-messages-contact').textContent=conversation.contact;
      messagesExplorer.querySelector('.rw-messages__avatar').textContent=conversation.avatar;
      messengerThread.replaceChildren();
      messengerMessages.forEach(m=>messengerThread.append(messengerBubble(m.side,m.ru,m.en)));
      if(messengerDraft)messengerThread.append(messengerBubble('out',messengerDraft.ru,messengerDraft.en,true));
      messengerReplies.replaceChildren();
      node.replies.forEach((reply,index)=>{
        const button=document.createElement('button');button.type='button';button.lang='ru';
        button.className='rw-messages__reply'+(messengerDraft===reply?' rw-messages__reply--selected':'');
        button.textContent=reply.ru;button.title=reply.en;
        button.setAttribute('aria-pressed',String(messengerDraft===reply));
        button.addEventListener('click',()=>{messengerDraft=reply;messengerRender();});
        messengerReplies.append(button);
      });
      const done=node.replies.length===0;
      messengerInstruction.textContent=done?'Conversation complete! Rewind to explore another direction.':
        messengerDraft?'Draft ready. Press SEND to send it, or choose another reply.':'Choose a Russian reply. Preview it in the conversation before sending.';
      messengerSend.disabled=!messengerDraft;
      messengerClear.disabled=!messengerDraft;
      messengerRewind.disabled=messengerHistory.length===0;
      messengerThread.scrollTop=messengerThread.scrollHeight;
    }
    function messengerReset(index){
      messengerIndex=index;const c=messengerConversations[index];messengerNode=c.start;
      messengerHistory=[];messengerDraft=null;messengerClarificationShown=false;
      const n=c.nodes[messengerNode];messengerMessages=[{side:'in',ru:n.say,en:n.en}];
      messengerDiscovery.textContent='Select any message bubble to discover its meaning and hear it spoken.';
      messengerSelectedMessage = null;
      messengerGrammarBody.replaceChildren();
      const prompt=document.createElement('p');prompt.textContent='Select a message bubble to explore its Russian.';
      messengerGrammarBody.append(prompt);
      messengerGrammarBody.hidden=true;
      messengerGrammarToggle.setAttribute('aria-expanded','false');
      messengerGrammarToggle.textContent='Explore this message ▾';
      messengerRender();
    }
    messengerSend.addEventListener('click',()=>{
      if(!messengerDraft)return;
      const reply=messengerDraft;
      if(reply.unknown){
        // A repeated unknown reply does not flood the phone with identical clarifications.
        if(!messengerClarificationShown){
          messengerMessages.push({side:'out',ru:reply.ru,en:reply.en});
          messengerMessages.push({side:'in',ru:universalClarification,en:'Sorry, I don’t understand. Try again!'});
          messengerClarificationShown=true;
        }
        messengerDraft=null;messengerRender();return;
      }
      messengerHistory.push({node:messengerNode,messages:messengerMessages.map(m=>({...m})),clarification:messengerClarificationShown});
      messengerMessages.push({side:'out',ru:reply.ru,en:reply.en});
      messengerNode=reply.next;
      const response=messengerConversations[messengerIndex].nodes[messengerNode];
      messengerMessages.push({side:'in',ru:response.say,en:response.en});
      messengerDraft=null;messengerClarificationShown=false;messengerRender();
    });
    messengerClear.addEventListener('click',()=>{messengerDraft=null;messengerRender();});
    messengerRewind.addEventListener('click',()=>{
      const previous=messengerHistory.pop();if(!previous)return;
      messengerNode=previous.node;messengerMessages=previous.messages;
      messengerClarificationShown=previous.clarification;messengerDraft=null;messengerRender();
    });
    messagesExplorer.querySelectorAll('input[name="rw-message-choice"]').forEach(input=>input.addEventListener('change',()=>{
      if(input.checked)messengerReset(Number(input.value));
    }));
    messagesExplorer.querySelector('#rw-messages-back').addEventListener('click',()=>{messagesExplorer.hidden=true;});
    interior.querySelector('[data-rw-spot="messages"]').addEventListener('click',()=>{
      if(interior.dataset.activeDrawer!=='real')return;
      messengerReset(Number(messagesExplorer.querySelector('input[name="rw-message-choice"]:checked').value));
      messagesExplorer.hidden=false;messagesExplorer.scrollTop=0;
    });
    messengerReset(0);
    // END DRAWER THREE — MESSAGES / INTERACTIVE BRANCHING ENGINE


    // BEGIN DRAWER THREE — MENUS RECONSTRUCTION
    // Hotspots are authored in HTML; JavaScript only attaches behavior.
    const menusExplorer = interior.querySelector('#rw-menus');
    const menuButtons = [...menusExplorer.querySelectorAll('[data-menu-item]')];
    const menuItems = [{"ru": "Борщ", "en": "Borscht", "order": "Мне, пожалуйста, борщ.", "translation": "Could I have borscht, please?"}, {"ru": "Щи", "en": "Cabbage soup", "order": "Мне, пожалуйста, щи.", "translation": "Could I have cabbage soup, please?"}, {"ru": "Пельмени", "en": "Dumplings", "order": "Мне, пожалуйста, пельмени.", "translation": "Could I have dumplings, please?"}, {"ru": "Вареники", "en": "Filled dumplings", "order": "Мне, пожалуйста, вареники.", "translation": "Could I have filled dumplings, please?"}, {"ru": "Блины", "en": "Blini", "order": "Мне, пожалуйста, блины.", "translation": "Could I have blini, please?"}, {"ru": "Сырники", "en": "Cheese pancakes", "order": "Мне, пожалуйста, сырники.", "translation": "Could I have cheese pancakes, please?"}, {"ru": "Оливье", "en": "Olivier salad", "order": "Мне, пожалуйста, оливье.", "translation": "Could I have olivier salad, please?"}, {"ru": "Винегрет", "en": "Beet salad", "order": "Мне, пожалуйста, винегрет.", "translation": "Could I have beet salad, please?"}, {"ru": "Голубцы", "en": "Stuffed cabbage rolls", "order": "Мне, пожалуйста, голубцы.", "translation": "Could I have stuffed cabbage rolls, please?"}, {"ru": "Котлеты", "en": "Cutlets", "order": "Мне, пожалуйста, котлеты.", "translation": "Could I have cutlets, please?"}, {"ru": "Гречка", "en": "Buckwheat", "order": "Мне, пожалуйста, гречку.", "translation": "Could I have buckwheat, please?"}, {"ru": "Картофель", "en": "Potatoes", "order": "Мне, пожалуйста, картофель.", "translation": "Could I have potatoes, please?"}, {"ru": "Пирожки", "en": "Stuffed pastries", "order": "Мне, пожалуйста, пирожки.", "translation": "Could I have stuffed pastries, please?"}, {"ru": "Медовик", "en": "Honey cake", "order": "Мне, пожалуйста, медовик.", "translation": "Could I have honey cake, please?"}, {"ru": "Компот", "en": "Fruit drink", "order": "Мне, пожалуйста, компот.", "translation": "Could I have fruit drink, please?"}, {"ru": "Чай", "en": "Tea", "order": "Мне, пожалуйста, чай.", "translation": "Could I have tea, please?"}];
    let currentMenuIndex = -1;
    const menuArt = menusExplorer.querySelector('#rw-menus-art');
    const menuStage = menusExplorer.querySelector('.rw-menus__menu-stage');
    const markMenuArt = () => menuStage.classList.toggle('has-art', menuArt.complete && menuArt.naturalWidth > 0);
    menuArt.addEventListener('load',markMenuArt);
    menuArt.addEventListener('error',()=>{menuArt.hidden=true;menuStage.classList.remove('has-art');});
    markMenuArt();
    function selectMenuItem(index){
      const item=menuItems[index];if(!item)return;
      currentMenuIndex=index;
      menuButtons.forEach((button,i)=>button.setAttribute('aria-pressed',String(i===index)));
      menusExplorer.querySelector('#rw-menus-dish').textContent=item.ru;
      menusExplorer.querySelector('#rw-menus-english').textContent=item.en;
      menusExplorer.querySelector('#rw-menus-order').textContent=item.order;
      menusExplorer.querySelector('#rw-menus-translation').textContent=item.translation;
      menusExplorer.querySelector('#rw-menus-listen').disabled=false;
      menusExplorer.querySelector('#rw-menus-grammar').textContent='Мне, пожалуйста… is a polite way to ask for something for yourself. Russian food names may change form in an order; compare the menu name with the ordering phrase.';
    }
    menuButtons.forEach(button=>button.addEventListener('click',()=>selectMenuItem(Number(button.dataset.menuItem))));
    menusExplorer.querySelector('#rw-menus-listen').addEventListener('click',()=>{if(currentMenuIndex>=0)speakRussian(menuItems[currentMenuIndex].order);});
    menusExplorer.querySelector('#rw-menus-reset').addEventListener('click',()=>{
      currentMenuIndex=-1;menuButtons.forEach(b=>b.setAttribute('aria-pressed','false'));
      menusExplorer.querySelector('#rw-menus-dish').textContent='Выберите блюдо';
      menusExplorer.querySelector('#rw-menus-english').textContent='Choose a dish on the menu to begin.';
      menusExplorer.querySelector('#rw-menus-order').textContent='—';
      menusExplorer.querySelector('#rw-menus-translation').textContent='Your English meaning appears here.';
      menusExplorer.querySelector('#rw-menus-grammar').textContent='Choose another dish to investigate a polite Russian ordering expression.';
      menusExplorer.querySelector('#rw-menus-listen').disabled=true;
    });
    const screenTwo=menusExplorer.querySelector('#rw-menus-screen-two');
    const bill=interior.querySelector('#rw-bill');
    const quantity=menusExplorer.querySelector('#rw-menus-quantity');
    function updateFamily(){
      const n=Number(quantity.value);
      const forms=['','одна порция','две порции','три порции','четыре порции','пять порций','шесть порций'];
      const ending=n===1?'порция':n<=4?'порции':'порций';
      menusExplorer.querySelector('#rw-menus-family-phrase').textContent=forms[n];
      renderRussianEnding(
          menusExplorer.querySelector('#rw-menus-family-form'),
          "",
          "порци",
          ending.slice(5)
      );
      menusExplorer.querySelector('#rw-menus-family-discovery').textContent=n===1?'After one, Russian uses порция.':n<=4?'After two, three, or four, Russian uses порции.':'After five or more (in this range), Russian uses порций.';
    }
    quantity.addEventListener('change',updateFamily);
    updateFamily();
    // Page One always shows both activities; its existing Next button opens Page Two.
    menusExplorer.querySelector('#rw-menus-next').addEventListener('click',()=>{bill.hidden=false;menusExplorer.hidden=true;});
    bill.querySelector('#rw-bill-back').addEventListener('click',()=>{closeRubleLens();bill.hidden=true;menusExplorer.hidden=false;});
    bill.querySelector('#rw-bill-exit').addEventListener('click',()=>{closeRubleLens();bill.hidden=true;menusExplorer.hidden=true;});
    const billDishes=[
      ['борщ','Borscht',150,'стоит'],['оливье','Olivier salad',180,'стоит'],['пельмени','Pelmeni',120,'стоят'],['блины','Blini',140,'стоят'],
      ['бефстроганов','Beef Stroganoff',290,'стоит'],['голубцы','Golubtsy',230,'стоят'],['солянка','Solyanka',210,'стоит'],['пирожки','Pirozhki',110,'стоят'],
      ['каша','Kasha',100,'стоит'],['селёдка под шубой','Herring under a fur coat',190,'стоит'],['окрошка','Okroshka',170,'стоит'],['драники','Draniki',160,'стоят'],
      ['квас','Kvass',80,'стоит'],['кулич','Kulich',130,'стоит'],['сырники','Syrniki',200,'стоят'],['пирог','Pirog',240,'стоит']
    ];
    const billHotspots=[...bill.querySelectorAll('[data-bill-item]')];
    const billNumbers=[...bill.querySelectorAll('[data-bill-people]')];
    let billIndex=-1,billPeople=3;
    const rubleForm=n=>{const last=n%10,teens=n%100;return teens>=11&&teens<=14?'рублей':last===1?'рубль':last>=2&&last<=4?'рубля':'рублей';};
    // Highlight only the changing word ending; keep all other text unmodified.
    function renderRussianEnding(element, prefix, stem, ending, suffix = "") {
        element.replaceChildren();
        element.appendChild(document.createTextNode(prefix + stem));

        const endingSpan = document.createElement("span");
        endingSpan.className = "rw-ruble__ending";
        endingSpan.textContent = ending;
        element.appendChild(endingSpan);

        if (suffix) {
            element.appendChild(document.createTextNode(suffix));
        }
    }

    function rubleEnding(amount) {
        const form = rubleForm(amount);
        return form.slice(3);
    }

    const peopleWords=['','одного','двоих','троих','четверых'];
    // Ruble Discovery Lens: all controls are authored in HTML; JS updates their content.
    const rubleOverlay=bill.querySelector('#rw-ruble-overlay');
    const rubleInput=bill.querySelector('#rw-ruble-amount');
    const rubleSlider=bill.querySelector('#rw-ruble-slider');
    const rubleOpen=bill.querySelector('#rw-ruble-open');
    const rubleClose=bill.querySelector('#rw-ruble-close');
    let rubleReturnFocus=null;
    let currentBillTotal=null;
    const rubleCategory=n=>{const last=n%10, lastTwo=n%100;return lastTwo>=11&&lastTwo<=14?'many':last===1?'one':last>=2&&last<=4?'few':'many';};
    const rubleReason=n=>{const last=n%10,lastTwo=n%100;if(lastTwo>=11&&lastTwo<=14)return `${n} ends in ${lastTwo}. That's the surprise: use рублей!`;return `${n} ends in ${last}, so use ${rubleForm(n)}.`;};
    function updateRubleSnapshot(total){
      currentBillTotal=total;
      const currentDisplay = bill.querySelector('#rw-ruble-current');
      if (total === null) {
          currentDisplay.textContent = "—";
      } else {
          renderRussianEnding(currentDisplay, `${total} `, "руб", rubleEnding(total));
      }
      bill.querySelector('#rw-ruble-why').textContent=total===null?'Select a dish to discover the rule.':rubleReason(total);
    }
    function renderRubleExperiment(value){
      const n=Math.max(1,Math.min(9999,Math.round(Number(value)||1)));
      rubleInput.value=String(n);
      rubleSlider.value=String(Math.min(n,200));
      renderRussianEnding(
          bill.querySelector('#rw-ruble-result'),
          `${n} `,
          "руб",
          rubleEnding(n)
      );
      bill.querySelector('#rw-ruble-reason').textContent=rubleReason(n);
      bill.querySelectorAll('[data-ruble-pattern]').forEach(card=>card.classList.toggle('is-active',card.dataset.rublePattern===rubleCategory(n)));
    }
    function closeRubleLens(){rubleOverlay.hidden=true;if(rubleReturnFocus&&rubleReturnFocus.isConnected)rubleReturnFocus.focus();}
    rubleOpen.addEventListener('click',()=>{rubleReturnFocus=document.activeElement;renderRubleExperiment(currentBillTotal===null?121:currentBillTotal);rubleOverlay.hidden=false;rubleClose.focus();});
    rubleClose.addEventListener('click',closeRubleLens);
    rubleOverlay.addEventListener('click',event=>{if(event.target===rubleOverlay)closeRubleLens();});
    rubleOverlay.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();closeRubleLens();}if(event.key==='Tab'){const controls=[rubleClose,bill.querySelector('#rw-ruble-minus'),rubleInput,bill.querySelector('#rw-ruble-plus'),rubleSlider];const i=controls.indexOf(document.activeElement);if(event.shiftKey&&i===0){event.preventDefault();controls[controls.length-1].focus();}else if(!event.shiftKey&&i===controls.length-1){event.preventDefault();controls[0].focus();}}});
    bill.querySelector('#rw-ruble-minus').addEventListener('click',()=>renderRubleExperiment(Number(rubleInput.value)-1));
    bill.querySelector('#rw-ruble-plus').addEventListener('click',()=>renderRubleExperiment(Number(rubleInput.value)+1));
    rubleInput.addEventListener('input',()=>{if(rubleInput.value!=='')renderRubleExperiment(rubleInput.value);});
    rubleInput.addEventListener('change',()=>renderRubleExperiment(rubleInput.value));
    rubleSlider.addEventListener('input',()=>renderRubleExperiment(rubleSlider.value));
    function renderBill(){
      billHotspots.forEach((b,i)=>b.setAttribute('aria-pressed',String(i===billIndex)));
      billNumbers.forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.billPeople)===billPeople)));
      bill.querySelector('#rw-bill-people-count').textContent=String(billPeople);
      bill.querySelector('#rw-bill-request').textContent=`На ${peopleWords[billPeople]}, пожалуйста.`;
      bill.querySelector('#rw-bill-request-en').textContent=`For ${billPeople} ${billPeople===1?'person':'people'}, please.`;
      if(billIndex<0){bill.querySelector('#rw-bill-question').textContent='Сколько стоит блюдо?';bill.querySelector('#rw-bill-question-en').textContent='How much does the dish cost?';bill.querySelector('#rw-bill-unit').textContent='Выберите блюдо.';bill.querySelector('#rw-bill-unit-en').textContent='Choose a dish to see its price.';bill.querySelector('#rw-bill-total').textContent='—';bill.querySelector('#rw-bill-grammar').textContent='Choose a dish to see the ruble ending change.';updateRubleSnapshot(null);return;}
      const [ru,en,price,verb]=billDishes[billIndex];const total=price*billPeople;
      bill.querySelector('#rw-bill-question').textContent=`Сколько ${verb} ${ru}?`;
      bill.querySelector('#rw-bill-question-en').textContent=`How much ${verb==='стоят'?'do':'does'} the ${en.toLowerCase()} cost?`;
      renderRussianEnding(
          bill.querySelector('#rw-bill-unit'),
          `Одна порция — ${price} `,
          "руб",
          rubleEnding(price),
          "."
      );
      bill.querySelector('#rw-bill-unit-en').textContent=`One serving costs ${price} rubles.`;
      bill.querySelector('#rw-bill-total').textContent=`${total} ₽`;
      bill.querySelector('#rw-bill-grammar').textContent='Watch the colored ending change with your total.';
      updateRubleSnapshot(total);
    }
    billHotspots.forEach(b=>b.addEventListener('click',()=>{billIndex=Number(b.dataset.billItem);renderBill();}));
    billNumbers.forEach(b=>b.addEventListener('click',()=>{billPeople=Number(b.dataset.billPeople);renderBill();}));
    renderBill();
    menusExplorer.querySelector('#rw-menus-back').addEventListener('click',()=>{menusExplorer.hidden=true;bill.hidden=true;});
    interior.querySelector('[data-rw-spot="menus"]').addEventListener('click',()=>{
      if(interior.dataset.activeDrawer!=='real')return;
      menusExplorer.hidden=false;bill.hidden=true;screenTwo.hidden=false;
    });
    // END DRAWER THREE — MENUS RECONSTRUCTION


    // ==========================================================
    // DRAWER THREE — CONVERSATION GALLERY LANDING PAGE
    // All seven scenario buttons are explicitly authored in HTML.
    // Individual conversation environments will be built later.
    // ==========================================================

    const conversationsGallery = interior.querySelector("#rw-conversations");
    const conversationsStatus = interior.querySelector("#rw-conversations-status");
    const conversationsBack = interior.querySelector("#rw-conversations-back");
    function showConversationGallery() {
        conversationsStatus.hidden = true;
        conversationsStatus.textContent = "";
        conversationsGallery.hidden = false;
    }

    function returnToConversationDesk() {
        conversationsGallery.hidden = true;
        conversationsStatus.hidden = true;
    }

    interior.querySelector('[data-rw-spot="conversations"]').addEventListener("click", () => {
        if (interior.dataset.activeDrawer !== "real") {
            return;
        }

        showConversationGallery();
    });

    conversationsBack.addEventListener("click", returnToConversationDesk);

    // BEGIN SCENARIO 01 — DIRECT OPEN FROM THE GALLERY
    conversationsGallery.querySelector('[data-conversation-scenario="01"]')
        .addEventListener('click', openAnnaScenario);
    // END SCENARIO 01 — DIRECT OPEN FROM THE GALLERY
    // Scenarios 02–07 remain intentionally unconnected.

    // END DRAWER THREE — CONVERSATION GALLERY LANDING PAGE

    function showDrawerInterior(drawerKey) {
        drawers.hidden = true;
        stage.hidden = true;
        microscope.hidden = true;
        returnButton.hidden = true;
        status.hidden = true;
        interior.hidden = false;
        interiorTabs.forEach(tab => {
            const selected = tab.dataset.drawerTab === drawerKey;
            tab.classList.toggle('is-active', selected);
            tab.setAttribute('aria-pressed', String(selected));
        });
        interior.dataset.activeDrawer = drawerKey;
        signsExplorer.hidden = true;
        messagesExplorer.hidden = true;
        menusExplorer.hidden = true;
        bill.hidden = true;
        conversationsGallery.hidden = true;
        if (sentenceSpotlight) sentenceSpotlight.hidden = drawerKey !== 'examples';
        if (curiosityCabinet) curiosityCabinet.hidden = drawerKey !== 'special';
        const livingSentence = null;
        if (livingSentence) livingSentence.hidden = drawerKey !== 'examples';
        interior.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    function returnFromDrawerInterior(to) {
        hideSentenceSpotlight();
        hideCuriosityCabinet();
        interior.hidden = true;
        const livingSentence = null;
        if (livingSentence) livingSentence.hidden = true;
        if (to === 'drawers') {
            showDrawers();
        } else {
            closeDrawers();
        }
    }
    const drawers = lab.querySelector('.door-four__drawers');
    function showDrawers() {
        hideSentenceSpotlight();
        hideCuriosityCabinet();
        interior.hidden = true;
        const livingSentence = null;
        if (livingSentence) livingSentence.hidden = true;
        stage.hidden = true;
        microscope.hidden = true;
        returnButton.hidden = true;
        status.hidden = true;
        drawers.hidden = false;
        drawers.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    function closeDrawers() {
        hideSentenceSpotlight();
        hideCuriosityCabinet();
        interior.hidden = true;
        const livingSentence = null;
        if (livingSentence) livingSentence.hidden = true;
        drawers.hidden = true;
        stage.hidden = false;
        returnButton.hidden = false;
        status.hidden = true;
        lab.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    // END DRAWERS SECONDARY SCREEN
    const microscope = lab.querySelector('.door-four__microscope');
    const stage = lab.querySelector('.door-four__stage');
    const returnButton = lab.querySelector('.door-four__return');
    const examples = {
        brother: { my: 'мой', noun: 'брат', english: 'my brother' },
        sister: { my: 'моя', noun: 'сестра', english: 'my sister' },
        name: { my: 'моё', noun: 'имя', english: 'my name' },
        parents: { my: 'мои', noun: 'родители', english: 'my parents' }
    };
    const examined = new Set();
    const phrase = microscope.querySelector('.door-four__microscope-phrase');
    const hint = microscope.querySelector('.door-four__microscope-hint');
    const feedback = microscope.querySelector('.door-four__microscope-feedback');
    function resetMicroscope() {
        examined.clear();
        microscope.querySelectorAll('[data-micro-choice]').forEach(b => {
            b.classList.remove('is-selected');
            b.setAttribute('aria-pressed', 'false');
        });
        phrase.hidden = true;
        hint.hidden = false;
        microscope.querySelector('.door-four__microscope-translation').textContent = '';
        microscope.querySelector('.door-four__microscope-count').textContent = '0 of 4 expressions examined';
        feedback.textContent = 'Select a word to begin your investigation.';
    }
    function showMicroscope() {
        setMicroMode('guided');
        stage.hidden = true;
        returnButton.hidden = true;
        status.hidden = true;
        microscope.hidden = false;
        microscope.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    function closeMicroscope() {
        microscope.hidden = true;
        stage.hidden = false;
        returnButton.hidden = false;
        lab.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    microscope.querySelectorAll('.door-four__microscope-close').forEach(b => b.addEventListener('click', closeMicroscope));
    microscope.querySelector('.door-four__microscope-reset').addEventListener('click', resetMicroscope);
    microscope.querySelectorAll('[data-micro-choice]').forEach(button => button.addEventListener('click', () => {
        const key = button.dataset.microChoice;
        const item = examples[key];
        examined.add(key);
        microscope.querySelectorAll('[data-micro-choice]').forEach(b => {
            const active = b === button;
            b.classList.toggle('is-selected', active);
            b.setAttribute('aria-pressed', String(active));
        });
        hint.hidden = true;
        phrase.hidden = false;
        microscope.querySelector('.door-four__microscope-my').textContent = item.my;
        microscope.querySelector('.door-four__microscope-noun').textContent = item.noun;
        microscope.querySelector('.door-four__microscope-translation').textContent = item.english;
        microscope.querySelector('.door-four__microscope-count').textContent =
            `${examined.size} of 4 expressions examined`;
        if (examined.size === 4) feedback.textContent = 'Discovery! MY changes to match the noun: masculine, feminine, neuter, or plural.';
    }));
    // BEGIN MICROSCOPE — GUIDED / YOU CHOOSE (scoped, additive)
    const choosePanel = microscope.querySelector('.door-four__microscope-choose');
    const referenceGrid = microscope.querySelector('.door-four__microscope-discovery');
    const guidedButtons = microscope.querySelector('.door-four__microscope-choices');
    const guidedPrompt = microscope.querySelector('.door-four__microscope-prompt');
    const genderSelect = microscope.querySelector('[data-micro-gender]');
    const wordSelect = microscope.querySelector('[data-micro-word]');
    const changeMessage = microscope.querySelector('.door-four__microscope-change');
    const reason = microscope.querySelector('.door-four__microscope-reason');
    const explainButton = microscope.querySelector('.door-four__microscope-explain');
    // BEGIN MICROSCOPE — EXPANDED WORD BANK
    const microscopeWords = [
        { "id": "brother", "label": "Brother", "singular": "брат", "plural": "братья", "gender": "masculine", "my": "мой", "enPlural": "brothers", "note": "" },
        { "id": "sister", "label": "Sister", "singular": "сестра", "plural": "сёстры", "gender": "feminine", "my": "моя", "enPlural": "sisters", "note": "" },
        { "id": "relative-m", "label": "Relative (male)", "singular": "родственник", "plural": "родственники", "gender": "masculine", "my": "мой", "enPlural": "male relatives", "note": "" },
        { "id": "relative-f", "label": "Relative (female)", "singular": "родственница", "plural": "родственницы", "gender": "feminine", "my": "моя", "enPlural": "female relatives", "note": "" },
        { "id": "cousin-m", "label": "Cousin (male)", "singular": "двоюродный брат", "plural": "двоюродные братья", "gender": "masculine", "my": "мой", "enPlural": "male cousins", "note": "" },
        { "id": "cousin-f", "label": "Cousin (female)", "singular": "двоюродная сестра", "plural": "двоюродные сёстры", "gender": "feminine", "my": "моя", "enPlural": "female cousins", "note": "" },
        { "id": "father", "label": "Father", "singular": "отец", "plural": "отцы", "gender": "masculine", "my": "мой", "enPlural": "fathers", "note": "" },
        { "id": "mother", "label": "Mother", "singular": "мать", "plural": "матери", "gender": "feminine", "my": "моя", "enPlural": "mothers", "note": "Notice the unusual plural: мать → матери." },
        { "id": "uncle", "label": "Uncle", "singular": "дядя", "plural": "дяди", "gender": "masculine", "my": "мой", "enPlural": "uncles", "note": "Masculine, despite its -я ending." },
        { "id": "aunt", "label": "Aunt", "singular": "тётя", "plural": "тёти", "gender": "feminine", "my": "моя", "enPlural": "aunts", "note": "" },
        { "id": "name", "label": "Name", "singular": "имя", "plural": "имена", "gender": "neuter", "my": "моё", "enPlural": "names", "note": "" },
        { "id": "child-archaic", "label": "Child (дитя)", "singular": "дитя", "plural": "дети", "gender": "neuter", "my": "моё", "enPlural": "children", "note": "Дитя is a literary word; everyday Russian usually uses ребёнок." },
        { "id": "grandfather", "label": "Grandfather", "singular": "дедушка", "plural": "дедушки", "gender": "masculine", "my": "мой", "enPlural": "grandfathers", "note": "Masculine even though дедушка ends in -а." },
        { "id": "grandmother", "label": "Grandmother", "singular": "бабушка", "plural": "бабушки", "gender": "feminine", "my": "моя", "enPlural": "grandmothers", "note": "" },
        { "id": "dog", "label": "Dog", "singular": "собака", "plural": "собаки", "gender": "feminine", "my": "моя", "enPlural": "dogs", "note": "Собака is grammatically feminine, even when referring to a male dog." },
        { "id": "cat-m", "label": "Cat (male)", "singular": "кот", "plural": "коты", "gender": "masculine", "my": "мой", "enPlural": "male cats", "note": "" },
        { "id": "cat-f", "label": "Cat (female)", "singular": "кошка", "plural": "кошки", "gender": "feminine", "my": "моя", "enPlural": "female cats", "note": "" },
        { "id": "bird", "label": "Bird", "singular": "птица", "plural": "птицы", "gender": "feminine", "my": "моя", "enPlural": "birds", "note": "" },
        { "id": "surname", "label": "Last name / surname", "singular": "фамилия", "plural": "фамилии", "gender": "feminine", "my": "моя", "enPlural": "last names", "note": "“My last names” is possible when someone has multiple surnames, but uncommon." },
        { "id": "son", "label": "Son", "singular": "сын", "plural": "сыновья", "gender": "masculine", "my": "мой", "enPlural": "sons", "note": "Сын → сыновья is an irregular plural." },
        { "id": "daughter", "label": "Daughter", "singular": "дочь", "plural": "дочери", "gender": "feminine", "my": "моя", "enPlural": "daughters", "note": "Дочь → дочери changes its stem." },
        { "id": "husband", "label": "Husband", "singular": "муж", "plural": "мужья", "gender": "masculine", "my": "мой", "enPlural": "husbands", "note": "Муж → мужья is an irregular plural." },
        { "id": "wife", "label": "Wife", "singular": "жена", "plural": "жёны", "gender": "feminine", "my": "моя", "enPlural": "wives", "note": "" },
        { "id": "friend", "label": "Friend (male)", "singular": "друг", "plural": "друзья", "gender": "masculine", "my": "мой", "enPlural": "male friends", "note": "Друг → друзья is an irregular plural." },
        { "id": "patronymic", "label": "Patronymic", "singular": "отчество", "plural": "отчества", "gender": "neuter", "my": "моё", "enPlural": "patronymics", "note": "" },
        { "id": "animal", "label": "Animal", "singular": "животное", "plural": "животные", "gender": "neuter", "my": "моё", "enPlural": "animals", "note": "Животное is a neuter noun formed from an adjective." },
        { "id": "letter", "label": "Letter (message)", "singular": "письмо", "plural": "письма", "gender": "neuter", "my": "моё", "enPlural": "letters", "note": "" },
        { "id": "word", "label": "Word", "singular": "слово", "plural": "слова", "gender": "neuter", "my": "моё", "enPlural": "words", "note": "" },
        { "id": "child", "label": "Child (ребёнок)", "singular": "ребёнок", "plural": "дети", "gender": "masculine", "my": "мой", "enPlural": "children", "note": "Ребёнок → дети: the plural uses a different root." },
        { "id": "person", "label": "Person", "singular": "человек", "plural": "люди", "gender": "masculine", "my": "мой", "enPlural": "people", "note": "Человек → люди: the plural uses a different root. “My people” needs context." },
        { "id": "parents", "label": "Parent(s)", "singular": "родитель", "plural": "родители", "gender": "masculine", "my": "мой", "enPlural": "parents", "note": "Родитель is one parent; родители usually means parents together." },
    ];
    // END MICROSCOPE — EXPANDED WORD BANK
    let microNumber = 'singular';
    function updateMicroWordOptions() {
        const filtered = microscopeWords.filter(w => genderSelect.value === 'all' || w.gender === genderSelect.value);
        const old = wordSelect.value;
        wordSelect.replaceChildren();
        filtered.forEach(w => {
            const option = document.createElement('option');
            option.value = w.id;
            option.textContent = w.label;
            wordSelect.appendChild(option);
        });
        if (filtered.some(w => w.id === old)) wordSelect.value = old;
        updateMicroChoice();
    }
    function updateMicroChoice() {
        const w = microscopeWords.find(item => item.id === wordSelect.value);
        if (!w) return;
        const plural = microNumber === 'plural';
        const possessive = plural ? 'мои' : w.my;
        hint.hidden = true;
        phrase.hidden = false;
        microscope.querySelector('.door-four__microscope-my').textContent = possessive;
        microscope.querySelector('.door-four__microscope-noun').textContent = plural ? w.plural : w.singular;
        microscope.querySelector('.door-four__microscope-translation').textContent =
            'my ' + (plural ? w.enPlural : w.label.toLowerCase());
        microscope.querySelectorAll('[data-micro-number]').forEach(b =>
            b.setAttribute('aria-pressed', String(b.dataset.microNumber === microNumber)));
        changeMessage.textContent = plural
            ? `One → many: ${w.singular} → ${w.plural}; ${w.my} → мои.`
            : `One ${w.label.toLowerCase()}: ${w.my} ${w.singular}. Try “More than one.”`;
        const singularComparison = microscope.querySelector('[data-micro-compare-singular]');
        const pluralComparison = microscope.querySelector('[data-micro-compare-plural]');
        const discoveryNote = microscope.querySelector('[data-micro-discovery-note]');
        singularComparison.textContent = `${w.my} ${w.singular}`;
        pluralComparison.textContent = `мои ${w.plural}`;
        // Keep the illuminated comparison synchronized for every word and category.
        singularComparison.parentElement.classList.toggle('is-active', !plural);
        pluralComparison.parentElement.classList.toggle('is-active', plural);
        discoveryNote.textContent = w.note || 'Compare the noun and the word for MY. What changes?';
        reason.textContent = plural
            ? `Plural nouns use мои, regardless of the noun’s singular gender. The noun also changes to its plural form: ${w.plural}.`
            : `${w.singular} is a ${w.gender} singular noun, so MY is ${w.my}. Grammatical gender belongs to the noun.`;
    }
    function setMicroMode(mode) {
        const choosing = mode === 'choose';
        choosePanel.hidden = !choosing;
        referenceGrid.hidden = false;
        guidedButtons.hidden = false;
        guidedPrompt.hidden = false;
        microscope.querySelectorAll('[data-micro-mode]').forEach(b =>
            b.setAttribute('aria-pressed', String(b.dataset.microMode === mode)));
        if (choosing) updateMicroChoice();
        else {
            resetMicroscope();
            feedback.textContent = 'Guided Discovery is ready. Click брат, сестра, имя, or родители to examine the four forms of MY.';
        }
    }
    microscope.querySelectorAll('[data-micro-mode]').forEach(b => b.addEventListener('click', () => setMicroMode(b.dataset.microMode)));
    genderSelect.addEventListener('change', updateMicroWordOptions);
    wordSelect.addEventListener('change', updateMicroChoice);
    microscope.querySelectorAll('[data-micro-number]').forEach(b => b.addEventListener('click', () => {
        microNumber = b.dataset.microNumber;
        updateMicroChoice();
    }));
    explainButton.addEventListener('click', () => {
        reason.hidden = !reason.hidden;
        explainButton.setAttribute('aria-expanded', String(!reason.hidden));
    });
    updateMicroWordOptions();
    // END MICROSCOPE — GUIDED / YOU CHOOSE
    // END UNDER THE MICROSCOPE — interactive first experiment
    lab.addEventListener('click', (event) => {
        // The shared drawer workspace has its own navigation attributes.
        // Delegate all three hotspot types so the six illustrated buttons work.
        const hotspot = event.target.closest('[data-lab-action], [data-drawer-tab], [data-drawer-nav]');
        if (!hotspot || !lab.contains(hotspot)) return;
        const action = hotspot.dataset.labAction;
        if (action === 'microscope') { showMicroscope(); return; }
        if (action === 'drawers') { showDrawers(); return; }
        if (hotspot.dataset.drawerTab) { showDrawerInterior(hotspot.dataset.drawerTab); return; }
        if (hotspot.dataset.drawerNav) { returnFromDrawerInterior(hotspot.dataset.drawerNav); return; }
        const drawerActions = { 'drawer-examples': 'examples', 'drawer-special': 'special', 'drawer-real': 'real', 'drawer-notes': 'notes' };
        if (drawerActions[action]) { showDrawerInterior(drawerActions[action]); return; }
        if (action === 'drawers-back') { closeDrawers(); return; }
        status.textContent = messages[action] || 'This discovery is being prepared.';
        status.hidden = false;
    });
})();
// ============================================================
// END DOOR FOUR — RUSSIAN LANGUAGE LABORATORY
// ============================================================


// ==================================================
// LESSON 2 — COUSIN GRAMMAR CANDY
// Two choice buttons; one shared display area.
// Click the active Candy again to close it.
// ==================================================

const cousinGrammarCandy =
    document.querySelector("#lesson-2-cousin-grammar-candy");

const cousinGrammarCandyDisplay =
    document.querySelector("#lesson-2-cousin-grammar-candy-display");


cousinGrammarCandy
    ?.querySelectorAll("[data-cousin-candy]")
    .forEach((button) => {

        button.addEventListener("click", () => {

            const candyKey =
                button.dataset.cousinCandy;

            const wasActive =
                button.classList.contains("is-active");


            // Clear both buttons first.
            cousinGrammarCandy
                .querySelectorAll("[data-cousin-candy]")
                .forEach((choice) => {

                    choice.classList.remove("is-active");
                    choice.setAttribute("aria-pressed", "false");

                });


            // Hide both graphics first.
            cousinGrammarCandy
                .querySelectorAll("[data-cousin-candy-panel]")
                .forEach((panel) => {

                    panel.hidden = true;

                });


            // Clicking the currently open Candy closes the display.
            if (wasActive) {

                if (cousinGrammarCandyDisplay) {
                    cousinGrammarCandyDisplay.hidden = true;
                }

                return;
            }


            // Find the graphic that belongs to the selected Candy.
            const selectedPanel =
                cousinGrammarCandy.querySelector(
                    `[data-cousin-candy-panel="${candyKey}"]`
                );


            button.classList.add("is-active");
            button.setAttribute("aria-pressed", "true");


            if (selectedPanel) {
                selectedPanel.hidden = false;
            }


            if (cousinGrammarCandyDisplay) {
                cousinGrammarCandyDisplay.hidden = false;
            }

        });

    });


// One universal control closes whichever cousin Grammar Candy is open.
document
    .querySelector("#lesson-2-cousin-grammar-candy-collapse")
    ?.addEventListener("click", () => {

        cousinGrammarCandy
            ?.querySelectorAll("[data-cousin-candy]")
            .forEach((choice) => {

                choice.classList.remove("is-active");
                choice.setAttribute("aria-pressed", "false");

            });


        cousinGrammarCandy
            ?.querySelectorAll("[data-cousin-candy-panel]")
            .forEach((panel) => {

                panel.hidden = true;

            });


        if (cousinGrammarCandyDisplay) {
            cousinGrammarCandyDisplay.hidden = true;
        }

    });


// ==================================================
// LESSON 3 — IN-LAW & MARITAL STATUS GRAMMAR CANDY
// Four choice buttons; one shared display area.
// Click the active Candy again to close it.
// Same pattern as the Lesson 2 cousin Grammar Candy
// above — only the id/data-attribute names change.
// ==================================================

const inlawGrammarCandy =
    document.querySelector("#lesson-3-inlaw-grammar-candy");

const inlawGrammarCandyDisplay =
    document.querySelector("#lesson-3-inlaw-grammar-candy-display");


inlawGrammarCandy
    ?.querySelectorAll("[data-inlaw-candy]")
    .forEach((button) => {

        button.addEventListener("click", () => {

            const candyKey =
                button.dataset.inlawCandy;

            const wasActive =
                button.classList.contains("is-active");


            // Clear all four buttons first.
            inlawGrammarCandy
                .querySelectorAll("[data-inlaw-candy]")
                .forEach((choice) => {

                    choice.classList.remove("is-active");
                    choice.setAttribute("aria-pressed", "false");

                });


            // Hide all four graphics first.
            inlawGrammarCandy
                .querySelectorAll("[data-inlaw-candy-panel]")
                .forEach((panel) => {

                    panel.hidden = true;

                });


            // Clicking the currently open Candy closes the display.
            if (wasActive) {

                if (inlawGrammarCandyDisplay) {
                    inlawGrammarCandyDisplay.hidden = true;
                }

                return;
            }


            // Find the graphic that belongs to the selected Candy.
            const selectedPanel =
                inlawGrammarCandy.querySelector(
                    `[data-inlaw-candy-panel="${candyKey}"]`
                );


            button.classList.add("is-active");
            button.setAttribute("aria-pressed", "true");


            if (selectedPanel) {
                selectedPanel.hidden = false;
            }


            if (inlawGrammarCandyDisplay) {
                inlawGrammarCandyDisplay.hidden = false;
            }

        });

    });


// One universal control closes whichever in-law Grammar Candy is open.
document
    .querySelector("#lesson-3-inlaw-grammar-candy-collapse")
    ?.addEventListener("click", () => {

        inlawGrammarCandy
            ?.querySelectorAll("[data-inlaw-candy]")
            .forEach((choice) => {

                choice.classList.remove("is-active");
                choice.setAttribute("aria-pressed", "false");

            });


        inlawGrammarCandy
            ?.querySelectorAll("[data-inlaw-candy-panel]")
            .forEach((panel) => {

                panel.hidden = true;

            });


        if (inlawGrammarCandyDisplay) {
            inlawGrammarCandyDisplay.hidden = true;
        }

    });


// ==================================================
// LESSON 1 — GRAMMAR CANDY
// Four choice buttons; one shared display area.
// Click the active Candy again to close it.
// Same pattern as the Lesson 2 cousin and Lesson 3
// in-law Grammar Candy above — only the id/data-
// attribute names change.
// ==================================================

const lesson1GrammarCandy =
    document.querySelector("#lesson-1-grammar-candy");

const lesson1GrammarCandyDisplay =
    document.querySelector("#lesson-1-grammar-candy-display");


lesson1GrammarCandy
    ?.querySelectorAll("[data-lesson1-candy]")
    .forEach((button) => {

        button.addEventListener("click", () => {

            const candyKey =
                button.dataset.lesson1Candy;

            const wasActive =
                button.classList.contains("is-active");


            // Clear all four buttons first.
            lesson1GrammarCandy
                .querySelectorAll("[data-lesson1-candy]")
                .forEach((choice) => {

                    choice.classList.remove("is-active");
                    choice.setAttribute("aria-pressed", "false");

                });


            // Hide all four graphics first.
            lesson1GrammarCandy
                .querySelectorAll("[data-lesson1-candy-panel]")
                .forEach((panel) => {

                    panel.hidden = true;

                });


            // Clicking the currently open Candy closes the display.
            if (wasActive) {

                if (lesson1GrammarCandyDisplay) {
                    lesson1GrammarCandyDisplay.hidden = true;
                }

                return;
            }


            // Find the graphic that belongs to the selected Candy.
            const selectedPanel =
                lesson1GrammarCandy.querySelector(
                    `[data-lesson1-candy-panel="${candyKey}"]`
                );


            button.classList.add("is-active");
            button.setAttribute("aria-pressed", "true");


            if (selectedPanel) {
                selectedPanel.hidden = false;
            }


            if (lesson1GrammarCandyDisplay) {
                lesson1GrammarCandyDisplay.hidden = false;
            }

        });

    });


// One universal control closes whichever Lesson 1 Grammar Candy is open.
document
    .querySelector("#lesson-1-grammar-candy-collapse")
    ?.addEventListener("click", () => {

        lesson1GrammarCandy
            ?.querySelectorAll("[data-lesson1-candy]")
            .forEach((choice) => {

                choice.classList.remove("is-active");
                choice.setAttribute("aria-pressed", "false");

            });


        lesson1GrammarCandy
            ?.querySelectorAll("[data-lesson1-candy-panel]")
            .forEach((panel) => {

                panel.hidden = true;

            });


        if (lesson1GrammarCandyDisplay) {
            lesson1GrammarCandyDisplay.hidden = true;
        }

    });


// ==================================================
// LESSON 2 — EMBEDDED LANGUAGE DISCOVERIES
// Notice → Try → Understand
// These are NOT Grammar Candy.
// ==================================================


// --------------------------------------------------
// DISCOVERY 1 — ADD INFORMATION
// Older / Younger / Twin
// --------------------------------------------------

document
    .querySelectorAll("#family-descriptor-discovery [data-descriptor-demo]")
    .forEach((demo) => {

        const button =
            demo.querySelector(".descriptor-reveal");

        const result =
            demo.querySelector(".descriptor-demo__result");

        const russian =
            result?.querySelector("strong");

        const meaning =
            result?.querySelector("span");


        button?.addEventListener("click", () => {

            const isOpen =
                !result.hidden;


            if (isOpen) {

                result.hidden = true;
                button.classList.remove("is-active");
                return;
            }


            russian.textContent =
                button.dataset.result;

            meaning.textContent =
                button.dataset.meaning;

            result.hidden = false;
            button.classList.add("is-active");

        });

    });


// --------------------------------------------------
// DISCOVERY 2 — WHOSE FAMILY?
// твой / его / её / их
// --------------------------------------------------

const ownerChoices =
    document.querySelectorAll(
        "#family-owner-discovery .owner-choice"
    );

const ownerRussian =
    document.querySelector("#owner-live-russian");

const ownerEnglish =
    document.querySelector("#owner-live-english");

const ownerListen =
    document.querySelector("#owner-live-listen");


ownerChoices.forEach((button) => {

    button.addEventListener("click", () => {

        ownerChoices.forEach((choice) => {
            choice.classList.remove("is-active");
        });


        button.classList.add("is-active");


        const word =
            button.dataset.ownerWord;

        const meaning =
            button.dataset.ownerMeaning;

        const sentence =
            button.dataset.ownerSentence;


        if (ownerRussian) {
            ownerRussian.textContent = sentence;
        }


        if (ownerEnglish) {
            ownerEnglish.textContent =
                `${meaning.charAt(0).toUpperCase() + meaning.slice(1)} brother lives in Moscow.`;
        }


        if (ownerListen) {
            ownerListen.dataset.speak = sentence;
            ownerListen.disabled = false;
        }

    });

});


// Quick Try — Anna's brother = её брат
document
    .querySelectorAll(
        "#family-owner-discovery [data-owner-answer]"
    )
    .forEach((button) => {

        button.addEventListener("click", () => {

            const feedback =
                document.querySelector(
                    "#owner-challenge-feedback"
                );

            const buttons =
                document.querySelectorAll(
                    "#family-owner-discovery [data-owner-answer]"
                );


            buttons.forEach((choice) => {
                choice.classList.remove("selected");
            });


            button.classList.add("selected");


            const isCorrect =
                button.dataset.ownerAnswer === "её";


            if (feedback) {

                feedback.textContent =
                    isCorrect
                        ? "Exactly — Anna is female, so you are talking about her brother: её брат."
                        : "Not quite. The family belongs to Anna. Which word means \"her\"?";

                feedback.className =
                    "feedback " +
                    (isCorrect ? "good" : "bad");

            }

        });

    });


// --------------------------------------------------
// DISCOVERY 3 — ASK AND ANSWER
// жить stays живёт no matter whose family it is
// --------------------------------------------------

const familyLiveChoices =
    document.querySelectorAll(
        "#live-verb-discovery .owner-choice"
    );

const familyLiveQuestionRu =
    document.querySelector("#family-live-question-ru");

const familyLiveQuestionEn =
    document.querySelector("#family-live-question-en");

const familyLiveAnswerRu =
    document.querySelector("#family-live-answer-ru");

const familyLiveAnswerEn =
    document.querySelector("#family-live-answer-en");

const familyLiveListen =
    document.querySelector("#family-live-listen");

const familyLivePayoff =
    document.querySelector("#live-verb-payoff");

const familyLiveCompareLabel =
    document.querySelector("#family-live-compare-label");

const familyLiveCompareSentence =
    document.querySelector("#family-live-compare-sentence");


familyLiveChoices.forEach((button) => {

    button.addEventListener("click", () => {

        familyLiveChoices.forEach((choice) => {
            choice.classList.remove("is-active");
        });


        button.classList.add("is-active");


        const questionRu =
            button.dataset.familyQuestionRu;

        const questionEn =
            button.dataset.familyQuestionEn;

        const answerRu =
            button.dataset.familyAnswerRu;

        const answerEn =
            button.dataset.familyAnswerEn;

        const personLabel =
            button.dataset.familyPersonLabel;


        if (familyLiveQuestionRu) {
            familyLiveQuestionRu.textContent = questionRu;
        }


        if (familyLiveQuestionEn) {
            familyLiveQuestionEn.textContent = questionEn;
        }


        if (familyLiveAnswerRu) {
            familyLiveAnswerRu.textContent = answerRu;
        }


        if (familyLiveAnswerEn) {
            familyLiveAnswerEn.textContent = answerEn;
        }


        if (familyLiveListen) {
            familyLiveListen.dataset.speak = answerRu;
            familyLiveListen.disabled = false;
        }


        if (familyLiveCompareLabel) {
            familyLiveCompareLabel.textContent = personLabel;
        }


        if (familyLiveCompareSentence) {
            familyLiveCompareSentence.textContent = answerRu;
        }


        if (familyLivePayoff) {
            familyLivePayoff.hidden = false;
        }

    });

});


// --------------------------------------------------
// LESSON 3 — WATCH ЛЮБИТЬ CHANGE WITH EVERY SUBJECT
// Same owner-choice mechanic as Lesson 2 Discovery 2,
// except the object is fixed (свою семью) so only the
// subject/verb pair changes on screen.
// --------------------------------------------------

const lyubitChoices =
    document.querySelectorAll(
        "#lyubit-subject-discovery .owner-choice"
    );

const lyubitLiveRussian =
    document.querySelector("#lyubit-live-russian");

const lyubitLiveEnglish =
    document.querySelector("#lyubit-live-english");

const lyubitLiveListen =
    document.querySelector("#lyubit-live-listen");


lyubitChoices.forEach((button) => {

    button.addEventListener("click", () => {

        lyubitChoices.forEach((choice) => {
            choice.classList.remove("is-active");
        });


        button.classList.add("is-active");


        const sentence =
            button.dataset.lyubitSentence;

        const english =
            button.dataset.lyubitEnglish;


        if (lyubitLiveRussian) {
            lyubitLiveRussian.textContent = sentence;
        }


        if (lyubitLiveEnglish) {
            lyubitLiveEnglish.textContent = english;
        }


        if (lyubitLiveListen) {
            lyubitLiveListen.dataset.speak = sentence;
            lyubitLiveListen.disabled = false;
        }

    });

});


// Quick Try — они любят свою семью
document
    .querySelectorAll(
        "#lyubit-subject-discovery [data-lyubit-answer]"
    )
    .forEach((button) => {

        button.addEventListener("click", () => {

            const feedback =
                document.querySelector(
                    "#lyubit-challenge-feedback"
                );

            const buttons =
                document.querySelectorAll(
                    "#lyubit-subject-discovery [data-lyubit-answer]"
                );


            buttons.forEach((choice) => {
                choice.classList.remove("selected");
            });


            button.classList.add("selected");


            const isCorrect =
                button.dataset.lyubitAnswer === "любят";


            if (feedback) {

                feedback.textContent =
                    isCorrect
                        ? "Exactly — они (they) takes любят."
                        : "Not quite. The subject is они (they). Which ending goes with они?";

                feedback.className =
                    "feedback " +
                    (isCorrect ? "good" : "bad");

            }

        });

    });


// ==================================================
// PASS 1 — THE COMBINATOR
// Two independent dials: possessive + family noun
// ==================================================

(() => {

    const root =
        document.querySelector("#pass-1-combinator");

    if (!root) {
        return;
    }

    const dialButtons =
        [...root.querySelectorAll(".owner-choice[data-dial]")];

    const livePhrase =
        root.querySelector("#pass1-live-phrase");

    const listenBtn =
        root.querySelector("#pass1-listen");

    const sayBtn =
        root.querySelector("#pass1-say");

    const feedback =
        root.querySelector("#pass1-feedback");

    let selectedPossessive = null;
    let selectedNoun = null;
    let selectedNounGender = null;

    const wrongAttemptsByNoun = {};


    function updatePhrase() {

        const possessiveText =
            selectedPossessive || "___";

        const nounText =
            selectedNoun || "___";

        livePhrase.textContent =
            `${possessiveText} ${nounText}`;


        if (!selectedPossessive || !selectedNoun) {

            listenBtn.disabled = true;
            listenBtn.dataset.speak = "";

            sayBtn.disabled = true;
            sayBtn.dataset.target = "";

            feedback.textContent = "";
            feedback.className = "feedback";

            return;
        }


        listenBtn.disabled = false;
        listenBtn.dataset.speak =
            `${selectedPossessive} ${selectedNoun}`;


        const isCorrect =
            selectedPossessive === selectedNounGender;


        if (isCorrect) {

            sayBtn.disabled = false;
            sayBtn.dataset.target =
                `${selectedPossessive} ${selectedNoun}`;

            feedback.textContent =
                "That's right!";

            feedback.className =
                "feedback good";

            return;
        }


        sayBtn.disabled = true;
        sayBtn.dataset.target = "";

        const attempts =
            (wrongAttemptsByNoun[selectedNoun] || 0) + 1;

        wrongAttemptsByNoun[selectedNoun] = attempts;

        feedback.textContent =
            attempts === 1
                ? "Does that sound right to you? Have you chosen the right pronoun?"
                : `${selectedNoun} is a word that needs ${selectedNounGender} — try choosing it again.`;

        feedback.className =
            "feedback bad";

    }


    dialButtons.forEach((button) => {

        button.addEventListener("click", () => {

            const dial =
                button.dataset.dial;

            root
                .querySelectorAll(`.owner-choice[data-dial="${dial}"]`)
                .forEach((choice) => {
                    choice.classList.remove("is-active");
                });

            button.classList.add("is-active");


            if (dial === "possessive") {

                selectedPossessive =
                    button.dataset.value;

            } else {

                selectedNoun =
                    button.dataset.value;

                selectedNounGender =
                    button.dataset.gender;

            }

            updatePhrase();

        });

    });

})();

// ==================================================
// PASS 2 — TYPE IT YOURSELF
// Typed possessive blanks: мать, отец, семья
// ==================================================

(() => {

    const container =
        document.querySelector("#pass2-rows");

    if (!container) {
        return;
    }

    const rows =
        [...container.querySelectorAll(".pass2-row")];

    // Reuse the same shuffle() already defined for
    // the Match What You Know practice activity.
    shuffle(rows).forEach((row) => {
        container.appendChild(row);
    });


    const wrongAttemptsByNoun = {};


    rows.forEach((row) => {

        const noun =
            row.dataset.noun;

        const gender =
            row.dataset.gender;

        const input =
            row.querySelector(".pass2-input");

        const listenBtn =
            row.querySelector(".listen");

        const sayBtn =
            row.querySelector(".say");

        const feedback =
            row.querySelector(".feedback");


        function checkAnswer() {

            const typed =
                normalize(input.value);

            if (!typed) {
                return;
            }


            listenBtn.disabled = false;
            listenBtn.dataset.speak =
                `${input.value.trim()} ${noun}`;


            const isCorrect =
                typed === normalize(gender);


            if (isCorrect) {

                sayBtn.disabled = false;
                sayBtn.dataset.target =
                    `${gender} ${noun}`;

                feedback.textContent =
                    "That's right!";

                feedback.className =
                    "feedback good";

                return;
            }


            sayBtn.disabled = true;
            sayBtn.dataset.target = "";

            const attempts =
                (wrongAttemptsByNoun[noun] || 0) + 1;

            wrongAttemptsByNoun[noun] = attempts;

            feedback.textContent =
                attempts === 1
                    ? "Does that sound right to you? Have you chosen the right pronoun?"
                    : `${noun} is a word that needs ${gender} — try typing it again.`;

            feedback.className =
                "feedback bad";

        }


        input.addEventListener("keydown", (e) => {

            if (e.key === "Enter") {
                checkAnswer();
            }

        });

        input.addEventListener("blur", checkAnswer);

    });

})();



// ==================================================
// PASS 3 — INSIDE A REAL SENTENCE
// Predict -> Reveal -> Produce, one item at a time
// ==================================================

(() => {

    const root =
        document.querySelector("#pass-3");

    if (!root) {
        return;
    }

    root.querySelectorAll(".reveal-btn").forEach((button) => {

        button.addEventListener("click", () => {

            const box =
                button.nextElementSibling;

            if (box) {
                box.hidden = false;
            }

            button.disabled = true;

        });

    });


    root.querySelectorAll(".pass3-reveal").forEach((box) => {

        const input =
            box.querySelector(".pass3-input");

        const answer =
            input.dataset.answer;

        const rule =
            box.dataset.rule;

        const listenBtn =
            box.querySelector(".listen");

        const sayBtn =
            box.querySelector(".say");

        const feedback =
            box.querySelector(".feedback");

        let attempts = 0;


        function fullSentence() {

            const before =
                input.previousSibling ? input.previousSibling.textContent : "";

            const after =
                input.nextSibling ? input.nextSibling.textContent : "";

            return `${before}${input.value.trim()}${after}`.trim();

        }


        function checkAnswer() {

            const typed =
                normalize(input.value);

            if (!typed) {
                return;
            }


            listenBtn.disabled = false;
            listenBtn.dataset.speak =
                fullSentence();


            const isCorrect =
                typed === normalize(answer);


            if (isCorrect) {

                sayBtn.disabled = false;
                sayBtn.dataset.target =
                    fullSentence();

                feedback.textContent =
                    "That's right!";

                feedback.className =
                    "feedback good";

                return;
            }


            sayBtn.disabled = true;
            sayBtn.dataset.target = "";

            attempts++;

            feedback.textContent =
                attempts === 1
                    ? "Does that sound right to you? Have you chosen the right pronoun?"
                    : rule;

            feedback.className =
                "feedback bad";

        }


        input.addEventListener("keydown", (e) => {

            if (e.key === "Enter") {
                checkAnswer();
            }

        });

        input.addEventListener("blur", checkAnswer);

    });

})();

// ==================================================
//    THE VAULT
//    Self-contained component. State lives entirely
//    on data-vault-view; Door 2 only knows how to
//    open and reset it — see setVaultView() below.
// ==================================================

const doorTwoVault =
    document.querySelector("#door2-vault");

function setVaultView(view, opts = {}) {

    if (!doorTwoVault) {
        return;
    }

    doorTwoVault.dataset.vaultView = view;

    if (opts.scroll !== false) {
        doorTwoVault.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }

}

// Open the vault — from the door's own button, or from
// Discovery Three's "Open the Vault" teaser.

document
    .querySelectorAll("#vault-open-button, [data-vault-open]")
    .forEach((button) => {
        button.addEventListener("click", () => setVaultView("menu"));
    });

// Close the vault — returns to the closed-door state.
// Since the Vault lives inline in Door 2's own flow (not a
// modal), collapsing back to "closed" naturally leaves the
// learner at the same scroll position in Door 2 — no separate
// "return to location" logic needed.

document
    .querySelector("#vault-close-button")
    ?.addEventListener("click", () => setVaultView("closed", { scroll: false }));

// Menu items — open a specific section.

document
    .querySelectorAll(".vault__menu-item")
    .forEach((item) => {
        item.addEventListener("click", () => {
            setVaultView(`section-${item.dataset.vaultSection}`);
        });
    });

// Return to Vault Menu — every section has one of these.

document
    .querySelectorAll("[data-vault-return]")
    .forEach((button) => {
        button.addEventListener("click", () => setVaultView("menu", { scroll: false }));
    });


// --------------------------------------------------
// VAULT SECTION 3 — "DID IT GET SMALLER?" PREDICTION
// --------------------------------------------------

const vaultSection3Reveal =
    document.querySelector("#vault-section-3-reveal");

const vaultSection3Verdict =
    document.querySelector("#vault-section-3-verdict");

document
    .querySelectorAll("#vault-section-3 .vault__predict-button")
    .forEach((button) => {

        button.addEventListener("click", () => {

            if (!vaultSection3Reveal) {
                return;
            }

            const answeredYes = button.dataset.vaultAnswer === "yes";

            if (vaultSection3Verdict) {
                vaultSection3Verdict.textContent = answeredYes
                    ? "Actually — no, it didn't."
                    : "Right — it didn't.";
            }

            vaultSection3Reveal.hidden = false;

            vaultSection3Reveal.scrollIntoView({
                behavior: "smooth",
                block: "nearest"
            });

        });

    });


// --------------------------------------------------
// VAULT RESET — folded into Door 2's own
// "Restore This Door" handler, further down this file.
// Exposed here so that handler can call it without
// needing to know the Vault's internal structure.
// --------------------------------------------------

function resetDoorTwoVault() {

    setVaultView("closed", { scroll: false });

    if (vaultSection3Reveal) {
        vaultSection3Reveal.hidden = true;
    }

    if (peopleExploreMoreEndingsReveal) {
        peopleExploreMoreEndingsReveal.setAttribute("hidden", "");
    }

}

// ==================================================
//    END - THE VAULT
// ==================================================

// ==================================================
//    DOOR 1 — THE LANGUAGE IDENTITY CARD
//    Self-contained component. Unlike the Vault, there
//    is no single "current view" attribute — each of
//    the five category panels tracks its own open/
//    closed state independently (data-category-open on
//    its toggle button + [hidden] on its panel), because
//    the learner decides whether several stay open at
//    once. The Family Tree is always visible and is a
//    live view: renderIdentityTree() reads whatever is
//    currently checked, fresh, every time it runs — it
//    never stores an old answer that would need syncing.
// ==================================================

// --------------------------------------------------
// NAME — transliteration
// A real letter/sound mapping, not a lookup list of
// pre-written names. Longest sequences are matched
// first (e.g. "shch" before "sh" before "s") so digraphs
// win over their single-letter pieces. Anything with no
// mapping (numbers, accents, stray punctuation) is
// carried through unchanged rather than dropped — an odd
// character showing through is more honest than a silent
// failure.
// --------------------------------------------------

const IDENTITY_TRANSLIT_MULTI = [
    ["shch", "щ"],
    ["kh", "х"],
    ["ts", "ц"],
    ["ch", "ч"],
    ["sh", "ш"],
    ["zh", "ж"],
    ["ya", "я"],
    ["yu", "ю"],
    ["yo", "ё"],
    ["ye", "е"],
    ["ph", "ф"],
    ["ck", "к"],
    ["qu", "кв"]
];

const IDENTITY_TRANSLIT_SINGLE = {
    a: "а", b: "б", c: "к", d: "д", e: "е", f: "ф", g: "г", h: "х",
    i: "и", j: "дж", k: "к", l: "л", m: "м", n: "н", o: "о", p: "п",
    q: "к", r: "р", s: "с", t: "т", u: "у", v: "в", w: "в", x: "кс",
    y: "и", z: "з"
};

function transliterateWord(word) {

    let output = "";
    let i = 0;

    while (i < word.length) {

        const ch = word[i];

        if (!/[a-z]/.test(ch)) {
            output += ch;
            i += 1;
            continue;
        }

        const multiMatch = IDENTITY_TRANSLIT_MULTI.find(([latin]) =>
            word.startsWith(latin, i));

        if (multiMatch) {
            output += multiMatch[1];
            i += multiMatch[0].length;
            continue;
        }

        // "c" is soft (с) before e/i/y, hard (к) everywhere else —
        // the one letter that genuinely needs its neighbor to decide.
        if (ch === "c") {
            const next = word[i + 1];
            output += (next === "e" || next === "i" || next === "y") ? "с" : "к";
            i += 1;
            continue;
        }

        output += IDENTITY_TRANSLIT_SINGLE[ch] || ch;
        i += 1;

    }

    return output.charAt(0).toUpperCase() + output.slice(1);

}

function transliterateToRussian(fullName) {

    return (fullName || "")
        .toLowerCase()
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .map(transliterateWord)
        .join(" ");

}

const identityNameInput = document.querySelector("#identity-name-input");
const identityNameOutput = document.querySelector("#identity-name-output");

identityNameInput?.addEventListener("input", () => {

    const value = identityNameInput.value.trim();

    identityNameOutput.textContent = value
        ? transliterateToRussian(value)
        : "Still discovering...";

});

// --------------------------------------------------
// BIRTH MONTH — the sentence and its gender toggle
// Every month just adds -е after "в" (январь → январе),
// so the prepositional form rides along on the option
// itself (data-prep) instead of living in a second table
// that would have to stay in sync with the first.
// --------------------------------------------------

let identityGender = "male"; // "male" -> родился, "female" -> родилась

const identityMonthSelect = document.querySelector("#identity-month-select");
const identityBirthSentence = document.querySelector("#identity-birth-sentence");
const identityMonthPrep = document.querySelector("#identity-month-prep");
const identityGenderWord = document.querySelector("#identity-gender-word");

identityMonthSelect?.addEventListener("change", () => {

    const option = identityMonthSelect.selectedOptions[0];

    if (!identityBirthSentence) {
        return;
    }

    if (!option || !option.value) {
        identityBirthSentence.hidden = true;
        return;
    }

    if (identityMonthPrep) {
        identityMonthPrep.textContent = option.dataset.prep;
    }

    identityBirthSentence.hidden = false;

});

document
    .querySelectorAll(".identity-card__gender-option")
    .forEach((button) => {

        button.addEventListener("click", () => {

            identityGender = button.dataset.gender;

            document
                .querySelectorAll(".identity-card__gender-option")
                .forEach((other) => {
                    other.setAttribute("aria-pressed", other === button ? "true" : "false");
                });

            if (identityGenderWord) {
                identityGenderWord.textContent =
                    identityGender === "female" ? "родилась" : "родился";
            }

        });

    });

// --------------------------------------------------
// FIVE CATEGORY PANELS — pull-down, independent state
// --------------------------------------------------

function closeIdentityCategory(category) {

    const panel = document.querySelector(`#identity-panel-${category}`);
    const toggle = document.querySelector(`[data-category-open="${category}"]`);

    if (panel) {
        panel.hidden = true;
    }

    if (toggle) {
        toggle.setAttribute("aria-expanded", "false");
    }

}

document
    .querySelectorAll(".identity-card__category-toggle")
    .forEach((toggle) => {

        toggle.addEventListener("click", () => {

            const category = toggle.dataset.categoryOpen;
            const panel = document.querySelector(`#identity-panel-${category}`);

            if (!panel) {
                return;
            }

            const opening = panel.hidden;

            panel.hidden = !opening;
            toggle.setAttribute("aria-expanded", String(opening));

            if (opening && category === "special") {
                renderIdentitySpecialPicker();
            }

        });

    });

document
    .querySelectorAll("[data-category-return]")
    .forEach((button) => {
        button.addEventListener("click", () => {
            closeIdentityCategory(button.dataset.categoryReturn);
        });
    });

// "Close" — collapses every open panel at once. The card itself
// has no closed/sealed state the way the Vault's door does; Name,
// Birth Month, and the Tree stay visible always. This button only
// ever affects the five pull-downs.

document
    .querySelector("#identity-close-all")
    ?.addEventListener("click", () => {

        document
            .querySelectorAll(".identity-card__category-panel")
            .forEach((panel) => { panel.hidden = true; });

        document
            .querySelectorAll(".identity-card__category-toggle")
            .forEach((toggle) => { toggle.setAttribute("aria-expanded", "false"); });

    });

// --------------------------------------------------
// PER-CATEGORY RESET — "clear this one, keep the rest."
// Reuses the Vault's "Restore This Door" principle at a
// finer grain: nothing is ever lost by accident, only by
// one clearly-labeled, scoped, deliberate action.
// --------------------------------------------------

document
    .querySelectorAll("[data-category-reset]")
    .forEach((button) => {

        button.addEventListener("click", () => {

            const category = button.dataset.categoryReset;

            document
                .querySelectorAll(`.identity-card__checkbox[data-category="${category}"]`)
                .forEach((checkbox) => { checkbox.checked = false; });

            if (category === "special") {

                identitySpecialChoice = null;

                const whyInput = document.querySelector("#identity-special-why");

                if (whyInput) {
                    whyInput.value = "";
                }

            }

            renderIdentitySpecialPicker();
            renderIdentityTree();

        });

    });

document
    .querySelectorAll(".identity-card__checkbox")
    .forEach((checkbox) => {
        checkbox.addEventListener("change", () => {
            renderIdentitySpecialPicker();
            renderIdentityTree();
        });
    });

// --------------------------------------------------
// SOMEONE SPECIAL — no fixed vocabulary of its own yet
// (an open question in the guiding document). Rather than
// invent new words, it reuses whoever is already checked
// above: pick one of them, and say why.
// --------------------------------------------------

let identitySpecialChoice = null;

function getIdentityCheckedPeople() {

    return Array.from(document.querySelectorAll(".identity-card__checkbox:checked"))
        .map((checkbox) => ({
            word: checkbox.dataset.treeWord,
            label: checkbox.dataset.treeLabel
        }));

}

function renderIdentitySpecialPicker() {

    const picker = document.querySelector("#identity-special-picker");
    const hint = document.querySelector("#identity-special-hint");

    if (!picker) {
        return;
    }

    const people = getIdentityCheckedPeople();

    if (identitySpecialChoice && !people.some((person) => person.word === identitySpecialChoice)) {
        identitySpecialChoice = null;
    }

    picker.innerHTML = "";

    if (people.length === 0) {
        if (hint) {
            hint.hidden = false;
        }
        return;
    }

    if (hint) {
        hint.hidden = true;
    }

    people.forEach((person) => {

        const optionId = `identity-special-${person.word.replace(/\s+/g, "-")}`;

        const wrapper = document.createElement("label");
        wrapper.className = "identity-card__special-option";
        wrapper.setAttribute("for", optionId);

        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "identity-special-choice";
        radio.id = optionId;
        radio.value = person.word;
        radio.checked = identitySpecialChoice === person.word;

        radio.addEventListener("change", () => {
            identitySpecialChoice = person.word;
            renderIdentityTree();
        });

        wrapper.appendChild(radio);
        wrapper.append(` ${person.label} — ${person.word}`);

        picker.appendChild(wrapper);

    });

}

document
    .querySelector("#identity-special-why")
    ?.addEventListener("input", () => renderIdentityTree());

// --------------------------------------------------
// THE FAMILY TREE — a live view, not a stored snapshot.
// Reads whatever is currently checked across the four
// vocabulary categories, fresh, every render. Clearing a
// category elsewhere never requires special sync logic
// here — the Tree was never holding an old answer.
// --------------------------------------------------

function renderIdentityTree() {

    const canvas = document.querySelector("#identity-tree-canvas");
    const emptyMessage = document.querySelector("#identity-tree-empty");

    if (!canvas) {
        return;
    }

    canvas
        .querySelectorAll(".identity-card__tree-leaf")
        .forEach((leaf) => leaf.remove());

    const people = getIdentityCheckedPeople();

    if (people.length === 0) {
        if (emptyMessage) {
            emptyMessage.hidden = false;
        }
        return;
    }

    if (emptyMessage) {
        emptyMessage.hidden = true;
    }

    const whyInput = document.querySelector("#identity-special-why");
    const whyText = whyInput ? whyInput.value.trim() : "";

    people.forEach((person) => {

        const isSpecial = person.word === identitySpecialChoice;

        const leaf = document.createElement("div");
        leaf.className = "identity-card__tree-leaf" +
            (isSpecial ? " identity-card__tree-leaf--special" : "");

        if (isSpecial && whyText) {
            leaf.title = whyText;
        }

        const strong = document.createElement("strong");
        strong.textContent = person.label;

        const span = document.createElement("span");
        span.textContent = person.word;

        leaf.appendChild(strong);
        leaf.appendChild(span);

        canvas.appendChild(leaf);

    });

}

// ==================================================
//    END - DOOR 1 IDENTITY CARD
// ==================================================
// ==================================================
//    BEGIN — DOOR 1 FAMILY IDENTITY CARD
//    Screen 1 of 5: My People (Launch screen)
//
//    Built piece by piece, directly into this file, each
//    piece tested in the real page before the next is added.
//    (See Git history: an earlier attempt built the whole
//    component standalone and merged it in one shot — that's
//    what caused the CSS-bloat bug that broke the page on
//    click. This time each screen is built and proven here
//    first.)
//
//    $ / $$ below are short query-selector helpers scoped to
//    this block only — nothing above this point in the file
//    defines them, so there's no collision with the rest of
//    the page's script.
// ==================================================

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

// Every relationship word the app can ever show in Russian, regardless of which
// screen uses it. ruRel() below always reads from this full list. Keep this one
// complete even when a particular screen's dropdown (like RELS, right below)
// only offers a subset of these choices.
const REL_RU = [
    ["mother", "мама"], ["father", "папа"], ["sister", "сестра"], ["brother", "брат"],
    ["grandmother", "бабушка"], ["grandfather", "дедушка"], ["great-grandmother", "прабабушка"], ["great-grandfather", "прадедушка"], ["aunt", "тётя"], ["uncle", "дядя"],
    ["cousin", "двоюродный брат / двоюродная сестра"], ["wife", "жена"], ["husband", "муж"],
    ["girlfriend", "девушка"], ["boyfriend", "парень"], ["fiancée", "невеста"], ["fiancé", "жених"],
    ["ex-wife", "бывшая жена"], ["ex-husband", "бывший муж"], ["friend", "друг / подруга"]
];

// My People only offers Mother/Father/Brother/Sister. Every other relationship
// (grandparents, great-grandparents, mom's/dad's siblings) is side-specific —
// there's no way to know "mom's side" or "dad's side" from a dropdown alone,
// only from which box the learner clicks on the My Connections tree. So those
// are added there instead, not here. Aunt/Uncle/Cousin/spouse-type relationships
// will come back once "What I Call Them" and "Someone Special" are built.
const RELS = [
    ["mother", "мама"], ["father", "папа"], ["sister", "сестра"], ["brother", "брат"]
];

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const monthLabels = {
    "January": "January — Январь", "February": "February — Февраль", "March": "March — Март",
    "April": "April — Апрель", "May": "May — Май", "June": "June — Июнь", "July": "July — Июль",
    "August": "August — Август", "September": "September — Сентябрь", "October": "October — Октябрь",
    "November": "November — Ноябрь", "December": "December — Декабрь"
};

let state = { owner: { name: "", month: "", birthYear: "", photo: "" }, people: [], callThemExtras: [], callThemChoices: {}, specialId: null, specialExtras: [], specialExpressions: {}, tryPersonId: "", tryExtraPeople: [], trySavedExpressions: {}, pets: [], petId: null, petFeeling: "love" };

// Tracks which person (if any) is loaded into the form for editing.
// null means the form is in "add a new person" mode.
let selectedPersonId = null;

const DB = "familyIdentityCardDB", STORE = "state";

function openDB() {
    return new Promise((res, rej) => {
        let r = indexedDB.open(DB, 1);
        r.onupgradeneeded = () => r.result.createObjectStore(STORE);
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
    });
}

async function saveIdentityCard() {
    const db = await openDB();
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(state, "app");
    return new Promise(r => tx.oncomplete = r);
}

async function loadIdentityCard() {
    try {
        const db = await openDB();
        const tx = db.transaction(STORE, "readonly");
        const req = tx.objectStore(STORE).get("app");
        await new Promise(r => tx.oncomplete = r);
        if (req.result) state = req.result;
    } catch (e) { }
}

async function clearIdentityCard() {
    if (!confirm("Clear all Family Identity Card information and photos stored by this component in this browser?")) return;
    indexedDB.deleteDatabase(DB);
    state = { owner: { name: "", month: "", birthYear: "", photo: "" }, people: [], callThemExtras: [], callThemChoices: {}, specialId: null, specialExtras: [], specialExpressions: {}, tryPersonId: "", tryExtraPeople: [], trySavedExpressions: {}, pets: [], petId: null, petFeeling: "love" };
    selectedPersonId = null;
    renderIdentityCard();
}

function fillSelect(el, arr, placeholder) {
    el.innerHTML = placeholder ? `<option value="">${placeholder}</option>` : "";
    arr.forEach(([v, t]) => el.add(new Option(t, v)));
}

function speakRussianWord(t) {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.cancel();
    let u = new SpeechSynthesisUtterance(t);
    u.lang = "ru-RU";
    speechSynthesis.speak(u);
}

function photoData(file) {
    return new Promise((res, rej) => {
        if (!file) return res("");
        let r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = rej;
        r.readAsDataURL(file);
    });
}

function ruRel(rel) {
    return REL_RU.find(x => x[0] === rel)?.[1] || rel;
}

function person(id) {
    return state.people.find(p => p.id === id);
}

// Screen switcher. Any screen that doesn't exist yet (like Explore
// More) is a harmless no-op until it is built in a later piece.
// My Connections renders fresh from state.people every time the
// learner switches to it, so anything added or changed on My
// People is always up to date there — one shared list of people,
// not two.
function show(id) {
    const target = document.getElementById(id);
    if (!target) return;
    $$("#app .screen").forEach(s => s.classList.toggle("active", s.id === id));
    if (id === "connections") renderConnections();
    if (id === "callthem") renderCallThem();
    if (id === "special") renderSpecial();
    if (id === "explore") renderExplore();
    if (id === "people") renderTryPeople();
    if (id === "pets") renderPets();
    // Scroll the card itself back into view, not the whole page — the
    // card sits partway down Family Relationships, so jumping to the
    // very top of the page (window.scrollTo(0,0)) was landing above
    // Door 1 entirely and forcing a scroll back down every time.
    target.scrollIntoView({ block: "start" });
}

function updateAddRussianPreview() {
    const rel = $("#addRelationship").value;
    const preview = $("#addRussianPreview");
    const word = rel ? ruRel(rel) : "";
    preview.textContent = word || "Выберите отношение";
    $("#addRussianSpeak").dataset.speak = word;
}

function renderPeople() {
    const list = $("#peopleList");
    list.innerHTML = state.people.length ? "" : "<p>No people added yet.</p>";
    state.people.forEach(p => {
        const row = document.createElement("div");
        row.className = "person-row" + (p.id === selectedPersonId ? " person-row--selected" : "");
        // Mother, Father, and siblings can be edited right here. Everyone
        // else (grandparents, great-grandparents, mom's/dad's siblings)
        // was added by clicking their box on My Connections, and stays
        // tied to that box — so no edit pencil for those here.
        const editable = RELS.some(r => r[0] === p.relationship);
        row.innerHTML = `${p.photo ? `<img src="${p.photo}">` : `<div class="avatar">👤</div>`}<div><b>${p.name || "Unnamed"}</b><br>${ruRel(p.relationship)} — ${p.relationship}</div>${editable ? `<button type="button" data-select="${p.id}" title="Edit this person">✎</button>` : `<button type="button" data-remove="${p.id}" title="Remove this person">🗑</button>`}`;
        list.appendChild(row);
    });
    $$("[data-select]").forEach(b => b.onclick = () => selectPerson(b.dataset.select));
    $$("[data-remove]").forEach(b => b.onclick = () => removePersonFromList(b.dataset.remove));
}

// People with no pencil (added from a box on My Connections) can't be
// edited here, but they still need a way to be removed one at a time.
// Their saved sentences on the other screens go with them.
async function removePersonFromList(id) {
    const p = person(id);
    if (!p) return;
    if (!confirm(`Remove ${p.name || "this person"} from My People? They will also be removed from the family tree.`)) return;
    state.people = state.people.filter(x => x.id !== id);
    if (selectedPersonId === id) {
        selectedPersonId = null;
        $("#addPersonBtn").textContent = "＋ Add to My People";
    }
    if (state.specialExpressions) delete state.specialExpressions[id];
    if (state.trySavedExpressions) delete state.trySavedExpressions[id];
    if (state.specialId === id) state.specialId = null;
    if (state.tryPersonId === id) state.tryPersonId = "";
    await saveIdentityCard();
    renderIdentityCard();
}

// The four shared sibling positions on the family tree (one tree,
// not one per screen). Used whether a sibling is added here on My
// People or by clicking an empty sibling box on My Connections,
// so the 4-sibling limit holds no matter which screen was used.
function nextFreeSiblingSlot() {
    const used = new Set(state.people.filter(p => p.slotId && p.slotId.startsWith("sibling-")).map(p => p.slotId));
    return ["sibling-0", "sibling-1", "sibling-2", "sibling-3"].find(id => !used.has(id)) || "";
}

// Click a person's pencil: loads them into the form above and
// switches the submit button into "Save Changes" mode.
function selectPerson(id) {
    const p = person(id);
    if (!p) return;
    selectedPersonId = id;
    $("#addRelationship").value = p.relationship;
    updateAddRussianPreview();
    $("#addName").value = p.name === "Unnamed" ? "" : (p.name || "");
    $("#addPhoto").value = "";
    $("#addPersonBtn").textContent = "✓ Save Changes";
    renderPeople();
}

// Resets the form back to "adding a new person" — used by the
// "+ Add a Person" toolbar button and after a successful add/save.
function clearPersonForm() {
    selectedPersonId = null;
    $("#addRelationship").selectedIndex = 0;
    updateAddRussianPreview();
    $("#addName").value = "";
    $("#addPhoto").value = "";
    $("#addPersonBtn").textContent = "＋ Add to My People";
    renderPeople();
}

function renderIdentityCard() {
    $("#ownerName").value = state.owner.name || "";
    $("#ownerNameRussian").value = state.owner.nameRussian || "";
    $("#ownerMonth").value = state.owner.month || "";
    $("#ownerBirthYear").value = state.owner.birthYear || "";

    const ownerPhoto = $("#ownerPhoto"), ownerFallback = $("#ownerPhotoFallback");
    const hasPhoto = !!state.owner.photo;
    $("#ownerPhotoRemove").hidden = !hasPhoto;
    ownerPhoto.style.display = hasPhoto ? "block" : "none";
    ownerPhoto.src = hasPhoto ? state.owner.photo : "";
    ownerFallback.style.display = hasPhoto ? "none" : "flex";

    renderPeople();
}

function initIdentityCard() {

    fillSelect($("#addRelationship"), RELS, null);
    $("#ownerMonth").innerHTML = "";
    MONTHS.forEach(m => $("#ownerMonth").add(new Option(monthLabels[m] || m, m)));

    $$("#app [data-go]").forEach(btn => btn.addEventListener("click", () => show(btn.dataset.go)));

    $("#printBtn").onclick = () => window.print();
    $("#clearBtn").onclick = clearIdentityCard;

    $("#ownerName").onchange = async e => { state.owner.name = e.target.value; await saveIdentityCard(); };
    $("#ownerNameRussian").onchange = async e => { state.owner.nameRussian = e.target.value; await saveIdentityCard(); };
    $("#ownerMonth").onchange = async e => { state.owner.month = e.target.value; await saveIdentityCard(); };
    $("#ownerBirthYear").onchange = async e => {
        state.owner.birthYear = e.target.value.replace(/\D/g, "").slice(0, 4);
        e.target.value = state.owner.birthYear;
        await saveIdentityCard();
    };

    $("#ownerPhotoInput").onchange = async e => {
        const file = e.target.files[0];
        if (!file) return;
        state.owner.photo = await photoData(file);
        e.target.value = "";
        await saveIdentityCard();
        renderIdentityCard();
    };

    $("#ownerPhotoRemove").onclick = async () => {
        state.owner.photo = "";
        await saveIdentityCard();
        renderIdentityCard();
    };

    $("#addRelationship").onchange = updateAddRussianPreview;
    $("#addRussianSpeak").onclick = () => {
        const rel = $("#addRelationship").value;
        if (rel) speakRussianWord(ruRel(rel));
    };

    $("#workspaceAddMode").onclick = clearPersonForm;

    $("#workspaceEditMode").onclick = () => {
        if (selectedPersonId) return;
        if (!state.people.length) return alert("Add a person first.");
        alert("Click the pencil next to a person in \"People I've Added\" to edit them.");
    };

    $("#workspaceRemoveMode").onclick = async () => {
        if (!selectedPersonId) return alert("Click a person in your list first, then press Remove a Person.");
        const p = person(selectedPersonId);
        if (!p) return;
        if (!confirm(`Remove ${p.name || "this person"}?`)) return;
        state.people = state.people.filter(x => x.id !== selectedPersonId);
        selectedPersonId = null;
        $("#addPersonBtn").textContent = "＋ Add to My People";
        await saveIdentityCard();
        renderIdentityCard();
    };

    $("#addPersonBtn").onclick = async () => {
        const name = $("#addName").value.trim();
        const relationship = $("#addRelationship").value;
        if (!relationship) return alert("Choose a relationship.");

        const file = $("#addPhoto").files[0];
        const photo = file ? await photoData(file) : "";

        const isSibling = relationship === "brother" || relationship === "sister";

        if (selectedPersonId) {
            const p = person(selectedPersonId);
            if (p) {
                if (isSibling && !p.slotId) {
                    const free = nextFreeSiblingSlot();
                    if (!free) return alert("You can add up to four siblings. Remove one on My Connections before adding another.");
                    p.slotId = free;
                } else if (!isSibling) {
                    delete p.slotId;
                }
                p.name = name || "Unnamed";
                p.relationship = relationship;
                if (photo) p.photo = photo;
            }
        } else {
            let slotId = "";
            if (isSibling) {
                slotId = nextFreeSiblingSlot();
                if (!slotId) return alert("You can add up to four siblings. Remove one on My Connections before adding another.");
            }
            state.people.push({
                id: crypto.randomUUID(),
                name: name || "Unnamed",
                relationship,
                photo,
                birthYear: "",
                slotId
            });
        }

        await saveIdentityCard();
        clearPersonForm();
        renderIdentityCard();
    };

    updateAddRussianPreview();
}

// ==================================================
//    Screen 2: My Connections (family tree)
//
//    Reuses state.people — the same list Screen 1 reads and
//    writes. Mother, Father, and siblings are unambiguous, so My
//    People can add them directly (RELS, above) and they appear
//    here automatically. Everyone else (grandparents, great-
//    grandparents, mom's/dad's siblings) can only be added here,
//    by clicking the specific box on the tree — only the box
//    clicked can say which side of the family that person is on.
// ==================================================

// One fixed slot per box on the tree. Each slot holds at most one
// person, matched by person.slotId. Percent positions are left/top
// on the #connections card — a first pass against the new
// my-connections-tab-wide.png art, expect a visual-alignment round
// together the same way Screen 1's launch card got one.
const CONNECTIONS_SLOTS = [
    { id: "mother", fixedRel: "mother", pos: [37.5, 56] },
    { id: "father", fixedRel: "father", pos: [49.5, 56] },

    { id: "sibling-0", tier: "sibling", pos: [28, 77] },
    { id: "sibling-1", tier: "sibling", pos: [58, 77] },
    { id: "sibling-2", tier: "sibling", pos: [20, 77] },
    { id: "sibling-3", tier: "sibling", pos: [66, 77] },

    // Grandparent and great-grandparent boxes are each labeled for a
    // specific gender by position (the same way a real family tree
    // always draws a couple as one of each), and that's what the
    // Relationship dropdown opens pre-selected to — so "You clicked
    // on" already shows the right answer before anything is typed.
    // The dropdown still has both options plus a blank "Choose /
    // change…", in case this particular box should hold the other
    // one, or the pick needs to be reset and redone.
    { id: "grandfather-0", tier: "grandparent", impliedRel: "grandfather", pos: [20.5, 34] },
    { id: "grandmother-0", tier: "grandparent", impliedRel: "grandmother", pos: [30.5, 34] },
    { id: "grandmother-1", tier: "grandparent", impliedRel: "grandmother", pos: [56.5, 34] },
    { id: "grandfather-1", tier: "grandparent", impliedRel: "grandfather", pos: [66.5, 34] },

    { id: "greatgrandfather-0", tier: "greatgrandparent", impliedRel: "great-grandfather", pos: [7.5, 12] },
    { id: "greatgrandmother-0", tier: "greatgrandparent", impliedRel: "great-grandmother", pos: [16.5, 12] },
    { id: "greatgrandfather-1", tier: "greatgrandparent", impliedRel: "great-grandfather", pos: [28.5, 12] },
    { id: "greatgrandmother-1", tier: "greatgrandparent", impliedRel: "great-grandmother", pos: [37.5, 12] },
    { id: "greatgrandfather-2", tier: "greatgrandparent", impliedRel: "great-grandfather", pos: [55.5, 12] },
    { id: "greatgrandmother-2", tier: "greatgrandparent", impliedRel: "great-grandmother", pos: [64.5, 12] },
    { id: "greatgrandfather-3", tier: "greatgrandparent", impliedRel: "great-grandfather", pos: [76.5, 12] },
    { id: "greatgrandmother-3", tier: "greatgrandparent", impliedRel: "great-grandmother", pos: [85.5, 12] },

    { id: "parentsibling-maternal-0", tier: "parentsibling", branch: "maternal", pos: [29.5, 56] },
    { id: "parentsibling-maternal-1", tier: "parentsibling", branch: "maternal", pos: [21.5, 56] },
    { id: "parentsibling-maternal-2", tier: "parentsibling", branch: "maternal", pos: [13.5, 56] },
    { id: "parentsibling-maternal-3", tier: "parentsibling", branch: "maternal", pos: [5.5, 56] },
    { id: "parentsibling-paternal-0", tier: "parentsibling", branch: "paternal", pos: [57.5, 56] },
    { id: "parentsibling-paternal-1", tier: "parentsibling", branch: "paternal", pos: [65.5, 56] },
    { id: "parentsibling-paternal-2", tier: "parentsibling", branch: "paternal", pos: [73.5, 56] },
    { id: "parentsibling-paternal-3", tier: "parentsibling", branch: "paternal", pos: [81.5, 56] }
];

// English label for each relationship word — used for a box's idle
// clue and for its Relationship dropdown options.
const REL_LABEL = {
    mother: "Mother", father: "Father",
    grandfather: "Grandfather", grandmother: "Grandmother",
    "great-grandfather": "Great-Grandfather", "great-grandmother": "Great-Grandmother",
    brother: "Brother", sister: "Sister"
};

// What the Relationship dropdown offers for each tier that has one.
// Every tier here always includes a blank "Choose / change…" first
// (see populateTierDropdown) — even grandparent/great-grandparent,
// as a reset in case the wrong one got picked. Mother/Father
// (slot.fixedRel) are the only boxes with no dropdown at all — there
// is only one mother, one father, nothing to choose between.
const TIER_CHOICES = {
    sibling: ["brother", "sister"],
    parentsibling: ["brother", "sister"],
    grandparent: ["grandfather", "grandmother"],
    greatgrandparent: ["great-grandfather", "great-grandmother"]
};

let activeConnectionsSlotId = null;

function connectionsSlot(id) {
    return CONNECTIONS_SLOTS.find(s => s.id === id);
}

// The person occupying a given slot, or null if that box is empty.
function personInSlot(slotId) {
    // Mother and Father are singletons — there's only one of each, so
    // they're found by relationship, not slotId. That way it doesn't
    // matter whether Mother was added here or over on My People; both
    // land in the same box. Every other slot (grandparents, great-
    // grandparents, siblings) can have more than one, so those stay
    // slotId-based.
    if (slotId === "mother" || slotId === "father") {
        return state.people.find(p => p.relationship === slotId) || null;
    }
    return state.people.find(p => p.slotId === slotId) || null;
}

function slotEmptyClue(slot) {
    if (slot.fixedRel) return REL_LABEL[slot.fixedRel] || slot.fixedRel;
    if (slot.impliedRel) return REL_LABEL[slot.impliedRel] || slot.impliedRel;
    if (slot.tier === "parentsibling") {
        return slot.branch === "maternal" ? "Mom's Brother or Sister" : "Dad's Brother or Sister";
    }
    return "Brother or Sister";
}

function familyGenderClass(rel) {
    if (["mother", "grandmother", "great-grandmother", "sister", "aunt"].includes(rel)) return "female";
    if (["father", "grandfather", "great-grandfather", "brother", "uncle"].includes(rel)) return "male";
    return "";
}

// A parent-sibling box stores the real relationship ("aunt"/"uncle"),
// but its dropdown only ever offers Brother/Sister — brother maps to
// uncle, sister maps to aunt, when the box is saved.
function parentSiblingChoiceFor(rel) {
    if (rel === "uncle") return "brother";
    if (rel === "aunt") return "sister";
    return "";
}

// The "You clicked on" sentence for whichever box is open.
// Mother/Father have no dropdown, so this is always the one fixed
// sentence. Grandparent/great-grandparent dropdowns open pre-
// selected to match the box's own label, so this already shows the
// full sentence the instant the box is clicked — before any name,
// photo, or birth year is typed — but follows along if that pick
// gets changed (or reset to blank). Sibling-type boxes (yours,
// mom's, dad's) always show the same fixed, generic line no matter
// which of the four slots it is or whether Brother or Sister gets
// chosen — the box itself and the saved card already show
// брат/сестра once it's filled in.
function connectionContextText(slot, choice) {
    if (slot.fixedRel) return `This is your ${slot.fixedRel} — ${ruRel(slot.fixedRel)}`;
    if (slot.tier === "sibling") return "Your sibling";
    if (slot.tier === "parentsibling") return slot.branch === "maternal" ? "Your mom's sibling" : "Your dad's sibling";
    if (!choice) return slotEmptyClue(slot);
    return `This is your ${choice} — ${ruRel(choice)}`;
}

function populateTierDropdown(tier, selectedChoice) {
    const select = $("#editorRelationshipChoice");
    if (!select) return;
    const choices = TIER_CHOICES[tier] || [];
    select.innerHTML = '<option value="">Choose / change…</option>';
    choices.forEach(value => select.add(new Option(`${REL_LABEL[value] || value} — ${ruRel(value)}`, value)));
    select.value = selectedChoice || "";
}

function currentEditorChoice() {
    const slot = connectionsSlot(activeConnectionsSlotId);
    if (!slot) return "";
    if (slot.fixedRel) return slot.fixedRel;
    return $("#editorRelationshipChoice")?.value || "";
}

function updateConnectionContext() {
    const box = $("#connectionContextStatement");
    if (!box) return;
    const slot = connectionsSlot(activeConnectionsSlotId);
    if (!slot) { box.textContent = ""; return; }
    box.textContent = connectionContextText(slot, currentEditorChoice());
}

function addFamilyPath(svg, d, cls) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", d);
    if (cls) path.setAttribute("class", cls);
    svg.appendChild(path);
}

// Draws the tree's connector lines. The four great-grandparent
// couple lines are permanent fixtures of the tree (drawn whether
// or not anyone has filled those boxes yet); the rest only appear
// once at least one box in that generation is populated.
function renderFamilyLines() {
    const svg = $("#familyLines");
    if (!svg) return;
    svg.innerHTML = "";

    const siblingSlots = CONNECTIONS_SLOTS.filter(s => s.tier === "sibling" && personInSlot(s.id));
    const hasParent = personInSlot("mother") || personInSlot("father");

    if (hasParent || siblingSlots.length) {
        addFamilyPath(svg, "M 375 390 L 495 390", "parent-couple");
        addFamilyPath(svg, "M 435 390 L 435 468");
        addFamilyPath(svg, "M 435 468 L 435 520");
        if (siblingSlots.length) {
            const xs = siblingSlots.map(s => s.pos[0] * 10);
            const minX = Math.min(435, ...xs), maxX = Math.max(435, ...xs);
            addFamilyPath(svg, `M ${minX} 468 L ${maxX} 468`);
            siblingSlots.forEach(s => { const x = s.pos[0] * 10; addFamilyPath(svg, `M ${x} 468 L ${x} 500`); });
        }
    }

    if (CONNECTIONS_SLOTS.some(s => s.tier === "grandparent" && personInSlot(s.id))) {
        addFamilyPath(svg, "M 205 245 L 305 245");
        addFamilyPath(svg, "M 255 245 L 255 315 L 375 315 L 375 370");
        addFamilyPath(svg, "M 565 245 L 665 245");
        addFamilyPath(svg, "M 615 245 L 615 315 L 495 315 L 495 370");
    }

    [
        { left: 75, right: 165, child: 205 },
        { left: 285, right: 375, child: 305 },
        { left: 555, right: 645, child: 565 },
        { left: 765, right: 855, child: 665 }
    ].forEach(pair => {
        const mid = (pair.left + pair.right) / 2;
        addFamilyPath(svg, `M ${pair.left} 105 L ${pair.right} 105`);
        addFamilyPath(svg, `M ${mid} 105 L ${pair.child} 225`);
    });

    const maternal = CONNECTIONS_SLOTS.filter(s => s.tier === "parentsibling" && s.branch === "maternal" && personInSlot(s.id));
    const paternal = CONNECTIONS_SLOTS.filter(s => s.tier === "parentsibling" && s.branch === "paternal" && personInSlot(s.id));
    if (maternal.length) {
        const xs = maternal.map(s => s.pos[0] * 10);
        const minX = Math.min(375, ...xs);
        addFamilyPath(svg, `M ${minX} 315 L 375 315`);
        maternal.forEach(s => { const x = s.pos[0] * 10; addFamilyPath(svg, `M ${x} 315 L ${x} 370`); });
    }
    if (paternal.length) {
        const xs = paternal.map(s => s.pos[0] * 10);
        const maxX = Math.max(495, ...xs);
        addFamilyPath(svg, `M 495 315 L ${maxX} 315`);
        paternal.forEach(s => { const x = s.pos[0] * 10; addFamilyPath(svg, `M ${x} 315 L ${x} 370`); });
    }
}

function renderConnections() {
    const area = $("#treeNodes");
    if (!area) return;
    area.innerHTML = "";

    CONNECTIONS_SLOTS.forEach(slot => {
        const p = personInSlot(slot.id);
        const isSiblingCard = slot.tier === "sibling" || slot.tier === "parentsibling";
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "family-slot " + (p ? "populated " + familyGenderClass(p.relationship) : "empty") + (p && isSiblingCard ? " sibling-family-card" : "");
        btn.style.left = slot.pos[0] + "%";
        btn.style.top = slot.pos[1] + "%";
        btn.innerHTML = p
            ? `${p.photo ? `<img src="${p.photo}" alt="">` : `<span class="slot-avatar">👤</span>`}<span class="slot-name">${p.name || "Unnamed"}</span><span class="slot-russian">${ruRel(p.relationship)}</span>${p.birthYear ? `<span class="slot-year">${p.birthYear}</span>` : ""}`
            : `<span class="slot-clue">${slotEmptyClue(slot)}</span><span class="slot-add">Click to add</span>`;
        btn.onclick = () => openFamilyEditor(slot.id);
        area.appendChild(btn);
    });

    renderFamilyLines();

    const meName = $("#connectionsOwnerName");
    if (meName) meName.textContent = state.owner.name || "ME";

    const ownerPhoto = $("#connectionsOwnerPhoto"), ownerFallback = $("#connectionsOwnerPhotoFallback");
    if (ownerPhoto && ownerFallback) {
        const hasPhoto = !!state.owner.photo;
        ownerPhoto.style.display = hasPhoto ? "block" : "none";
        ownerPhoto.src = hasPhoto ? state.owner.photo : "";
        ownerFallback.style.display = hasPhoto ? "none" : "flex";
    }
}

// Opens the editing menu without a specific tree box chosen yet.
// Relationship stays hidden (there's nothing to choose a relationship
// FOR until a box is clicked) — this just gets the panel open and
// explains what to do next. Collapse this menu closes it again.
function openConnectionsMenu() {
    const launcher = $("#connectionsMenuLauncher"), tools = $(".connection-tools");
    if (launcher) launcher.hidden = true;
    if (tools) { tools.hidden = false; tools.removeAttribute("hidden"); }
    resetConnectionsEditorFields();
}

function openFamilyEditor(slotId) {
    const slot = connectionsSlot(slotId);
    if (!slot) return;

    const launcher = $("#connectionsMenuLauncher"), tools = $(".connection-tools");
    if (launcher) launcher.hidden = true;
    if (tools) { tools.hidden = false; tools.removeAttribute("hidden"); }

    activeConnectionsSlotId = slotId;
    const p = personInSlot(slotId);
    const relChoiceWrap = $("#editorRelationshipChoiceWrap");

    if (slot.fixedRel) {
        if (relChoiceWrap) relChoiceWrap.hidden = true;
    } else {
        if (relChoiceWrap) relChoiceWrap.hidden = false;
        // A saved person's actual choice always wins (they may have
        // overridden this box to the other option); an empty box
        // defaults to the box's own implied gender, if it has one —
        // grandparent/great-grandparent boxes pre-select that way,
        // sibling-type boxes have no implied gender and start blank.
        let selectedChoice;
        if (slot.tier === "parentsibling") selectedChoice = parentSiblingChoiceFor(p?.relationship);
        else selectedChoice = p?.relationship || slot.impliedRel || "";
        populateTierDropdown(slot.tier, selectedChoice);
    }

    $("#editorName").value = p?.name || "";
    $("#editorBirthYear").value = p?.birthYear || "";
    $("#editorPhoto").value = "";
    $("#removeFamilyMember").hidden = !p;

    updateConnectionContext();
}

// Clears whichever box was being edited back to the neutral "click a
// box" state, WITHOUT closing the menu — the menu stays open across
// as many boxes as you want to fill in, and only the Collapse button
// (below) actually closes it. Used after Save, after Remove, and by
// the Cancel button.
function resetConnectionsEditorFields() {
    activeConnectionsSlotId = null;
    const relChoiceWrap = $("#editorRelationshipChoiceWrap");
    if (relChoiceWrap) relChoiceWrap.hidden = true;
    $("#editorName").value = "";
    $("#editorBirthYear").value = "";
    $("#editorPhoto").value = "";
    $("#removeFamilyMember").hidden = true;
    const box = $("#connectionContextStatement");
    if (box) box.textContent = "Click a box on the tree to choose who you're adding.";
}

// The only thing that actually closes the editing menu.
function collapseConnectionsMenu() {
    resetConnectionsEditorFields();
    const launcher = $("#connectionsMenuLauncher"), tools = $(".connection-tools");
    if (tools) tools.hidden = true;
    if (launcher) launcher.hidden = false;
}

function initConnections() {
    $("#connectionsHomeBtn").onclick = () => show("launch");
    $("#connectionsPrintBtn").onclick = () => window.print();
    $("#connectionsClearBtn").onclick = clearIdentityCard;
    $("#connectionsMenuLauncher").onclick = openConnectionsMenu;
    $("#collapseConnectionsMenu").onclick = collapseConnectionsMenu;
    $("#cancelFamilyEdit").onclick = resetConnectionsEditorFields;
    $("#editorRelationshipChoice").onchange = updateConnectionContext;

    $("#saveFamilyMember").onclick = async () => {
        const slot = connectionsSlot(activeConnectionsSlotId);
        if (!slot) return;

        let relationship;
        if (slot.fixedRel) {
            relationship = slot.fixedRel;
        } else {
            const choice = $("#editorRelationshipChoice").value;
            if (!choice) return alert("Choose a relationship.");
            relationship = slot.tier === "parentsibling" ? (choice === "brother" ? "uncle" : "aunt") : choice;
        }

        const name = $("#editorName").value.trim();
        const birthYear = $("#editorBirthYear").value.replace(/\D/g, "").slice(0, 4);
        const file = $("#editorPhoto").files[0];

        let p = personInSlot(slot.id);
        if (!p) {
            p = { id: crypto.randomUUID(), slotId: slot.id, name: "", relationship: "", photo: "", birthYear: "" };
            state.people.push(p);
        }
        p.relationship = relationship;
        p.name = name || p.name || "Unnamed";
        p.birthYear = birthYear;
        if (file) p.photo = await photoData(file);

        await saveIdentityCard();
        resetConnectionsEditorFields();
        renderIdentityCard();
        renderConnections();
    };

    $("#removeFamilyMember").onclick = async () => {
        const p = personInSlot(activeConnectionsSlotId);
        if (!p) return;
        if (!confirm(`Remove ${p.name || "this person"} from My People?`)) return;
        state.people = state.people.filter(x => x.id !== p.id);
        await saveIdentityCard();
        resetConnectionsEditorFields();
        renderIdentityCard();
        renderConnections();
    };
}

// ==================================================
//    Screen 3: What I Call Them
//
//    Reuses state.people from My People / My Connections — nobody
//    is entered a third time. A second, small roster lives only on
//    THIS screen: relationships with no box on the family tree
//    (girlfriend, boyfriend, fiancé(e), wife, husband, ex-wife,
//    ex-husband). They're added here with "+ Add Someone Else" and
//    stored in state.callThemExtras — never in state.people, never
//    on the tree. Aunt/Uncle already have a tree box via My
//    Connections, so they're deliberately left off this screen's
//    add list to avoid a second, untracked aunt or uncle.
//
//    Each person — real or local-only — can have exactly one saved
//    "what I call them" term at a time, in state.callThemChoices
//    (personId -> {ru, note}). Picking a new term for someone who
//    already has one simply replaces it.
// ==================================================

const CALL_TERM_DATA = {
    mother: [{ ru: "мама", note: "Feels like: Mom / Mum — normal, warm everyday term" }, { ru: "мамочка", note: "Feels like: Mommy / dear Mom — very affectionate and tender" }, { ru: "мамуля", note: "Feels like: Mama / Momma — especially warm and affectionate" }, { ru: "мам", note: "Feels like: Mom! / Mum! — casual spoken address" }],
    father: [{ ru: "папа", note: "Feels like: Dad / Papa — normal, warm everyday term" }, { ru: "папочка", note: "Feels like: Daddy / dear Dad — very affectionate and tender" }, { ru: "папуля", note: "Feels like: Papa / Dad — especially warm and affectionate" }, { ru: "пап", note: "Feels like: Dad! — casual spoken address" }],
    grandmother: [{ ru: "бабушка", note: "Feels like: Grandma — normal, warm everyday term" }, { ru: "бабуля", note: "Feels like: Nana / Grandma — warm and affectionate" }, { ru: "бабуся", note: "Feels like: Nana / dear Grandma — especially tender" }, { ru: "бабуня", note: "Feels like: Granny / Nana — affectionate and homey" }],
    grandfather: [{ ru: "дедушка", note: "Feels like: Grandpa — normal, warm everyday term" }, { ru: "дедуля", note: "Feels like: Grandpa / Papa — especially warm and affectionate" }, { ru: "дедуся", note: "Feels like: Granddad / dear Grandpa — tender and affectionate" }, { ru: "дед", note: "Feels like: Granddad / Gramps — short and familiar" }],
    "great-grandmother": [{ ru: "прабабушка", note: "Feels like: Great-Grandma — identifies the actual relationship" }, { ru: "бабушка", note: "Feels like: Grandma — if that is what your family actually calls her" }, { ru: "бабуля", note: "Feels like: Nana / Grandma — warm and affectionate" }, { ru: "бабуся", note: "Feels like: Nana / dear Grandma — especially tender" }],
    "great-grandfather": [{ ru: "прадедушка", note: "Feels like: Great-Grandpa — identifies the actual relationship" }, { ru: "прадед", note: "Feels like: Great-Granddad — shorter and more neutral" }, { ru: "дедушка", note: "Feels like: Grandpa — if that is what your family actually calls him" }, { ru: "дедуля", note: "Feels like: Grandpa / Papa — warm and affectionate" }],
    sister: [{ ru: "сестра", note: "sister — the normal, everyday word" }, { ru: "сестрёнка", note: "little sis / sis — warm and affectionate" }, { ru: "сестричка", note: "dear sister / sis — affectionate and tender" }, { ru: "сеструха", note: "sis — very informal and slangy" }],
    brother: [{ ru: "брат", note: "brother — the normal, everyday word" }, { ru: "братишка", note: "little bro / dear brother — warm and affectionate" }, { ru: "братец", note: "brother / bro — familiar and affectionate" }, { ru: "братан", note: "bro / dude — very informal and slangy" }],
    aunt: [{ ru: "тётя", note: "Feels like: Aunt / Auntie — normal, warm everyday term" }, { ru: "тётушка", note: "Feels like: dear Aunt / Auntie — affectionate and somewhat traditional" }],
    uncle: [{ ru: "дядя", note: "Feels like: Uncle — normal, warm everyday term" }, { ru: "дядюшка", note: "Feels like: dear Uncle — affectionate and somewhat traditional" }],
    wife: [{ ru: "жена", note: "Wife" }], husband: [{ ru: "муж", note: "Husband" }],
    girlfriend: [{ ru: "девушка", note: "Girlfriend" }], boyfriend: [{ ru: "парень", note: "Boyfriend" }],
    "fiancée": [{ ru: "невеста", note: "Fiancée" }], "fiancé": [{ ru: "жених", note: "Fiancé" }],
    "ex-wife": [{ ru: "бывшая жена", note: "Ex-wife" }], "ex-husband": [{ ru: "бывший муж", note: "Ex-husband" }]
};

// The only relationships this screen's own "+ Add Someone Else"
// panel offers — every one has no box on the family tree, so
// there's nowhere else for them to be added.
const CALLTHEM_EXTRA_RELS = [
    ["girlfriend", "Girlfriend"], ["boyfriend", "Boyfriend"],
    ["fiancée", "Fiancée"], ["fiancé", "Fiancé"],
    ["wife", "Wife"], ["husband", "Husband"],
    ["ex-wife", "Ex-Wife"], ["ex-husband", "Ex-Husband"]
];

let activeCallThemPersonId = null;
let activeCallThemChoice = null;
// Which saved entry in Your Personal List is currently selected —
// separate from activeCallThemPersonId above (that's who Steps 1-3
// are working on; this is which saved row is picked for removal).
let selectedPersonalEntryId = null;

// state.people (My People / My Connections) plus state.callThemExtras
// (this screen's own local-only roster) — one combined list of
// everyone this screen can offer in its dropdown.
function callThemAllPeople() {
    return [...state.people, ...(state.callThemExtras || [])];
}

function callThemPerson(id) {
    return callThemAllPeople().find(p => p.id === id) || null;
}

function renderCallThemPeopleSelect() {
    const select = $("#callPerson");
    select.innerHTML = '<option value="">Choose a family member…</option>';
    callThemAllPeople().forEach(p => select.add(new Option(`${p.name || "Unnamed"} — ${ruRel(p.relationship)}`, p.id)));
    select.value = activeCallThemPersonId || "";
}

function renderCallThemPersonCard() {
    const box = $("#callSelectedPerson");
    const p = callThemPerson(activeCallThemPersonId);
    if (!p) { box.hidden = true; return; }
    box.hidden = false;
    const img = $("#callPersonPhoto"), fallback = $("#callPersonPhotoFallback");
    img.style.display = p.photo ? "block" : "none";
    img.src = p.photo || "";
    fallback.style.display = p.photo ? "none" : "flex";
    $("#callPersonName").textContent = p.name || "Unnamed";
    $("#callPersonRel").textContent = `Your ${p.relationship} — ${ruRel(p.relationship)}`;
}

function updateCallThemConfirmBtn() {
    const btn = $("#callConfirmBtn");
    const p = callThemPerson(activeCallThemPersonId);
    if (p && activeCallThemChoice) {
        btn.disabled = false;
        btn.textContent = `I'll call ${p.name || "them"} ${activeCallThemChoice.ru}`;
    } else {
        btn.disabled = true;
        btn.textContent = "Choose a Russian option";
    }
}

function selectCallThemTerm(term, btnEl) {
    activeCallThemChoice = term;
    $$("#callOptionsRow button").forEach(b => b.classList.toggle("selected", b === btnEl));
    updateCallThemConfirmBtn();
}

function renderCallThemOptions() {
    const wrap = $("#callOptionsRow");
    wrap.innerHTML = "";
    activeCallThemChoice = null;
    const p = callThemPerson(activeCallThemPersonId);
    if (!p) { updateCallThemConfirmBtn(); return; }

    const terms = CALL_TERM_DATA[p.relationship] || [];
    const saved = state.callThemChoices[p.id];

    terms.forEach(term => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.innerHTML = `<span class="call-ru">${term.ru}</span><span class="call-note">${term.note}</span><span class="call-speaker" role="button" tabindex="0" title="Listen">🔊</span>`;
        btn.onclick = () => selectCallThemTerm(term, btn);
        const speaker = btn.querySelector(".call-speaker");
        speaker.onclick = e => { e.stopPropagation(); speakRussianWord(term.ru); };
        speaker.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); speakRussianWord(term.ru); } };
        if (saved && saved.ru === term.ru) {
            btn.classList.add("selected");
            activeCallThemChoice = term;
        }
        wrap.appendChild(btn);
    });

    updateCallThemConfirmBtn();
}

function renderCallThemPersonalList() {
    const list = $("#personalListEntries"), empty = $("#personalListEmpty");
    const entries = Object.entries(state.callThemChoices || {})
        .map(([id, term]) => ({ id, term, person: callThemPerson(id) }))
        .filter(e => e.person);

    if (!entries.some(e => e.id === selectedPersonalEntryId)) selectedPersonalEntryId = null;

    empty.hidden = entries.length > 0;
    list.innerHTML = "";

    entries.forEach(({ id, term, person }) => {
        const row = document.createElement("div");
        row.className = "personal-call-entry" + (id === selectedPersonalEntryId ? " selected" : "");
        row.tabIndex = 0;
        row.setAttribute("role", "button");
        row.innerHTML = `${person.photo ? `<img src="${person.photo}" alt="">` : `<span class="mini-fallback">👤</span>`}<div><strong>${person.name || "Unnamed"}</strong><small>${term.ru} — ${ruRel(person.relationship)}</small></div><button type="button" class="list-speaker" title="Listen">🔊</button>`;
        row.querySelector(".list-speaker").onclick = e => { e.stopPropagation(); speakRussianWord(term.ru); };
        const select = () => { selectedPersonalEntryId = id; renderCallThemPersonalList(); };
        row.onclick = select;
        row.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select(); } };
        list.appendChild(row);
    });

    $("#personalRemoveBtn").disabled = !selectedPersonalEntryId;
}

function renderCallThem() {
    if (!state.callThemExtras) state.callThemExtras = [];
    if (!state.callThemChoices) state.callThemChoices = {};
    renderCallThemPeopleSelect();
    renderCallThemPersonCard();
    renderCallThemOptions();
    renderCallThemPersonalList();
}

function initCallThem() {
    $("#callThemHomeBtn").onclick = () => show("launch");
    $("#callThemPrintBtn").onclick = () => window.print();
    $("#callThemClearBtn").onclick = clearIdentityCard;

    fillSelect($("#callThemAddRelationship"), CALLTHEM_EXTRA_RELS, "Choose a relationship…");

    $("#callPerson").onchange = e => {
        activeCallThemPersonId = e.target.value || null;
        renderCallThemPersonCard();
        renderCallThemOptions();
    };

    $("#callThemAddToggle").onclick = () => {
        $("#callThemAddPanel").hidden = false;
        $("#callThemAddName").value = "";
        $("#callThemAddRelationship").value = "";
    };
    $("#callThemAddCancel").onclick = () => { $("#callThemAddPanel").hidden = true; };

    $("#callThemAddSave").onclick = async () => {
        const relationship = $("#callThemAddRelationship").value;
        if (!relationship) return alert("Choose a relationship.");
        const name = $("#callThemAddName").value.trim();
        const p = { id: crypto.randomUUID(), name: name || "Unnamed", relationship, photo: "" };
        state.callThemExtras.push(p);
        await saveIdentityCard();
        $("#callThemAddPanel").hidden = true;
        activeCallThemPersonId = p.id;
        renderCallThemPeopleSelect();
        renderCallThemPersonCard();
        renderCallThemOptions();
    };

    // Clears the in-progress (unsaved) pick — not a saved choice, just
    // whatever is currently highlighted in Step 2 before Confirm is
    // pressed. Lets the learner back out of a pick without saving it.
    $("#callClearChoice").onclick = () => {
        activeCallThemChoice = null;
        $$("#callOptionsRow button").forEach(b => b.classList.remove("selected"));
        updateCallThemConfirmBtn();
    };

    $("#callConfirmBtn").onclick = async () => {
        const p = callThemPerson(activeCallThemPersonId);
        if (!p || !activeCallThemChoice) return;
        state.callThemChoices[p.id] = { ru: activeCallThemChoice.ru, note: activeCallThemChoice.note };
        await saveIdentityCard();
        renderCallThemPersonalList();
    };

    $("#personalRemoveBtn").onclick = async () => {
        if (!selectedPersonalEntryId) return;
        const removedId = selectedPersonalEntryId;
        delete state.callThemChoices[removedId];
        selectedPersonalEntryId = null;
        await saveIdentityCard();
        renderCallThemPersonalList();
        if (activeCallThemPersonId === removedId) renderCallThemOptions();
    };
}

// ==================================================
//    SCREEN 4 — SOMEONE SPECIAL
//
//  The learner picks one person, then picks one or two
//  feelings (from eight). The Russian they receive comes
//  from the curated bank below — the learner controls what
//  it MEANS, the bank controls the QUALITY of the Russian.
//  Nothing here ever glues together random Russian words.
//
//  Reuses state.people (nobody is entered again). People
//  added with "+ Add Someone Special" live only in
//  state.specialExtras — never on My People or the tree.
//  Saved sentences live in state.specialExpressions,
//  keyed by person id (up to four each).
// ==================================================

/* =========================================================
   SOMEONE SPECIAL — CURATED EXPRESSION BANK
   The learner chooses meaning. This bank supplies validated Russian.
   ========================================================= */
const SPECIAL_SENTIMENTS = [
    { key: "kind", label: "Kind / Caring" },
    { key: "funny", label: "Funny / Makes Me Laugh" },
    { key: "smart", label: "Smart" },
    { key: "beautiful", label: "Beautiful / Handsome" },
    { key: "happy", label: "Makes Me Happy" },
    { key: "important", label: "Important to Me" },
    { key: "admire", label: "I Admire Them" },
    { key: "love", label: "I Love Them" }
];
const SPECIAL_BANK = {
    kind: {
        female: [
            { ru: "Она добрая и заботливая.", en: "She is kind and caring.", hi: "добрая и заботливая" },
            { ru: "Она очень отзывчивая.", en: "She is very caring and helpful.", hi: "очень отзывчивая" },
            { ru: "Она всегда готова помочь.", en: "She is always ready to help.", hi: "всегда готова помочь" },
            { ru: "У неё золотое сердце.", en: "She has a heart of gold.", hi: "золотое сердце" }
        ],
        male: [
            { ru: "Он добрый и заботливый.", en: "He is kind and caring.", hi: "добрый и заботливый" },
            { ru: "Он очень отзывчивый.", en: "He is very caring and helpful.", hi: "очень отзывчивый" },
            { ru: "Он всегда готов помочь.", en: "He is always ready to help.", hi: "всегда готов помочь" },
            { ru: "У него золотое сердце.", en: "He has a heart of gold.", hi: "золотое сердце" }
        ]
    },
    funny: {
        female: [
            { ru: "Она весёлая.", en: "She is cheerful and fun.", hi: "весёлая" },
            { ru: "Она умеет меня рассмешить.", en: "She knows how to make me laugh.", hi: "умеет меня рассмешить" },
            { ru: "С ней всегда весело.", en: "It's always fun with her.", hi: "всегда весело" },
            { ru: "У неё отличное чувство юмора.", en: "She has a great sense of humor.", hi: "отличное чувство юмора" }
        ],
        male: [
            { ru: "Он весёлый.", en: "He is cheerful and fun.", hi: "весёлый" },
            { ru: "Он умеет меня рассмешить.", en: "He knows how to make me laugh.", hi: "умеет меня рассмешить" },
            { ru: "С ним всегда весело.", en: "It's always fun with him.", hi: "всегда весело" },
            { ru: "У него отличное чувство юмора.", en: "He has a great sense of humor.", hi: "отличное чувство юмора" }
        ]
    },
    smart: {
        female: [
            { ru: "Она умная.", en: "She is smart.", hi: "умная" },
            { ru: "Она очень мудрая.", en: "She is very wise.", hi: "очень мудрая" },
            { ru: "Она невероятно умна.", en: "She is incredibly smart.", hi: "невероятно умна" },
            { ru: "У неё острый ум.", en: "She has a sharp mind.", hi: "острый ум" }
        ],
        male: [
            { ru: "Он умный.", en: "He is smart.", hi: "умный" },
            { ru: "Он очень мудрый.", en: "He is very wise.", hi: "очень мудрый" },
            { ru: "Он невероятно умён.", en: "He is incredibly smart.", hi: "невероятно умён" },
            { ru: "У него острый ум.", en: "He has a sharp mind.", hi: "острый ум" }
        ]
    },
    beautiful: {
        female: [
            { ru: "Она красивая.", en: "She is beautiful.", hi: "красивая" },
            { ru: "Она очень красивая.", en: "She is very beautiful.", hi: "очень красивая" },
            { ru: "Она выглядит великолепно.", en: "She looks gorgeous.", hi: "выглядит великолепно" },
            { ru: "Она невероятно красива.", en: "She is incredibly beautiful.", hi: "невероятно красива" }
        ],
        male: [
            { ru: "Он красивый.", en: "He is handsome.", hi: "красивый" },
            { ru: "Он очень симпатичный.", en: "He is very good-looking.", hi: "очень симпатичный" },
            { ru: "Он выглядит отлично.", en: "He looks great.", hi: "выглядит отлично" },
            { ru: "Он очень привлекательный.", en: "He is very attractive.", hi: "очень привлекательный" }
        ]
    },
    happy: {
        female: [
            { ru: "Она приносит мне радость.", en: "She brings me joy.", hi: "приносит мне радость" },
            { ru: "Она дарит мне счастье.", en: "She brings me happiness.", hi: "дарит мне счастье" },
            { ru: "Она всегда заставляет меня улыбаться.", en: "She always makes me smile.", hi: "заставляет меня улыбаться" },
            { ru: "Рядом с ней мне хорошо.", en: "I feel good and happy when I'm with her.", hi: "мне хорошо" }
        ],
        male: [
            { ru: "Он приносит мне радость.", en: "He brings me joy.", hi: "приносит мне радость" },
            { ru: "Он дарит мне счастье.", en: "He brings me happiness.", hi: "дарит мне счастье" },
            { ru: "Он всегда заставляет меня улыбаться.", en: "He always makes me smile.", hi: "заставляет меня улыбаться" },
            { ru: "Рядом с ним мне хорошо.", en: "I feel good and happy when I'm with him.", hi: "мне хорошо" }
        ]
    },
    important: {
        female: [
            { ru: "Она важна для меня.", en: "She is important to me.", hi: "важна для меня" },
            { ru: "Она очень много значит для меня.", en: "She means a lot to me.", hi: "очень много значит для меня" },
            { ru: "Она — важная часть моей жизни.", en: "She is an important part of my life.", hi: "важная часть моей жизни" },
            { ru: "Она мне очень дорога.", en: "She is very dear to me.", hi: "очень дорога" }
        ],
        male: [
            { ru: "Он важен для меня.", en: "He is important to me.", hi: "важен для меня" },
            { ru: "Он очень много значит для меня.", en: "He means a lot to me.", hi: "очень много значит для меня" },
            { ru: "Он — важная часть моей жизни.", en: "He is an important part of my life.", hi: "важная часть моей жизни" },
            { ru: "Он мне очень дорог.", en: "He is very dear to me.", hi: "очень дорог" }
        ]
    },
    admire: {
        female: [
            { ru: "Я восхищаюсь ею.", en: "I admire her.", hi: "восхищаюсь ею" },
            { ru: "Она меня вдохновляет.", en: "She inspires me.", hi: "меня вдохновляет" },
            { ru: "Я очень её уважаю.", en: "I respect her very much.", hi: "очень её уважаю" },
            { ru: "Я горжусь ею.", en: "I am proud of her.", hi: "горжусь ею" }
        ],
        male: [
            { ru: "Я восхищаюсь им.", en: "I admire him.", hi: "восхищаюсь им" },
            { ru: "Он меня вдохновляет.", en: "He inspires me.", hi: "меня вдохновляет" },
            { ru: "Я очень его уважаю.", en: "I respect him very much.", hi: "очень его уважаю" },
            { ru: "Я горжусь им.", en: "I am proud of him.", hi: "горжусь им" }
        ]
    },
    love: {
        female: [
            { ru: "Я люблю её.", en: "I love her.", hi: "люблю её" },
            { ru: "Я очень её люблю.", en: "I love her very much.", hi: "очень её люблю" },
            { ru: "Я всем сердцем люблю её.", en: "I love her with all my heart.", hi: "всем сердцем люблю её" },
            { ru: "Я её обожаю.", en: "I adore her.", hi: "её обожаю" }
        ],
        male: [
            { ru: "Я люблю его.", en: "I love him.", hi: "люблю его" },
            { ru: "Я очень его люблю.", en: "I love him very much.", hi: "очень его люблю" },
            { ru: "Я всем сердцем люблю его.", en: "I love him with all my heart.", hi: "всем сердцем люблю его" },
            { ru: "Я его обожаю.", en: "I adore him.", hi: "его обожаю" }
        ]
    }
};

/* Curated two-sentiment combinations. The engine never glues arbitrary Russian
   sentences together; every pair below is deliberately written. */
const SPECIAL_COMBINATIONS = {
    "kind|funny": { female: { ru: "Она <mark>добрая и заботливая</mark>, и с ней <mark>всегда весело</mark>.", plain: "Она добрая и заботливая, и с ней всегда весело.", en: "She is kind and caring, and it's always fun with her." }, male: { ru: "Он <mark>добрый и заботливый</mark>, и с ним <mark>всегда весело</mark>.", plain: "Он добрый и заботливый, и с ним всегда весело.", en: "He is kind and caring, and it's always fun with him." } },
    "kind|smart": { female: { ru: "Она <mark>добрая</mark> и <mark>умная</mark>.", plain: "Она добрая и умная.", en: "She is kind and smart." }, male: { ru: "Он <mark>добрый</mark> и <mark>умный</mark>.", plain: "Он добрый и умный.", en: "He is kind and smart." } },
    "kind|beautiful": { female: { ru: "Она <mark>добрая</mark> и <mark>красивая</mark>.", plain: "Она добрая и красивая.", en: "She is kind and beautiful." }, male: { ru: "Он <mark>добрый</mark> и <mark>красивый</mark>.", plain: "Он добрый и красивый.", en: "He is kind and handsome." } },
    "kind|happy": { female: { ru: "Она <mark>очень заботливая</mark>, и рядом с ней <mark>мне хорошо</mark>.", plain: "Она очень заботливая, и рядом с ней мне хорошо.", en: "She is very caring, and I feel happy when I'm with her." }, male: { ru: "Он <mark>очень заботливый</mark>, и рядом с ним <mark>мне хорошо</mark>.", plain: "Он очень заботливый, и рядом с ним мне хорошо.", en: "He is very caring, and I feel happy when I'm with him." } },
    "kind|important": { female: { ru: "У неё <mark>золотое сердце</mark>, и она <mark>очень много значит для меня</mark>.", plain: "У неё золотое сердце, и она очень много значит для меня.", en: "She has a heart of gold, and she means a lot to me." }, male: { ru: "У него <mark>золотое сердце</mark>, и он <mark>очень много значит для меня</mark>.", plain: "У него золотое сердце, и он очень много значит для меня.", en: "He has a heart of gold, and he means a lot to me." } },
    "kind|admire": { female: { ru: "Она <mark>всегда готова помочь</mark>, и я <mark>очень её уважаю</mark>.", plain: "Она всегда готова помочь, и я очень её уважаю.", en: "She is always ready to help, and I respect her very much." }, male: { ru: "Он <mark>всегда готов помочь</mark>, и я <mark>очень его уважаю</mark>.", plain: "Он всегда готов помочь, и я очень его уважаю.", en: "He is always ready to help, and I respect him very much." } },
    "kind|love": { female: { ru: "У неё <mark>золотое сердце</mark>, и я <mark>очень её люблю</mark>.", plain: "У неё золотое сердце, и я очень её люблю.", en: "She has a heart of gold, and I love her very much." }, male: { ru: "У него <mark>золотое сердце</mark>, и я <mark>очень его люблю</mark>.", plain: "У него золотое сердце, и я очень его люблю.", en: "He has a heart of gold, and I love him very much." } },
    "funny|smart": { female: { ru: "Она <mark>умная</mark> и умеет <mark>меня рассмешить</mark>.", plain: "Она умная и умеет меня рассмешить.", en: "She is smart and knows how to make me laugh." }, male: { ru: "Он <mark>умный</mark> и умеет <mark>меня рассмешить</mark>.", plain: "Он умный и умеет меня рассмешить.", en: "He is smart and knows how to make me laugh." } },
    "funny|beautiful": { female: { ru: "Она <mark>красивая</mark>, и у неё <mark>отличное чувство юмора</mark>.", plain: "Она красивая, и у неё отличное чувство юмора.", en: "She is beautiful and has a great sense of humor." }, male: { ru: "Он <mark>красивый</mark>, и у него <mark>отличное чувство юмора</mark>.", plain: "Он красивый, и у него отличное чувство юмора.", en: "He is handsome and has a great sense of humor." } },
    "funny|happy": { female: { ru: "Она <mark>умеет меня рассмешить</mark> и всегда <mark>заставляет меня улыбаться</mark>.", plain: "Она умеет меня рассмешить и всегда заставляет меня улыбаться.", en: "She knows how to make me laugh and always makes me smile." }, male: { ru: "Он <mark>умеет меня рассмешить</mark> и всегда <mark>заставляет меня улыбаться</mark>.", plain: "Он умеет меня рассмешить и всегда заставляет меня улыбаться.", en: "He knows how to make me laugh and always makes me smile." } },
    "funny|important": { female: { ru: "С ней <mark>всегда весело</mark>, и она <mark>очень много значит для меня</mark>.", plain: "С ней всегда весело, и она очень много значит для меня.", en: "It's always fun with her, and she means a lot to me." }, male: { ru: "С ним <mark>всегда весело</mark>, и он <mark>очень много значит для меня</mark>.", plain: "С ним всегда весело, и он очень много значит для меня.", en: "It's always fun with him, and he means a lot to me." } },
    "funny|admire": { female: { ru: "У неё <mark>отличное чувство юмора</mark>, и она <mark>меня вдохновляет</mark>.", plain: "У неё отличное чувство юмора, и она меня вдохновляет.", en: "She has a great sense of humor, and she inspires me." }, male: { ru: "У него <mark>отличное чувство юмора</mark>, и он <mark>меня вдохновляет</mark>.", plain: "У него отличное чувство юмора, и он меня вдохновляет.", en: "He has a great sense of humor, and he inspires me." } },
    "funny|love": { female: { ru: "С ней <mark>всегда весело</mark>, и я <mark>очень её люблю</mark>.", plain: "С ней всегда весело, и я очень её люблю.", en: "It's always fun with her, and I love her very much." }, male: { ru: "С ним <mark>всегда весело</mark>, и я <mark>очень его люблю</mark>.", plain: "С ним всегда весело, и я очень его люблю.", en: "It's always fun with him, and I love him very much." } },
    "smart|beautiful": { female: { ru: "Она <mark>умная</mark> и <mark>красивая</mark>.", plain: "Она умная и красивая.", en: "She is smart and beautiful." }, male: { ru: "Он <mark>умный</mark> и <mark>красивый</mark>.", plain: "Он умный и красивый.", en: "He is smart and handsome." } },
    "smart|happy": { female: { ru: "Она <mark>очень умная</mark> и <mark>приносит мне радость</mark>.", plain: "Она очень умная и приносит мне радость.", en: "She is very smart and brings me joy." }, male: { ru: "Он <mark>очень умный</mark> и <mark>приносит мне радость</mark>.", plain: "Он очень умный и приносит мне радость.", en: "He is very smart and brings me joy." } },
    "smart|important": { female: { ru: "Я ценю её <mark>острый ум</mark>, и она <mark>очень много значит для меня</mark>.", plain: "Я ценю её острый ум, и она очень много значит для меня.", en: "I value her sharp mind, and she means a lot to me." }, male: { ru: "Я ценю его <mark>острый ум</mark>, и он <mark>очень много значит для меня</mark>.", plain: "Я ценю его острый ум, и он очень много значит для меня.", en: "I value his sharp mind, and he means a lot to me." } },
    "smart|admire": { female: { ru: "Она <mark>невероятно умна</mark> и <mark>меня вдохновляет</mark>.", plain: "Она невероятно умна и меня вдохновляет.", en: "She is incredibly smart and inspires me." }, male: { ru: "Он <mark>невероятно умён</mark> и <mark>меня вдохновляет</mark>.", plain: "Он невероятно умён и меня вдохновляет.", en: "He is incredibly smart and inspires me." } },
    "smart|love": { female: { ru: "Она <mark>невероятно умна</mark>, и я <mark>очень её люблю</mark>.", plain: "Она невероятно умна, и я очень её люблю.", en: "She is incredibly smart, and I love her very much." }, male: { ru: "Он <mark>невероятно умён</mark>, и я <mark>очень его люблю</mark>.", plain: "Он невероятно умён, и я очень его люблю.", en: "He is incredibly smart, and I love him very much." } },
    "beautiful|happy": { female: { ru: "Она <mark>красивая</mark> и <mark>приносит мне радость</mark>.", plain: "Она красивая и приносит мне радость.", en: "She is beautiful and brings me joy." }, male: { ru: "Он <mark>красивый</mark> и <mark>приносит мне радость</mark>.", plain: "Он красивый и приносит мне радость.", en: "He is handsome and brings me joy." } },
    "beautiful|important": { female: { ru: "Она <mark>невероятно красива</mark> и <mark>очень много значит для меня</mark>.", plain: "Она невероятно красива и очень много значит для меня.", en: "She is incredibly beautiful and means a lot to me." }, male: { ru: "Он <mark>очень привлекательный</mark> и <mark>очень много значит для меня</mark>.", plain: "Он очень привлекательный и очень много значит для меня.", en: "He is very attractive and means a lot to me." } },
    "beautiful|admire": { female: { ru: "Она <mark>невероятно красива</mark>, и я <mark>восхищаюсь ею</mark>.", plain: "Она невероятно красива, и я восхищаюсь ею.", en: "She is incredibly beautiful, and I admire her." }, male: { ru: "Он <mark>очень привлекательный</mark>, и я <mark>восхищаюсь им</mark>.", plain: "Он очень привлекательный, и я восхищаюсь им.", en: "He is very attractive, and I admire him." } },
    "beautiful|love": { female: { ru: "Она <mark>невероятно красива</mark>, и я <mark>всем сердцем люблю её</mark>.", plain: "Она невероятно красива, и я всем сердцем люблю её.", en: "She is incredibly beautiful, and I love her with all my heart." }, male: { ru: "Он <mark>очень привлекательный</mark>, и я <mark>всем сердцем люблю его</mark>.", plain: "Он очень привлекательный, и я всем сердцем люблю его.", en: "He is very attractive, and I love him with all my heart." } },
    "happy|important": { female: { ru: "Она <mark>дарит мне счастье</mark> и <mark>очень много значит для меня</mark>.", plain: "Она дарит мне счастье и очень много значит для меня.", en: "She brings me happiness and means a lot to me." }, male: { ru: "Он <mark>дарит мне счастье</mark> и <mark>очень много значит для меня</mark>.", plain: "Он дарит мне счастье и очень много значит для меня.", en: "He brings me happiness and means a lot to me." } },
    "happy|admire": { female: { ru: "Она <mark>приносит мне радость</mark> и <mark>меня вдохновляет</mark>.", plain: "Она приносит мне радость и меня вдохновляет.", en: "She brings me joy and inspires me." }, male: { ru: "Он <mark>приносит мне радость</mark> и <mark>меня вдохновляет</mark>.", plain: "Он приносит мне радость и меня вдохновляет.", en: "He brings me joy and inspires me." } },
    "happy|love": { female: { ru: "Она <mark>дарит мне счастье</mark>, и я <mark>очень её люблю</mark>.", plain: "Она дарит мне счастье, и я очень её люблю.", en: "She brings me happiness, and I love her very much." }, male: { ru: "Он <mark>дарит мне счастье</mark>, и я <mark>очень его люблю</mark>.", plain: "Он дарит мне счастье, и я очень его люблю.", en: "He brings me happiness, and I love him very much." } },
    "important|admire": { female: { ru: "Она <mark>очень много значит для меня</mark>, и я <mark>восхищаюсь ею</mark>.", plain: "Она очень много значит для меня, и я восхищаюсь ею.", en: "She means a lot to me, and I admire her." }, male: { ru: "Он <mark>очень много значит для меня</mark>, и я <mark>восхищаюсь им</mark>.", plain: "Он очень много значит для меня, и я восхищаюсь им.", en: "He means a lot to me, and I admire him." } },
    "important|love": { female: { ru: "Она <mark>мне очень дорога</mark>, и я <mark>всем сердцем люблю её</mark>.", plain: "Она мне очень дорога, и я всем сердцем люблю её.", en: "She is very dear to me, and I love her with all my heart." }, male: { ru: "Он <mark>мне очень дорог</mark>, и я <mark>всем сердцем люблю его</mark>.", plain: "Он мне очень дорог, и я всем сердцем люблю его.", en: "He is very dear to me, and I love him with all my heart." } },
    "admire|love": { female: { ru: "Я <mark>восхищаюсь ею</mark> и <mark>очень её люблю</mark>.", plain: "Я восхищаюсь ею и очень её люблю.", en: "I admire her and love her very much." }, male: { ru: "Я <mark>восхищаюсь им</mark> и <mark>очень его люблю</mark>.", plain: "Я восхищаюсь им и очень его люблю.", en: "I admire him and love him very much." } }
};
/* =========================================================
   END SOMEONE SPECIAL — CURATED EXPRESSION BANK
   ========================================================= */

const SPECIAL_FEMALE_RELS = new Set(["mother", "sister", "grandmother", "great-grandmother", "aunt", "wife", "girlfriend", "fiancée", "ex-wife"]);
const SPECIAL_MALE_RELS = new Set(["father", "brother", "grandfather", "great-grandfather", "uncle", "husband", "boyfriend", "fiancé", "ex-husband"]);

// What "+ Add Someone Special" offers. Friends need a gender picked here
// because "friend" alone doesn't say whether to use Она or Он.
const SPECIAL_NEW_RELS = [
    ["girlfriend", "Girlfriend — девушка"], ["boyfriend", "Boyfriend — парень"],
    ["fiancée", "Fiancée — невеста"], ["fiancé", "Fiancé — жених"],
    ["wife", "Wife — жена"], ["husband", "Husband — муж"],
    ["friend-female", "Friend (female) — подруга"], ["friend-male", "Friend (male) — друг"]
];

let specialSelections = [];   // the one or two feeling keys currently picked
let specialVariantIndex = 0;  // which "Try Another Way" wording is showing
let specialEditingIndex = null; // index of a saved sentence being modified

function englishRelationship(rel) {
    return String(rel || "").replaceAll("-", " ");
}

function specialAllPeople() {
    return [...state.people, ...(state.specialExtras || [])];
}

function special() {
    const all = specialAllPeople();
    return all.find(p => p.id === state.specialId) || all[0] || null;
}

function specialGender(p) {
    if (!p) return "female";
    if (p.specialGender) return p.specialGender;
    if (SPECIAL_FEMALE_RELS.has(p.relationship)) return "female";
    if (SPECIAL_MALE_RELS.has(p.relationship)) return "male";
    return "female";
}

// Two feelings are always looked up in the same order, so "kind|funny"
// and "funny|kind" find the same hand-written sentence.
function specialPairKey(keys) {
    return [...keys]
        .sort((a, b) => SPECIAL_SENTIMENTS.findIndex(x => x.key === a) - SPECIAL_SENTIMENTS.findIndex(x => x.key === b))
        .join("|");
}

function specialIdentityRelationship(p) {
    if (!p) return { ru: "", en: "" };
    const gender = specialGender(p);
    const relMap = {
        mother: ["моя мама", "my mother"], father: ["мой папа", "my father"],
        sister: ["моя сестра", "my sister"], brother: ["мой брат", "my brother"],
        grandmother: ["моя бабушка", "my grandmother"], grandfather: ["мой дедушка", "my grandfather"],
        "great-grandmother": ["моя прабабушка", "my great-grandmother"], "great-grandfather": ["мой прадедушка", "my great-grandfather"],
        aunt: ["моя тётя", "my aunt"], uncle: ["мой дядя", "my uncle"],
        wife: ["моя жена", "my wife"], husband: ["мой муж", "my husband"],
        girlfriend: ["моя девушка", "my girlfriend"], boyfriend: ["мой парень", "my boyfriend"],
        "fiancée": ["моя невеста", "my fiancée"], "fiancé": ["мой жених", "my fiancé"],
        "ex-wife": ["моя бывшая жена", "my ex-wife"], "ex-husband": ["мой бывший муж", "my ex-husband"]
    };
    if (p.relationship === "friend") {
        return gender === "female"
            ? { ru: "Это моя подруга.", en: "This is my friend." }
            : { ru: "Это мой друг.", en: "This is my friend." };
    }
    const pair = relMap[p.relationship];
    if (pair) return { ru: `Это ${pair[0]}.`, en: `This is ${pair[1]}.` };
    return { ru: `Это ${ruRel(p.relationship)}.`, en: `This is my ${englishRelationship(p.relationship)}.` };
}

function renderSpecialIntroduction(p) {
    const intro = $("#specialIntroduction"), question = $("#specialBuilderQuestion");
    if (!p) { intro.hidden = true; question.textContent = "What would you like to say?"; return; }
    const name = p.name || "this person", gender = specialGender(p), rel = specialIdentityRelationship(p);
    const nameRu = gender === "male" ? `Его зовут ${name}.` : `Её зовут ${name}.`;
    const nameEn = gender === "male" ? `His name is ${name}.` : `Her name is ${name}.`;
    intro.hidden = false;
    $("#specialIntroName").textContent = name;
    $("#specialIntroRelationRu").textContent = rel.ru;
    $("#specialIntroRelationEn").textContent = rel.en;
    $("#specialIntroNameRu").textContent = nameRu;
    $("#specialIntroNameEn").textContent = nameEn;
    $("#specialIntroRelationSpeak").dataset.speak = rel.ru;
    $("#specialIntroNameSpeak").dataset.speak = nameRu;
    question.textContent = `What would you like to say about ${name}?`;
}

// Returns { ru (with <mark> highlights), plain, en, sentiments } or null.
function specialCurrentExpression() {
    const p = special();
    if (!p || !specialSelections.length) return null;
    const gender = specialGender(p);
    if (specialSelections.length === 1) {
        const variants = SPECIAL_BANK[specialSelections[0]]?.[gender] || [];
        if (!variants.length) return null;
        const v = variants[specialVariantIndex % variants.length];
        const escaped = v.hi.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        return { ru: v.ru.replace(new RegExp(escaped), `<mark>${v.hi}</mark>`), plain: v.ru, en: v.en, sentiments: [...specialSelections] };
    }
    const combo = SPECIAL_COMBINATIONS[specialPairKey(specialSelections)]?.[gender];
    return combo ? { ...combo, sentiments: [...specialSelections] } : null;
}

function renderSpecialPersonOptions() {
    const el = $("#specialPerson");
    el.innerHTML = '<option value="">Choose a person…</option>';
    specialAllPeople().forEach(p => el.add(new Option(`${p.name || "Unnamed"} — ${englishRelationship(p.relationship)}`, p.id)));
    el.add(new Option("＋ Add Someone Special", "__new__"));
}

function renderSpecialSentiments() {
    const box = $("#specialSentiments");
    box.innerHTML = "";
    SPECIAL_SENTIMENTS.forEach(s => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "special-sentiment" + (specialSelections.includes(s.key) ? " selected" : "");
        b.textContent = s.label;
        b.onclick = () => toggleSpecialSentiment(s.key);
        box.append(b);
    });
}

function toggleSpecialSentiment(key) {
    if (specialSelections.includes(key)) specialSelections = specialSelections.filter(x => x !== key);
    else if (specialSelections.length < 2) specialSelections.push(key);
    else { $("#specialSentimentHint").textContent = "Choose no more than two feelings for one sentence."; return; }
    $("#specialSentimentHint").textContent = "Click to add; click again to remove. Choose up to two.";
    specialVariantIndex = 0;
    specialEditingIndex = null;
    renderSpecialSentiments();
    renderSpecialPreview();
}

function renderSpecialPreview() {
    const preview = $("#specialExpressionPreview"), x = specialCurrentExpression();
    preview.hidden = !x;
    if (!x) return;
    $("#specialRussian").innerHTML = x.ru;
    $("#specialEnglish").textContent = x.en;
    $("#specialSaveExpression").textContent = specialEditingIndex === null ? "Add to My Expressions" : "Save Changes";
}

function specialSavedFor(p) {
    if (!p) return [];
    if (!state.specialExpressions) state.specialExpressions = {};
    if (!state.specialExpressions[p.id]) state.specialExpressions[p.id] = [];
    return state.specialExpressions[p.id];
}

function renderSpecialSaved() {
    const p = special(), box = $("#specialSavedExpressions");
    box.innerHTML = "";
    $("#specialSavedHeading").textContent = p ? `My Expressions About ${p.name || "This Person"}` : "My Expressions";
    const saved = specialSavedFor(p);
    if (!saved.length) {
        box.innerHTML = '<p class="special-saved-empty">Your saved Russian expressions will appear here.</p>';
        return;
    }
    saved.forEach((x, i) => {
        const card = document.createElement("div");
        card.className = "special-saved-card";
        card.innerHTML = `<b>${x.plain}</b><small>${x.en}</small><div class="special-saved-actions no-print"><button type="button" data-listen>🔊 Listen</button><button type="button" data-modify>✏ Modify</button><button type="button" data-delete>🗑 Delete</button></div>`;
        card.querySelector("[data-listen]").onclick = () => speakRussianWord(x.plain);
        card.querySelector("[data-modify]").onclick = () => {
            specialSelections = [...(x.sentiments || [])];
            specialEditingIndex = i;
            specialVariantIndex = 0;
            renderSpecialSentiments();
            renderSpecialPreview();
        };
        card.querySelector("[data-delete]").onclick = async () => {
            saved.splice(i, 1);
            specialEditingIndex = null;
            await saveIdentityCard();
            renderSpecialSaved();
            renderSpecialPreview();
        };
        box.append(card);
    });
}

function renderSpecial() {
    if (!state.specialExtras) state.specialExtras = [];
    if (!state.specialExpressions) state.specialExpressions = {};
    renderSpecialPersonOptions();
    renderSpecialSentiments();
    const p = special();
    if (p) { state.specialId = p.id; $("#specialPerson").value = p.id; }
    const img = $("#specialPhoto"), fallback = $("#specialPortraitFallback"), label = $("#specialPhotoLabel");
    if (p) {
        $("#specialName").textContent = p.name || "Unnamed";
        $("#specialRelLabel").textContent = englishRelationship(p.relationship);
        img.style.display = p.photo ? "block" : "none";
        img.src = p.photo || "";
        fallback.style.display = p.photo ? "none" : "grid";
        label.textContent = p.photo ? "Change Photo" : "Add Photo";
    } else {
        $("#specialName").textContent = "Someone Special";
        $("#specialRelLabel").textContent = "";
        img.style.display = "none";
        fallback.style.display = "grid";
        label.textContent = "Add Photo";
    }
    renderSpecialIntroduction(p);
    renderSpecialPreview();
    renderSpecialSaved();
}

function openSpecialNewPanel() {
    $("#specialNewPanel").hidden = false;
    $("#specialNewName").value = "";
    $("#specialNewPhoto").value = "";
    fillSelect($("#specialNewRelationship"), SPECIAL_NEW_RELS, "Choose a relationship…");
}

function closeSpecialNewPanel() {
    $("#specialNewPanel").hidden = true;
    if (special()) $("#specialPerson").value = special().id;
    else $("#specialPerson").value = "";
}

async function saveSpecialNewPerson() {
    const name = $("#specialNewName").value.trim(), raw = $("#specialNewRelationship").value;
    if (!name) return alert("Enter a name.");
    if (!raw) return alert("Choose a relationship.");
    let relationship = raw, gender = "";
    if (raw === "friend-female") { relationship = "friend"; gender = "female"; }
    if (raw === "friend-male") { relationship = "friend"; gender = "male"; }
    const photo = await photoData($("#specialNewPhoto").files[0]);
    const p = { id: crypto.randomUUID(), name, relationship, photo, specialGender: gender };
    state.specialExtras.push(p);
    state.specialId = p.id;
    specialSelections = [];
    specialEditingIndex = null;
    await saveIdentityCard();
    $("#specialNewPanel").hidden = true;
    renderSpecial();
}

async function saveSpecialExpression() {
    const p = special(), x = specialCurrentExpression();
    if (!p || !x) return;
    const saved = specialSavedFor(p);
    const record = { plain: x.plain, en: x.en, sentiments: [...x.sentiments] };
    if (specialEditingIndex !== null) saved[specialEditingIndex] = record;
    else {
        if (saved.length >= 4) return alert("You can save up to four expressions for this person.");
        saved.push(record);
    }
    specialEditingIndex = null;
    await saveIdentityCard();
    renderSpecialSaved();
    renderSpecialPreview();
}

function initSpecial() {
    $("#specialHomeBtn").onclick = () => show("launch");
    $("#specialPrintBtn").onclick = () => window.print();
    $("#specialClearBtn").onclick = clearIdentityCard;

    $("#specialPerson").onchange = async e => {
        if (e.target.value === "__new__") { openSpecialNewPanel(); return; }
        state.specialId = e.target.value || null;
        specialSelections = [];
        specialEditingIndex = null;
        await saveIdentityCard();
        renderSpecial();
    };

    $("#specialPhotoInput").onchange = async e => {
        const p = special(), file = e.target.files[0];
        if (!p || !file) return;
        p.photo = await photoData(file);
        e.target.value = "";
        await saveIdentityCard();
        renderSpecial();
    };

    $("#specialSaveNew").onclick = saveSpecialNewPerson;
    $("#specialCancelNew").onclick = closeSpecialNewPanel;
    $("#specialIntroRelationSpeak").onclick = e => speakRussianWord(e.currentTarget.dataset.speak || "");
    $("#specialIntroNameSpeak").onclick = e => speakRussianWord(e.currentTarget.dataset.speak || "");
    $("#specialSpeak").onclick = () => { const x = specialCurrentExpression(); if (x) speakRussianWord(x.plain); };
    $("#specialSaveExpression").onclick = saveSpecialExpression;
    // Explore More (Screen 5): the same show() every other screen uses.
    $("#specialExploreMore").onclick = () => show("explore");
}

// ==================================================
//    SCREEN 5 — EXPLORE MORE
//
//  Static on purpose: the same four cards for everyone, a
//  progression from like → really like → love → adore, each
//  showing both directions (I → you, you → me). Nothing here
//  reads from state. Only the Listen buttons do anything.
//  The cards are built here (not typed into the HTML) so the
//  Russian lives in one place, as data.
// ==================================================

const EXPLORE_FEELING_CARDS = [
    [
        ["Ты мне нравишься.", "I like you."],
        ["Я тебе нравлюсь.", "You like me."]
    ],
    [
        ["Ты мне очень нравишься.", "I really like you."],
        ["Я тебе очень нравлюсь.", "You really like me."]
    ],
    [
        ["Я тебя люблю.", "I love you."],
        ["Ты меня любишь.", "You love me."]
    ],
    [
        ["Я тебя просто обожаю.", "I simply adore you."],
        ["Ты меня просто обожаешь.", "You simply adore me."]
    ]
];

function renderExplore() {
    const host = $("#feelingCards");
    host.innerHTML = EXPLORE_FEELING_CARDS.map(pairs => `
        <article class="feeling-card">
            ${pairs.map(([ru, en]) => `
                <div class="feeling-pair">
                    <strong>${ru}</strong>
                    <em>${en}</em>
                    <button class="speaker no-print" type="button" data-say="${ru}" aria-label="Listen to ${ru}">🔊 Listen</button>
                </div>
            `).join("")}
        </article>
    `).join("");
    host.querySelectorAll("[data-say]").forEach(btn => {
        btn.onclick = () => speakRussianWord(btn.dataset.say);
    });
}

// ==================================================
//    EXPLORE MORE DOORWAY 1 — WHY DOES RUSSIAN CHANGE?
//
//  Nothing to render: the lesson is painted into the
//  background art. This only wires the Print button and
//  flips between the two grammar-candy images on the
//  "See More" layer (exactly one is visible at a time —
//  the .active class is what shows it).
// ==================================================

function initWhy() {
    $("#whyPrintBtn").onclick = () => window.print();

    const like = $("#whyCandyLike"), pattern = $("#whyCandyPattern");
    $("#showPatternCandy").onclick = () => {
        like.classList.remove("active");
        pattern.classList.add("active");
    };
    $("#backToLikeCandy").onclick = () => {
        pattern.classList.remove("active");
        like.classList.add("active");
    };
}



// ==================================================
//    EXPLORE MORE DOORWAY 2 — TRY IT WITH DIFFERENT PEOPLE
//
//  Reuses the same hand-written SPECIAL_BANK / SPECIAL_COMBINATIONS
//  sentences as Someone Special, so the Russian is already checked.
//  People added with "Add Someone Else" live only in
//  state.tryExtraPeople — never in My People or on the tree.
//  Saved sentences live in state.trySavedExpressions, keyed by person id.
// ==================================================

let trySelections = [];
let tryVariantIndex = 0;
let tryEditingIndex = null;

function tryAllPeople() {
    return [...state.people, ...(state.tryExtraPeople || [])];
}

function tryPerson() {
    return tryAllPeople().find(p => p.id === state.tryPersonId) || null;
}

function tryCurrentExpression() {
    const p = tryPerson();
    if (!p || !trySelections.length) return null;
    const gender = specialGender(p);
    if (trySelections.length === 1) {
        const variants = SPECIAL_BANK[trySelections[0]]?.[gender] || [];
        if (!variants.length) return null;
        const v = variants[tryVariantIndex % variants.length];
        const escaped = v.hi.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        return { ru: v.ru.replace(new RegExp(escaped), `<mark>${v.hi}</mark>`), plain: v.ru, en: v.en, sentiments: [...trySelections] };
    }
    const combo = SPECIAL_COMBINATIONS[specialPairKey(trySelections)]?.[gender];
    return combo ? { ...combo, sentiments: [...trySelections] } : null;
}

function renderTryPersonOptions() {
    const el = $("#tryPerson");
    el.innerHTML = '<option value="">Choose a family member…</option>';
    state.people.forEach(p => el.add(new Option(`${p.name || "Unnamed"} — ${englishRelationship(p.relationship)}`, p.id)));
    if ((state.tryExtraPeople || []).length) {
        const group = document.createElement("optgroup");
        group.label = "People added here";
        state.tryExtraPeople.forEach(p => group.append(new Option(`${p.name || "Unnamed"} — ${englishRelationship(p.relationship)}`, p.id)));
        el.append(group);
    }
    el.value = state.tryPersonId || "";
}

function renderTrySentiments() {
    const box = $("#trySentiments");
    box.innerHTML = "";
    SPECIAL_SENTIMENTS.forEach(s => {
        const b = document.createElement("button");
        b.type = "button";
        b.textContent = s.label;
        b.className = trySelections.includes(s.key) ? "selected" : "";
        b.onclick = () => toggleTrySentiment(s.key);
        box.append(b);
    });
}

function toggleTrySentiment(key) {
    const hint = $("#trySentimentHint");
    if (trySelections.includes(key)) trySelections = trySelections.filter(x => x !== key);
    else if (trySelections.length < 2) trySelections.push(key);
    else { hint.textContent = "Choose no more than two sentiments for one expression."; return; }
    hint.textContent = "Choose up to two.";
    tryVariantIndex = 0;
    tryEditingIndex = null;
    renderTrySentiments();
    renderTryPreview();
}

function renderTryIdentity() {
    const p = tryPerson(), box = $("#trySelectedIdentity"), q = $("#tryBuilderQuestion");
    if (!p) { box.hidden = true; q.textContent = "What would you like to say?"; return; }
    box.hidden = false;
    box.innerHTML = `<strong>${p.name || "Unnamed"}</strong> · ${englishRelationship(p.relationship)}`;
    // Only people added on this screen can be removed here. Family from
    // My People is managed on the My People screen.
    if ((state.tryExtraPeople || []).some(x => x.id === p.id)) {
        const rm = document.createElement("button");
        rm.type = "button";
        rm.id = "tryRemovePerson";
        rm.className = "try-v1-secondary no-print";
        rm.textContent = "Remove";
        rm.onclick = removeTryPerson;
        box.append(rm);
    }
    q.textContent = `What would you like to say about ${p.name || "this person"}?`;
}

function renderTryPreview() {
    const box = $("#tryExpressionPreview"), x = tryCurrentExpression();
    box.hidden = !x;
    if (!x) return;
    $("#tryRussian").innerHTML = x.ru;
    $("#tryEnglish").textContent = x.en;
    $("#tryAnother").style.display = trySelections.length === 1 ? "" : "none";
    $("#trySaveExpression").textContent = tryEditingIndex === null ? "Add to My Expressions" : "Save Changes";
    $("#trySpeak").onclick = () => speakRussianWord(x.plain);
}

function trySaved() {
    const p = tryPerson();
    if (!p) return [];
    if (!state.trySavedExpressions) state.trySavedExpressions = {};
    if (!state.trySavedExpressions[p.id]) state.trySavedExpressions[p.id] = [];
    return state.trySavedExpressions[p.id];
}

function renderTrySaved() {
    const box = $("#trySavedExpressions"), saved = trySaved();
    $("#trySavedCount").textContent = `(${saved.length}/4)`;
    box.innerHTML = "";
    if (!saved.length) {
        box.innerHTML = '<div class="try-v1-saved-card">Your saved Russian expressions will appear here.</div>';
        return;
    }
    saved.forEach((x, i) => {
        const d = document.createElement("div");
        d.className = "try-v1-saved-card";
        d.innerHTML = `<b>${x.plain}</b><small>${x.en}</small><div class="try-v1-saved-card-actions no-print"><button type="button" data-listen>🔊 Listen</button><button type="button" data-modify>✏ Modify</button><button type="button" data-delete>🗑 Delete</button></div>`;
        d.querySelector("[data-listen]").onclick = () => speakRussianWord(x.plain);
        d.querySelector("[data-modify]").onclick = () => {
            trySelections = [...(x.sentiments || [])];
            tryEditingIndex = i;
            tryVariantIndex = 0;
            renderTrySentiments();
            renderTryPreview();
        };
        d.querySelector("[data-delete]").onclick = async () => {
            saved.splice(i, 1);
            await saveIdentityCard();
            renderTrySaved();
        };
        box.append(d);
    });
}

function renderTryPeople() {
    renderTryPersonOptions();
    renderTrySentiments();
    renderTryIdentity();
    renderTryPreview();
    renderTrySaved();
}

function openTryAddPanel() {
    $("#tryAddPanel").hidden = false;
    $("#tryNewName").value = "";
    fillSelect($("#tryNewRelationship"), SPECIAL_NEW_RELS, "Choose a relationship…");
}

async function saveTryNewPerson() {
    const name = $("#tryNewName").value.trim(), raw = $("#tryNewRelationship").value;
    if (!name) return alert("Enter a name.");
    if (!raw) return alert("Choose a relationship.");
    let relationship = raw, gender = "";
    if (raw === "friend-female") { relationship = "friend"; gender = "female"; }
    if (raw === "friend-male") { relationship = "friend"; gender = "male"; }
    if (!gender) gender = SPECIAL_FEMALE_RELS.has(relationship) ? "female" : "male";
    const p = { id: crypto.randomUUID(), name, relationship, specialGender: gender };
    if (!state.tryExtraPeople) state.tryExtraPeople = [];
    state.tryExtraPeople.push(p);
    state.tryPersonId = p.id;
    trySelections = [];
    tryVariantIndex = 0;
    tryEditingIndex = null;
    await saveIdentityCard();
    $("#tryAddPanel").hidden = true;
    renderTryPeople();
}

async function removeTryPerson() {
    const p = tryPerson();
    if (!p || !(state.tryExtraPeople || []).some(x => x.id === p.id)) return;
    if (!confirm(`Remove ${p.name || "this person"} from this screen? Their saved expressions will be removed too.`)) return;
    state.tryExtraPeople = state.tryExtraPeople.filter(x => x.id !== p.id);
    if (state.trySavedExpressions) delete state.trySavedExpressions[p.id];
    state.tryPersonId = "";
    trySelections = [];
    tryVariantIndex = 0;
    tryEditingIndex = null;
    await saveIdentityCard();
    renderTryPeople();
}

async function saveTryExpression() {
    const x = tryCurrentExpression();
    if (!x) return;
    const saved = trySaved();
    const record = { plain: x.plain, en: x.en, sentiments: [...x.sentiments] };
    if (tryEditingIndex !== null) { saved[tryEditingIndex] = record; tryEditingIndex = null; }
    else {
        if (saved.length >= 4) return alert("You can save up to four expressions for each person.");
        saved.push(record);
    }
    await saveIdentityCard();
    renderTrySaved();
    renderTryPreview();
}

function initTry() {
    $("#tryPrintBtn").onclick = () => window.print();
    $("#tryPerson").onchange = async e => {
        state.tryPersonId = e.target.value;
        trySelections = [];
        tryVariantIndex = 0;
        tryEditingIndex = null;
        await saveIdentityCard();
        renderTryPeople();
    };
    $("#tryAddSomeone").onclick = openTryAddPanel;
    $("#tryCancelNew").onclick = () => { $("#tryAddPanel").hidden = true; };
    $("#trySaveNew").onclick = saveTryNewPerson;
    $("#tryAnother").onclick = () => { tryVariantIndex++; renderTryPreview(); };
    $("#trySaveExpression").onclick = saveTryExpression;
    $("#trySavedToggle").onclick = () => { const l = $("#trySavedExpressions"); l.hidden = !l.hidden; };
}

// ==================================================
//    EXPLORE MORE DOORWAY 3 — WHAT ABOUT MY PETS?
//
//  Up to four pets, each with a type, a name and an optional photo.
//  Pets live only in state.pets (never in My People). The chosen pet
//  is state.petId and the chosen feeling is state.petFeeling.
// ==================================================

const PET_FEELINGS = [
    { key: "like", en: "I like you." },
    { key: "really", en: "I really like you." },
    { key: "love", en: "I love you." },
    { key: "adore", en: "I adore you." }
];

function currentPet() {
    if (!state.pets) state.pets = [];
    return state.pets.find(p => p.id === state.petId) || state.pets[0] || null;
}

function petTypeLabel(p) {
    if (!p) return "Pet";
    if (p.type === "dog") return "Dog";
    if (p.type === "cat") return "Cat";
    return p.otherType || "Other Pet";
}

function petEmoji(p) {
    return p?.type === "dog" ? "🐶" : p?.type === "cat" ? "🐱" : "🐾";
}

function renderPets() {
    if (!state.pets) state.pets = [];
    if (!state.petId && state.pets[0]) state.petId = state.pets[0].id;
    const p = currentPet();

    const box = $("#petChoices");
    box.innerHTML = "";
    state.pets.slice(0, 4).forEach(pet => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "pet-v1-choice" + (pet.id === (p && p.id) ? " selected" : "");
        b.innerHTML = `${pet.photo ? `<img class="pet-photo-thumb" src="${pet.photo}" alt="${pet.name}">` : `<span class="pet-emoji">${petEmoji(pet)}</span>`}<b>${pet.name}</b><small>${petTypeLabel(pet)}</small>`;
        b.onclick = async () => { state.petId = pet.id; await saveIdentityCard(); renderPets(); };
        box.append(b);
    });

    $("#petCount").textContent = `${state.pets.length}/4`;
    $("#petAdd").disabled = state.pets.length >= 4;
    $("#petAdd").textContent = state.pets.length >= 4 ? "Four Pet Limit Reached" : "＋ Add a Pet";
    $("#petPhotoButton").disabled = !p;
    $("#petPhotoButton").textContent = p?.photo ? "📷 Change Selected Pet Photo" : "📷 Add Photo to Selected Pet";
    $("#petPhotoRemove").hidden = !(p && p.photo);
    $("#petRemove").hidden = !p;
    $("#petCurrentName").textContent = p ? p.name : "your pet";

    const pf = $("#petFeelings");
    pf.innerHTML = "";
    PET_FEELINGS.forEach(x => {
        const b = document.createElement("button");
        b.type = "button";
        b.textContent = x.en;
        b.className = x.key === state.petFeeling ? "selected" : "";
        b.disabled = !p;
        b.onclick = async () => { state.petFeeling = x.key; await saveIdentityCard(); renderPets(); };
        pf.append(b);
    });
    updatePet();
}

function updatePet() {
    const p = currentPet(), pic = $("#petPic"), ruEl = $("#petRussian"), enEl = $("#petEnglish"), speakBtn = $("#petSpeak");
    if (!p) {
        pic.textContent = "🐾";
        ruEl.textContent = "Add a pet to begin.";
        enEl.textContent = "";
        speakBtn.disabled = true;
        return;
    }
    if (p.photo) pic.innerHTML = `<img src="${p.photo}" alt="${p.name}">`;
    else pic.textContent = petEmoji(p);
    const name = p.name;
    let ru, en;
    if (state.petFeeling === "like") { ru = `Мне нравится ${name}.`; en = `I like ${name}.`; }
    else if (state.petFeeling === "really") { ru = `Мне очень нравится ${name}.`; en = `I really like ${name}.`; }
    else if (state.petFeeling === "adore") { ru = `Я просто обожаю ${name}.`; en = `I adore ${name}.`; }
    else { ru = `Я очень люблю ${name}.`; en = `I love ${name} very much.`; }
    ruEl.textContent = ru;
    enEl.textContent = en;
    speakBtn.disabled = false;
    speakBtn.onclick = () => speakRussianWord(ru);
}

function openPetAdd() {
    if (!state.pets) state.pets = [];
    if (state.pets.length >= 4) return alert("You can add up to four pets.");
    $("#petNewName").value = "";
    $("#petNewPhoto").value = "";
    $("#petNewType").value = "dog";
    $("#petOtherType").value = "";
    $("#petOtherTypeWrap").hidden = true;
    $("#petAddPanel").hidden = false;
}

function closePetAdd() {
    $("#petAddPanel").hidden = true;
}

async function saveNewPet() {
    if (!state.pets) state.pets = [];
    if (state.pets.length >= 4) return;
    const name = $("#petNewName").value.trim(), type = $("#petNewType").value, otherType = $("#petOtherType").value.trim();
    if (!name) return alert("Give your pet a name.");
    if (type === "other" && !otherType) return alert("Tell us what kind of pet this is.");
    const photo = await photoData($("#petNewPhoto").files[0]);
    const p = { id: crypto.randomUUID(), name, type, otherType: type === "other" ? otherType : "", photo };
    state.pets.push(p);
    state.petId = p.id;
    await saveIdentityCard();
    closePetAdd();
    renderPets();
}

async function removeCurrentPet() {
    const p = currentPet();
    if (!p) return;
    if (!confirm(`Remove ${p.name} from this screen?`)) return;
    state.pets = state.pets.filter(x => x.id !== p.id);
    state.petId = state.pets[0] ? state.pets[0].id : null;
    await saveIdentityCard();
    renderPets();
}

function initPets() {
    $("#petPrintBtn").onclick = () => window.print();
    $("#petAdd").onclick = openPetAdd;
    $("#petCancel").onclick = closePetAdd;
    $("#petSave").onclick = saveNewPet;
    $("#petRemove").onclick = removeCurrentPet;
    $("#petNewType").onchange = e => { $("#petOtherTypeWrap").hidden = e.target.value !== "other"; };
    $("#petPhotoButton").onclick = () => $("#petPhotoInput").click();
    $("#petPhotoInput").onchange = async e => {
        const p = currentPet(), file = e.target.files[0];
        if (!p || !file) return;
        p.photo = await photoData(file);
        e.target.value = "";
        await saveIdentityCard();
        renderPets();
    };
    $("#petPhotoRemove").onclick = async () => {
        const p = currentPet();
        if (!p || !p.photo) return;
        p.photo = "";
        $("#petPhotoInput").value = "";
        await saveIdentityCard();
        renderPets();
    };
}

(async () => {
    await loadIdentityCard();
    initIdentityCard();
    initConnections();
    initCallThem();
    initSpecial();
    initWhy();
    initTry();
    initPets();
    renderIdentityCard();
})();

// ==================================================
//    END — DOOR 1 FAMILY IDENTITY CARD (Screens 1–4)
// ==================================================

// ============================================================

// BEGIN LIVING SENTENCE — isolated three-panel workspace
(() => {
    const scene = document.getElementById('ls-scene'); if (!scene) return;
    const $ = id => scene.querySelector('#' + id);
    const lex = { brother: ['брат', 'братья', 'brother', 'm'], sister: ['сестра', 'сёстры', 'sister', 'f'], uncle: ['дядя', 'дяди', 'uncle', 'm'], aunt: ['тётя', 'тёти', 'aunt', 'f'], father: ['отец', 'отцы', 'father', 'm'], mother: ['мама', 'мамы', 'mother', 'f'], son: ['сын', 'сыновья', 'son', 'm'], daughter: ['дочь', 'дочери', 'daughter', 'f'], grandfather: ['дедушка', 'дедушки', 'grandfather', 'm'], grandmother: ['бабушка', 'бабушки', 'grandmother', 'f'], cousin_m: ['двоюродный брат', 'двоюродные братья', 'male cousin', 'm'], cousin_f: ['двоюродная сестра', 'двоюродные сёстры', 'female cousin', 'f'] };
    const nameBank = { m: ['Иван', 'Алексей', 'Дмитрий'], f: ['Анна', 'Мария', 'Елена'] };
    const nameGender = name => Object.entries(nameBank).find(([, names]) => names.includes(name))?.[0];
    const nameChoices = (gender, current) => select('name', nameBank[gender].map(name => [name, name]), nameBank[gender].includes(current) ? current : nameBank[gender][0]);
    const nameForRelationship = (rel, current) => { const gender = lex[rel][3]; return nameGender(current) === gender ? current : nameBank[gender][0]; };
    const poss = { my: ['мой', 'моя', 'мои', 'my'], your: ['твой', 'твоя', 'твои', 'your'], your_formal: ['ваш', 'ваша', 'ваши', 'your (formal)'], his: ['его', 'его', 'его', 'his'], her: ['её', 'её', 'её', 'her'], our: ['наш', 'наша', 'наши', 'our'], their: ['их', 'их', 'их', 'their'] };
    const fam = { my: ['моей', 'my'], your: ['твоей', 'your'], your_formal: ['вашей', 'your (formal)'], our: ['нашей', 'our'], their: ['их', 'their'] };
    const desc = { oldest: ['самый старший', 'самая старшая', 'самые старшие', 'oldest'], youngest: ['самый младший', 'самая младшая', 'самые младшие', 'youngest'], tallest: ['самый высокий', 'самая высокая', 'самые высокие', 'tallest'], shortest: ['самый низкий', 'самая низкая', 'самые низкие', 'shortest'] };
    const nums = ['ноль', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять', 'десять', 'одиннадцать', 'двенадцать', 'тринадцать', 'четырнадцать', 'пятнадцать', 'шестнадцать', 'семнадцать', 'восемнадцать', 'девятнадцать', 'двадцать'];
    const tens = ['', '', 'двадцать', 'тридцать', 'сорок', 'пятьдесят', 'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто'];
    const number = n => n <= 20 ? nums[n] : n < 100 ? (tens[Math.floor(n / 10)] + (n % 10 ? ' ' + nums[n % 10] : '')) : String(n);
    const years = n => { let k = n % 100; return k >= 11 && k <= 14 ? 'лет' : n % 10 === 1 ? 'год' : n % 10 >= 2 && n % 10 <= 4 ? 'года' : 'лет' };
    // Five independently editable starting points. Each selection has its own state and undo stack.
    const makePerson = (id, owner, rel, name, descriptor, family) => ({ id, owner, rel, name, count: 1, descriptor, family });
    const presets = [
        { title: 'Introductions', hint: 'Meet two family members. Change names, relationships and ownership.', people: [makePerson('p1', 'my', 'brother', 'Иван', 'oldest', 'our'), makePerson('p2', 'your', 'sister', 'Анна', 'youngest', 'your')], additions: [] },
        { title: 'Ages', hint: 'Explore how ages are expressed. Add comparisons when you are ready.', people: [makePerson('p1', 'my', 'brother', 'Иван', 'oldest', 'our')], additions: [{ id: 'seed-age', type: 'age', person: 'p1', value: '25' }] },
        { title: 'Heights', hint: 'Explore descriptions of height and comparisons.', people: [makePerson('p1', 'my', 'sister', 'Анна', 'tallest', 'our')], additions: [{ id: 'seed-height', type: 'height', person: 'p1', value: '170' }] },
        { title: 'Our Families', hint: 'Change family references and add people to compare families.', people: [makePerson('p1', 'our', 'brother', 'Алексей', 'youngest', 'our'), makePerson('p2', 'their', 'sister', 'Мария', 'oldest', 'their')], additions: [] },
        { title: 'Connections', hint: 'Explore several relationships and build a family story.', people: [makePerson('p1', 'my', 'cousin_f', 'Елена', 'youngest', 'our'), makePerson('p2', 'her', 'uncle', 'Дмитрий', 'oldest', 'their')], additions: [] }
    ];
    let activePreset = 0;
    const initial = (index = activePreset) => ({ people: JSON.parse(JSON.stringify(presets[index].people)), additions: JSON.parse(JSON.stringify(presets[index].additions)) });
    const sessions = presets.map((_, i) => ({ state: initial(i), history: [], seq: 0, discovery: '' }));
    let state = sessions[0].state, history = sessions[0].history, editing = null, mode = null, seq = 0;
    function saveSession() { const current = sessions[activePreset]; current.state = state; current.history = history; current.seq = seq; current.discovery = $('ls-discovery').innerHTML; }
    function choosePreset(index) { if (index === activePreset || !sessions[index]) return; saveSession(); activePreset = index; const session = sessions[index]; state = session.state; history = session.history; seq = session.seq; editing = null; mode = null; $('ls-editor').hidden = true; $('ls-discovery').innerHTML = session.discovery || ('Sentence ' + (index + 1) + ' — ' + presets[index].title + '. ' + presets[index].hint); $('ls-preset-hint').textContent = presets[index].hint; render(); }
    scene.querySelectorAll('input[name="ls-preset"]').forEach(radio => radio.addEventListener('change', () => { if (radio.checked) choosePreset(Number(radio.value)); }));
    const clone = x => JSON.parse(JSON.stringify(x));
    const button = (text, kind, id, field) => `<button type="button" class="ls-word" data-ls-person="${id}" data-ls-field="${field}" title="Change ${kind}">${text}</button>`;
    const pinfo = p => { let g = lex[p.rel][3], pl = p.count > 1, k = pl ? 2 : g === 'm' ? 0 : 1; return { g, pl, k, pro: pl ? 'они' : g === 'm' ? 'он' : 'она', enpro: pl ? 'they' : g === 'm' ? 'he' : 'she' }; };
    function personRu(p) { const a = pinfo(p), l = lex[p.rel], d = desc[p.descriptor]; return `это ${button(poss[p.owner][a.k] + ' ' + l[a.pl ? 1 : 0], 'relationship', p.id, 'identity')} ${button(p.name, 'name', p.id, 'name')}, и ${a.pro} ${button(d[a.k], 'description', p.id, 'descriptor')} ${button('в ' + fam[p.family][0] + ' семье', 'family reference', p.id, 'family')}`; }
    function personEn(p) { const a = pinfo(p), l = lex[p.rel]; return `this ${a.pl ? 'group includes' : 'is'} ${poss[p.owner][3]} ${l[2]}${a.pl ? 's' : ''} ${p.name}, and ${a.enpro} ${a.pl ? 'are' : 'is'} the ${desc[p.descriptor][3]} in ${fam[p.family][1]} family`; }
    const getP = id => state.people.find(p => p.id === id);
    const genitiveName = name => { if (/а$/i.test(name)) return name.slice(0, -1) + 'ы'; if (/я$/i.test(name)) return name.slice(0, -1) + 'и'; if (/й$/i.test(name)) return name.slice(0, -1) + 'я'; if (/ь$/i.test(name)) return name.slice(0, -1) + 'я'; if (/[бвгджзклмнпрстфхцчшщ]$/i.test(name)) return name + 'а'; return name; };
    function addition(a) {
        const p = getP(a.person) || state.people[0], name = p ? p.name : 'этот человек', info = p ? pinfo(p) : { g: 'm' }; switch (a.type) {
            case 'age': return { ru: `${info.g === 'f' ? 'ей' : 'ему'} ${number(+a.value)} ${years(+a.value)}`, en: `${name} is ${a.value} years old` };
            case 'height': return { ru: `рост ${genitiveName(name)} — ${a.value} см`, en: `${name} is ${a.value} cm tall` };
            case 'comparison': { const other = getP(a.other) || state.people[1] || p; const words = { older: 'старше', younger: 'младше', taller: 'выше', shorter: 'ниже' }; return { ru: `${name} ${words[a.value]} ${genitiveName(other.name)}`, en: `${name} is ${a.value} than ${other.name}` }; }
            case 'description': { const d = desc[a.value], k = info.k; return { ru: `${info.pro} ${d[k]} в ${fam[a.family || 'our'][0]} семье`, en: `${name} is the ${d[3]} in ${fam[a.family || 'our'][1]} family` }; }
            case 'family': return { ru: `${info.pro} живёт в ${fam[a.value][0]} семье`, en: `${name} lives in ${fam[a.value][1]} family` };
            default: return { ru: '', en: '' };
        }
    }
    function render() {
        const base = state.people.map(personRu).join(', а '); const extra = state.additions.map(a => addition(a).ru).filter(Boolean); $('ls-russian').innerHTML = (base + (extra.length ? ', а ' + extra.join(', а ') : '') + '.'); $('ls-english').textContent = state.people.map(personEn).join(', while ') + (state.additions.length ? '; ' + state.additions.map(a => addition(a).en).join('; ') : '') + '.'; $('ls-undo').disabled = !history.length; $('ls-reset').disabled = !history.length;
        $('ls-additions').innerHTML = state.additions.length ? state.additions.map(a => { const v = addition(a); return `<div class="ls-added"><span>${v.en}<small lang="ru">${v.ru}</small></span><div><button type="button" data-ls-edit="${a.id}">✎ Edit</button><button type="button" data-ls-remove="${a.id}">× Remove</button></div></div>` }).join('') : '<p class="ls-empty">Your additions will appear here.</p>';
    }
    function commit(message, detail) { history.push(clone(state)); $('ls-discovery').innerHTML = `<strong>${message}</strong><br>${detail}`; }
    function changePerson(id, field, value) { const p = getP(id); if (!p || String(p[field]) === String(value)) return; const before = p[field]; commit('You changed ' + field.replace('rel', 'relationship') + '.', 'The Laboratory updates linked Russian words automatically. Watch agreement, pronouns and descriptions change together.'); p[field] = field === 'count' ? Number(value) : value; render(); }
    const select = (name, items, current) => `<label>${name}<select name="${name}">${items.map(([k, v]) => `<option value="${k}" ${String(k) === String(current) ? 'selected' : ''}>${v}</option>`).join('')}</select></label>`;
    const opts = o => Object.entries(o).map(([k, v]) => [k, v]);
    const personOpts = () => state.people.map(p => [p.id, p.name]);
    function editPhrase(id, field) { const p = getP(id); if (!p) return; editing = null; mode = 'phrase'; let body = ''; if (field === 'identity') { body = select('owner', opts(Object.fromEntries(Object.entries(poss).map(([k, v]) => [k, v[3]]))), p.owner) + select('relationship', opts(Object.fromEntries(Object.entries(lex).map(([k, v]) => [k, v[2]]))), p.rel) + select('count', [[1, 'One'], [2, 'Two'], [3, 'Three']], p.count); } if (field === 'name') body = nameChoices(lex[p.rel][3], p.name); if (field === 'descriptor') body = select('descriptor', opts(Object.fromEntries(Object.entries(desc).map(([k, v]) => [k, v[3]]))), p.descriptor); if (field === 'family') body = select('family', opts(Object.fromEntries(Object.entries(fam).map(([k, v]) => [k, v[1]]))), p.family); $('ls-editor').hidden = false; $('ls-editor').innerHTML = `<strong>✎ Change this phrase</strong><form id="ls-form">${body}<div class="ls-form-actions"><button type="submit">Apply Change</button><button type="button" data-ls-cancel>Cancel</button></div></form>`; $('ls-editor').dataset.person = id; $('ls-editor').dataset.field = field; }
    function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function openAdd(type, existing) {
        mode = type; editing = existing || null; const a = existing ? clone(state.additions.find(x => x.id === existing)) : { person: state.people[0].id, other: state.people[1]?.id || state.people[0].id, value: type === 'age' ? 25 : type === 'height' ? 175 : type === 'comparison' ? 'older' : type === 'description' ? 'tallest' : 'our', family: 'our' };
        let form = ''; if (type === 'person') { form = select('owner', opts(Object.fromEntries(Object.entries(poss).map(([k, v]) => [k, v[3]]))), 'my') + select('relationship', opts(Object.fromEntries(Object.entries(lex).map(([k, v]) => [k, v[2]]))), 'sister') + select('count', [[1, 'One'], [2, 'Two'], [3, 'Three']], 1) + nameChoices('f', 'Мария'); }
        else { form = select('person', personOpts(), a.person); if (type === 'comparison') form += select('value', opts({ older: 'Older than', younger: 'Younger than', taller: 'Taller than', shorter: 'Shorter than' }), a.value) + select('other', personOpts(), a.other); if (type === 'age' || type === 'height') form += `<label>${type === 'age' ? 'Age in years' : 'Height in cm'}<input name="value" type="number" min="${type === 'age' ? 0 : 40}" max="${type === 'age' ? 110 : 250}" value="${a.value}"></label>`; if (type === 'description') form += select('value', opts(Object.fromEntries(Object.entries(desc).map(([k, v]) => [k, v[3]]))), a.value) + select('family', opts(Object.fromEntries(Object.entries(fam).map(([k, v]) => [k, v[1]]))), a.family); if (type === 'family') form += select('value', opts(Object.fromEntries(Object.entries(fam).map(([k, v]) => [k, v[1]]))), a.value); }
        $('ls-editor').hidden = false; $('ls-editor').dataset.field = ''; $('ls-editor').innerHTML = `<strong>${editing ? '✎ Edit' : '✚ Add'} ${type}</strong><form id="ls-form">${form}<div class="ls-form-actions"><button type="submit">${editing ? 'Save Changes' : 'Add This Information'}</button><button type="button" data-ls-cancel>Cancel</button></div></form>`;
    }
    function syncNamePicker(form) {
        const relationship = form.querySelector('select[name="relationship"]');
        const name = form.querySelector('select[name="name"]');
        if (!relationship || !name) return;
        const gender = lex[relationship.value]?.[3];
        if (!gender) return;
        const selected = name.value;
        name.innerHTML = nameBank[gender].map(n => `<option value="${n}">${n}</option>`).join('');
        name.value = nameBank[gender].includes(selected) ? selected : nameBank[gender][0];
    }
    scene.addEventListener('click', e => { const w = e.target.closest('[data-ls-person]'); if (w) { editPhrase(w.dataset.lsPerson, w.dataset.lsField); return; } const add = e.target.closest('[data-ls-add]'); if (add) { openAdd(add.dataset.lsAdd); return; } const ed = e.target.closest('[data-ls-edit]'); if (ed) { const a = state.additions.find(x => x.id === ed.dataset.lsEdit); if (a) openAdd(a.type, a.id); return; } const rm = e.target.closest('[data-ls-remove]'); if (rm) { const a = state.additions.find(x => x.id === rm.dataset.lsRemove); if (a) { commit('Addition removed.', 'The entire expression was removed without leaving broken punctuation.'); state.additions = state.additions.filter(x => x.id !== a.id); render(); } return; } if (e.target.closest('[data-ls-cancel]')) { $('ls-editor').hidden = true; } });
    scene.addEventListener('change', e => { const form = e.target.closest('#ls-form'); if (form) { if (e.target.name === 'relationship') syncNamePicker(form); } });
    scene.addEventListener('submit', e => { if (e.target.id !== 'ls-form') return; e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); if (mode === 'phrase') { const id = $('ls-editor').dataset.person; const field = $('ls-editor').dataset.field; const p = getP(id); if (p) { const updates = Object.entries(d).map(([k, v]) => [k === 'relationship' ? 'rel' : k, k === 'count' ? Number(v) : v]); const changed = updates.filter(([k, v]) => String(p[k]) !== String(v)); if (changed.length) { commit('The sentence has changed.', 'Russian agreement adjusts to match the relationship, number and meaning you selected.'); changed.forEach(([k, v]) => p[k] = v); if (changed.some(([k]) => k === 'rel')) p.name = nameForRelationship(p.rel, p.name); } } } else if (mode === 'person') { commit('A new person was added.', 'The new family member becomes part of the Living Sentence and can be clicked and changed.'); state.people.push({ id: 'p' + (++seq + 2), owner: d.owner, rel: d.relationship, count: +d.count, name: nameForRelationship(d.relationship, d.name), descriptor: 'youngest', family: 'our' }); } else { if (editing) { const a = state.additions.find(x => x.id === editing); if (a) { commit('Addition updated.', 'The Russian expression has been reconstructed from your choices.'); Object.assign(a, d); } } else { commit('New information added.', 'Your sentence has grown. This addition can be edited or removed independently.'); state.additions.push({ id: 'a' + (++seq), type: mode, ...d }); } } $('ls-editor').hidden = true; render(); });
    $('ls-listen').addEventListener('click', () => { if (typeof speakRussian === 'function') speakRussian($('ls-russian').textContent); });
    $('ls-undo').addEventListener('click', () => { if (!history.length) return; state = history.pop(); $('ls-discovery').textContent = 'Last change undone. Your earlier choices have been preserved.'; $('ls-editor').hidden = true; render(); });
    $('ls-reset').addEventListener('click', () => { if (!history.length) return; state = initial(); history = []; $('ls-editor').hidden = true; $('ls-discovery').textContent = 'Starting sentence restored. All additions have been cleared.'; render(); }); render();
})();
// END LIVING SENTENCE


// BEGIN DRAWER TWO — SECRET INNER DRAWERS: ISOLATED INVESTIGATION LOGIC
(() => {
    const scene = document.getElementById('cc-scene'); if (!scene) return;
    const $ = id => scene.querySelector('#' + id);
    const investigations = {
        ending: { title: 'Why That Ending?', intro: 'The same person appears in both sentences. Why does the name look different?', sentences: [['Это <mark>Анна</mark>.', 'This is Anna.'], ['Иван старше <mark>Анны</mark>.', 'Ivan is older than Anna.']], question: 'What happened to Анна? Can you find the difference?', observation: 'Анна becomes Анны. The person stays the same.', prompt: 'Алексей старше ______.', options: ['Анна', 'Анну', 'Анны'], correct: 'Анны', from: 'Анна', to: 'Анны', labels: 'Nominative → Genitive · comparison reference', lens: { what: 'Анна changes to Анны. The ending -а becomes -ы; Anna herself has not changed.', why: 'In the comparison Иван старше Анны, Anna is the person used as the comparison reference. Russian can use the genitive case after a comparative such as старше.', how: 'For the name Анна, the nominative ending -а changes to genitive -ы. Other names can follow different patterns: Мария → Марии; Иван → Ивана.', when: 'This genitive comparison pattern is used without чем: Иван старше Анны. Another valid construction is Иван старше, чем Анна — with nominative after чем.', more: 'Мария выше Ивана. (Maria is taller than Ivan.)\nАлексей младше Марии. (Alexey is younger than Maria.)' } },
        mine: { title: 'My or Mine?', intro: 'English says “my” for every noun. Russian chooses a form that matches the noun.', sentences: [['Это <mark>мой</mark> брат.', 'This is my brother.'], ['Это <mark>моя</mark> сестра.', 'This is my sister.']], question: 'Why did мой become моя?', observation: 'The possessive word changes with the noun.', prompt: 'Это ______ имя. (This is my name.)', options: ['мой', 'моя', 'моё'], correct: 'моё', from: 'мой', to: 'моя', labels: 'Masculine → Feminine · possessive agreement', lens: { what: 'мой changes to моя when we switch from брат to сестра.', why: 'Russian possessives agree with the grammatical gender and number of the noun they describe. This is agreement, not necessarily a case change.', how: 'мой брат (masculine), моя сестра (feminine), моё имя (neuter), мои родители (plural).', when: 'Choose the form that matches the noun. These examples use nominative forms; other grammatical cases can change the possessive again.', more: 'Это моё имя. (This is my name.)\nЭто мои родители. (These are my parents.)' } },
        count: { title: 'One, Two, Five?', intro: 'Russian changes the noun form as the number changes.', sentences: [['У меня один <mark>брат</mark>.', 'I have one brother.'], ['У меня два <mark>брата</mark>.', 'I have two brothers.'], ['У меня пять <mark>братьев</mark>.', 'I have five brothers.']], question: 'Why are there three forms of “brother”?', observation: 'брат → брата → братьев as the number changes.', prompt: 'У меня три ______. (I have three brothers.)', options: ['брат', 'брата', 'братьев'], correct: 'брата', from: 'брат', to: 'братьев', labels: 'One → Five · counting changes noun form', lens: { what: 'After один: брат. After два: брата. After пять: братьев.', why: 'Russian numeral constructions select different noun forms. In basic counting, 2–4 typically use a genitive singular form; 5 and above typically use genitive plural.', how: 'один брат · два брата · пять братьев. These are patterns for the noun брат, not a universal ending for all nouns.', when: 'For simple counts, pay attention to the last digits and exceptions: 11–14 take the 5+ pattern. Other cases and constructions introduce additional rules.', more: 'одна сестра · две сестры · пять сестёр.\nодин человек · два человека · пять человек.' } },
        age: { title: 'How Old Are You?', intro: 'Russian expresses age with a different construction and different forms of “year.”', sentences: [['Мне один <mark>год</mark>.', 'I am one year old.'], ['Мне два <mark>года</mark>.', 'I am two years old.'], ['Мне пять <mark>лет</mark>.', 'I am five years old.']], question: 'Why does “year” change from год to года to лет?', observation: 'год → года → лет with different numbers.', prompt: 'Анне двадцать три ______. (Anna is 23.)', options: ['год', 'года', 'лет'], correct: 'года', from: 'год', to: 'лет', labels: 'One → Five · age and counting', lens: { what: 'год, года, and лет are used with different numbers in age expressions.', why: 'Russian expresses age as “to someone [there are] N years”: Мне двадцать лет. The number determines the form of “year.”', how: '1 год · 2, 3, 4 года · 5–20 лет. For 21: год; 22–24: года; 25: лет.', when: 'Look at the last two digits first: 11–14 use лет. Otherwise endings in 1 use год, 2–4 use года, and the rest use лет.', more: 'Мне двадцать один год. (I am 21.)\nЕй двадцать два года. (She is 22.)\nЕму двадцать пять лет. (He is 25.)' } }
    };

    const order = ['mine', 'count', 'ending', 'age'];
    const titles = { what: 'What Changed?', why: 'Why Did It Change?', how: 'How Does It Work?', when: 'When Does It Happen?', more: 'More Examples' };
    const state = Object.fromEntries(order.map(k => [k, { picked: null, checked: false, lens: 'what' }]));
    let active = 'ending', view = 'cabinet';
    const escape = s => String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
    function show(viewName) { view = viewName; scene.querySelectorAll('[data-cc-view]').forEach(el => { el.hidden = el.dataset.ccView !== viewName; }); }
    function feedback() { const s = state[active], d = investigations[active]; const el = $('cc-feedback'); if (!s.picked) { el.textContent = 'Choose a form, then check your prediction.'; el.dataset.result = ''; } else if (!s.checked) { el.textContent = 'Prediction selected. Ready to check?'; el.dataset.result = ''; } else if (s.picked === d.correct) { el.textContent = 'Excellent discovery! ' + d.correct + ' is correct. Open the Microscope to discover WHY.'; el.dataset.result = 'correct'; } else { el.textContent = 'Not quite yet. Look at the examples, then choose another form and try again.'; el.dataset.result = 'retry'; } }
    function showLens(key) { state[active].lens = key; const d = investigations[active]; $('cc-explanation-title').textContent = titles[key]; $('cc-explanation-text').textContent = d.lens[key]; scene.querySelectorAll('[data-cc-lens]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.ccLens === key))); }
    function render() {
        const d = investigations[active], s = state[active]; $('cc-case-counter').textContent = 'SECRET DRAWER ' + ['I', 'II', 'III', 'IV'][order.indexOf(active)]; $('cc-case-title').textContent = d.title; $('cc-case-intro').textContent = d.intro;
        $('cc-case-sentences').innerHTML = d.sentences.map(([ru, en]) => `<div class="cc-sentence"><div lang="ru">${ru.replace(/<mark>/g, '<span class="cc-mark">').replace(/<\/mark>/g, '</span>')}</div><em>${escape(en)}</em></div>`).join('');
        $('cc-case-question').textContent = d.question; $('cc-observation').textContent = d.observation; $('cc-prompt').textContent = d.prompt;
        $('cc-options').replaceChildren(); d.options.forEach(value => { const b = document.createElement('button'); b.type = 'button'; b.textContent = value; b.setAttribute('aria-pressed', String(s.picked === value)); b.addEventListener('click', () => { s.picked = value; s.checked = false; scene.querySelectorAll('#cc-options button').forEach(x => x.setAttribute('aria-pressed', String(x === b))); feedback(); }); $('cc-options').append(b); });
        $('cc-micro-title').textContent = d.title; $('cc-transform').innerHTML = `<span class="cc-from">${escape(d.from)}</span><span class="cc-arrow">⟶</span><span class="cc-to">${escape(d.to)}</span>`; $('cc-transform-label').textContent = d.labels; feedback(); showLens(s.lens);
    }
    scene.querySelectorAll('[data-cc-open]').forEach(b => b.addEventListener('click', () => { active = b.dataset.ccOpen; render(); show('investigation'); }));
    scene.querySelectorAll('[data-cc-nav]').forEach(b => b.addEventListener('click', () => { show(b.dataset.ccNav); if (b.dataset.ccNav === 'microscope') showLens(state[active].lens); }));
    scene.querySelectorAll('[data-cc-lens]').forEach(b => b.addEventListener('click', () => showLens(b.dataset.ccLens)));
    $('cc-check').addEventListener('click', () => { if (!state[active].picked) { feedback(); $('cc-feedback').textContent = 'Choose a Russian form first.'; return; } state[active].checked = true; feedback(); });
    $('cc-reset').addEventListener('click', () => { state[active].picked = null; state[active].checked = false; render(); });
    $('cc-listen').addEventListener('click', () => { const lines = investigations[active].sentences.map(([ru]) => ru.replace(/<\/?mark>/g, '')); if (typeof speakRussian === 'function') speakRussian(lines.join(' ')); });
    render(); show('cabinet');
})();
// END DRAWER TWO — SECRET INNER DRAWERS

// ============================================================
// BEGIN SCENARIO 01 — ANNA CONVERSATION LABORATORY (NO REGISTRY)
// Uses the complete original Anna dialogue and interaction code.
// Isolated inside the Foundation HTML's shadow root.
// ============================================================
function initAnnaScenario() {
    const annaHost = document.getElementById('anna-scenario-01');
    // Anna's HTML now lives directly in the Foundation document.
    const annaRoot = annaHost;
const anna = { name: 'Anna', voiceLanguage: 'ru-RU' };
const $ = id => annaRoot.querySelector(`[id="${id}"]`);
const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
let turn='opening', activeRecognition=null, practiceMode=false, activeDetail=null, audioToken=0;
const item=(ru,en,level,intent)=>({ru,en,level,intent});
const scenes={
 opening:{ru:'Ты любишь борщ?',en:'Do you like borscht?',answers:[item('Да, я люблю борщ.','Yes, I like borscht.','Simple','yes'),item('Да, очень люблю!','Yes, I like it very much!','Expanded','yes'),item('Обожаю борщ!','I love borscht!','Natural','yes'),item('Нет, я не люблю борщ.','No, I don’t like borscht.','Simple','no'),item('Нет, не очень.','No, not really.','Natural','no'),item('Я никогда не пробовал борщ.','I’ve never tried borscht. (male speaker)','Challenge','unknown'),item('А что такое борщ?','What is borscht?','Curious','what')],
  meaning:{title:'Ты любишь борщ?',summary:'Do you like borscht?',blocks:[['Ты','You — informal, for someone you know well.'],['любишь','You like / love — the ты form of любить.'],['борщ','Borscht, a beet-based soup.']]},
  discovery:{title:'How the verb changes',intro:'Russian verbs change depending on who is doing the action.',compare:[['Я люб<span class="ending">лю</span>','I like'],['Ты люб<span class="ending">ишь</span>','You like']],note:'The ending tells us who likes something. Listen for the change.',quiz:{prompt:'How would you say “I like”?',options:['Я люблю','Ты любишь'],correct:0}}},
 yes:{ru:'Замечательно! Хочешь ещё борща?',en:'Wonderful! Would you like some more borscht?',answers:[item('Да, хочу ещё.','Yes, I want more.','Simple','yes'),item('Да, я хочу ещё борща.','Yes, I want more borscht.','Expanded','yes'),item('Да, пожалуйста, дай мне ещё.','Yes, please, give me some more.','Natural','yes'),item('Можно немного борща?','May I have a little borscht?','Challenge','yes'),item('Нет, спасибо.','No, thank you.','Simple','no'),item('Нет, я больше не хочу.','No, I don’t want any more.','Expanded','no'),item('Спасибо, я уже сыт.','Thanks, I’m already full. (male speaker)','Natural','no'),item('Спасибо, я уже сыта.','Thanks, I’m already full. (female speaker)','Natural','no')],
  meaning:{title:'Хочешь ещё борща?',summary:'Would you like more borscht?',blocks:[['Хочешь','Do you want? Informal ты form of хотеть.'],['ещё','More / another serving, in this context.'],['борща','Of borscht — a genitive form of борщ, used with an unspecified amount.']]},
  discovery:{title:'A little more borscht',intro:'When we talk about an unspecified amount, Russian often uses the genitive.',compare:[['борщ','borscht'],['ещё борщ<span class="ending">а</span>','more borscht']],note:'The noun changes: борщ → борща. Also notice дай (informal) versus дайте (polite/plural).',quiz:{prompt:'Which means “more borscht”?',options:['ещё борщ','ещё борща'],correct:1}}},
 no:{ru:'Понятно. А что ты любишь?',en:'I see. And what do you like?',answers:[item('Я люблю пельмени.','I like pelmeni.','Simple','pelmeni'),item('Мне нравится суп.','I like soup.','Expanded','soup'),item('Я люблю пироги.','I like pies.','Expanded','pies'),item('Я люблю картошку.','I like potatoes.','Natural','potatoes'),item('Я предпочитаю салат.','I prefer salad.','Challenge','salad'),item('А что ты любишь?','And what do you like?','Curious','ask')],
  meaning:{title:'А что ты любишь?',summary:'And what do you like?',blocks:[['А','And / but — often shifts or contrasts the topic.'],['что','What.'],['ты любишь','You like — informal.']]},
  discovery:{title:'Two ways to say “I like”',intro:'Both are natural Russian, but they are built differently.',compare:[['Я люб<span class="ending">лю</span> суп.','I like soup.'],['Мне нрав<span class="ending">ится</span> суп.','I like soup.']],note:'Мне нравится literally follows a “pleases me” pattern. With a plural subject: Мне нравятся пельмени.',quiz:{prompt:'Which expression means “I like soup”?',options:['Мне нравится суп.','Мне нравятся суп.'],correct:0}}},
 unknown:{ru:'Тогда попробуй! Это очень вкусно.',en:'Then give it a try! It’s very tasty.',answers:[item('Хорошо, попробую.','Okay, I’ll try it.','Simple','yes'),item('Спасибо, попробую немного.','Thanks, I’ll try a little.','Expanded','yes'),item('Нет, спасибо.','No, thank you.','Simple','no')],
  meaning:{title:'Попробуй!',summary:'Give it a try!',blocks:[['попробуй','Try it! Informal singular imperative of попробовать.'],['вкусно','Tasty / delicious.']]},
  discovery:{title:'A friendly invitation',intro:'The imperative is not always a harsh command. It can be a warm invitation.',compare:[['Попробу<span class="ending">й</span>!','Try it! (informal)'],['Попробу<span class="ending">йте</span>!','Try it! (polite/plural)']],note:'The polite or plural form adds -те.',quiz:{prompt:'Which would you say to several guests?',options:['Попробуй!','Попробуйте!'],correct:1}}},
 what:{ru:'Борщ — это суп со свёклой. Хочешь попробовать?',en:'Borscht is a soup with beets. Would you like to try it?',answers:[item('Да, хочу попробовать.','Yes, I want to try it.','Simple','yes'),item('Да, пожалуйста.','Yes, please.','Simple','yes'),item('Нет, спасибо.','No, thank you.','Simple','no')],
  meaning:{title:'Что такое борщ?',summary:'What is borscht?',blocks:[['Что такое…?','What is …? A very useful question for unfamiliar words.'],['суп со свёклой','Soup with beets.'],['попробовать','To try / taste (perfective infinitive).']]},
  discovery:{title:'Ask about anything',intro:'Что такое…? is a powerful question when you encounter a new word.',compare:[['Что такое борщ?','What is borscht?'],['Что такое пельмени?','What are pelmeni?']],note:'Use this pattern to keep the conversation going even when you don’t know a word.',quiz:{prompt:'How do you ask “What is pelmeni?”',options:['Что такое пельмени?','Ты пельмени?'],correct:0}}},
 moreYes:{ru:'Конечно! Угощайся!',en:'Of course! Help yourself!',answers:[item('Спасибо!','Thank you!','Simple','thanks'),item('Большое спасибо!','Thank you very much!','Expanded','thanks'),item('С удовольствием!','With pleasure!','Natural','thanks'),item('Как вкусно!','How delicious!','Natural','thanks')],
  meaning:{title:'Угощайся!',summary:'Help yourself! / Have some!',blocks:[['угощайся','A friendly invitation to enjoy food or drink offered by a host.'],['угощаться','Imperfective reflexive infinitive: to help oneself / enjoy a treat.'],['угоститься','Related perfective infinitive.']]},
  discovery:{title:'An invitation, not an order',intro:'Russian changes the invitation depending on whom you address.',compare:[['Угоща<span class="ending">йся</span>!','One person, informal'],['Угоща<span class="ending">йтесь</span>!','Polite or several people']],note:'The informal imperative comes from угощаться. The polite/plural form is угощайтесь. The highlighted forms show the contrast.',quiz:{prompt:'You are welcoming several guests. Which fits?',options:['Угощайся!','Угощайтесь!'],correct:1}}},
 moreNo:{ru:'Хорошо! Если захочешь, скажи.',en:'All right! Let me know if you want some.',answers:[item('Спасибо!','Thank you!','Simple','thanks'),item('Хорошо, спасибо.','Okay, thank you.','Expanded','thanks'),item('Обязательно!','Certainly! / I will!','Natural','thanks')],
  meaning:{title:'Если захочешь, скажи.',summary:'If you want some, let me know.',blocks:[['если','If.'],['захочешь','You come to want / will want — perfective future of захотеть.'],['скажи','Tell me / say — informal imperative of сказать.']]},
  discovery:{title:'A gentle conditional',intro:'Anna leaves the invitation open.',compare:[['Хоч<span class="ending">ешь</span>?','Do you want?'],['За<span class="ending">хочешь</span> — скажи.','If you want to — tell me.']],note:'The prefix за- helps create the perfective verb захотеть. The meaning is not just a changed ending.',quiz:{prompt:'Which word means “if”?',options:['если','скажи'],correct:0}}},
 preference:{ru:'Как интересно! Спасибо, что поделился!',en:'How interesting! Thanks for sharing!',answers:[item('Пожалуйста!','You’re welcome!','Simple','thanks'),item('Спасибо!','Thank you!','Simple','thanks'),item('А ты что любишь?','And what do you like?','Curious','ask')],
  meaning:{title:'Спасибо, что поделился!',summary:'Thanks for sharing!',blocks:[['спасибо, что…','Thank you for … / Thanks that …'],['поделился','Shared — masculine past-tense form.'],['поделилась','Shared — feminine past-tense form.']]},
  discovery:{title:'Past tense can change',intro:'Russian past-tense verbs can reflect the gender of the person being described.',compare:[['подели<span class="ending">лся</span>','Masculine'],['подели<span class="ending">лась</span>','Feminine']],note:'Anna’s prototype currently uses one fixed form. Later we can make it adapt to the learner.',quiz:{prompt:'Which form is feminine?',options:['поделился','поделилась'],correct:1}}},
 closing:{ru:'Спасибо за разговор! До скорого!',en:'Thanks for the conversation! See you soon!',answers:[],
  meaning:{title:'До скорого!',summary:'See you soon!',blocks:[['до','Until / up to. Here: “until.”'],['скорого','Genitive singular form of the adjective скорый — soon / near / forthcoming.'],['скоро','The separate adverb “soon.” It is NOT the word form used in this farewell.']]},
  discovery:{title:'Why скорого?',intro:'До скорого! is a shortened farewell, traditionally understood as До скорого свидания! (“Until we meet again soon”).',compare:[['скор<span class="ending">ый</span>','Basic masculine adjective'],['скор<span class="ending">ого</span>','Genitive adjective after до']],note:'До takes the genitive case. Скорого agrees with the understood noun свидания (also genitive). The everyday expression is simply До скорого! Compare До завтра! and До встречи!',quiz:{prompt:'Which is the natural farewell?',options:['До скоро!','До скорого!'],correct:1}}}
};
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderStage(){
 const s=scenes[turn],d=s.discovery;
 if(turn==='closing'){
  $('visual-stage').innerHTML=`<div class="stage-head">Until next time</div><div class="stage-word" lang="ru">До скор<span class="ending">ого</span>!</div><div class="stage-sub">See you soon!</div><div class="stage-tiles"><div class="stage-box"><small>UNTIL</small><strong lang="ru">до</strong></div><div class="stage-box"><small>FROM СКОРЫЙ</small><strong lang="ru">скор<span class="ending">ого</span></strong></div></div><div class="stage-note">Select Language Discovery to see why the ending changes.</div>`;
 }else if(turn==='moreYes'){
  $('visual-stage').innerHTML=`<div class="stage-head">At Anna’s table</div><div class="stage-word" lang="ru">Угощайся!</div><div class="stage-sub">Help yourself!</div><div class="stage-tiles"><div class="stage-box"><small>FAMILIAR</small><strong lang="ru">Угоща<span class="ending">йся</span>!</strong></div><div class="stage-box"><small>POLITE / PLURAL</small><strong lang="ru">Угоща<span class="ending">йтесь</span>!</strong></div></div>`;
 }else if(turn==='yes'){
  $('visual-stage').innerHTML=`<div class="stage-head">A second helping?</div><div class="stage-word" lang="ru">ещё борщ<span class="ending">а</span></div><div class="stage-sub">more borscht</div><div class="stage-tiles"><div class="stage-box"><small>THE FOOD</small><strong lang="ru">борщ</strong></div><div class="stage-box"><small>MORE OF IT</small><strong lang="ru">борщ<span class="ending">а</span></strong></div></div>`;
 }else{
  const cards=d.compare.map(([ru,en])=>`<div class="stage-box"><small>${escapeHtml(en)}</small><strong lang="ru">${ru}</strong></div>`).join('');
  $('visual-stage').innerHTML=`<div class="stage-head">Russian in focus</div><div class="stage-word" lang="ru">${escapeHtml(s.ru)}</div><div class="stage-tiles">${cards}</div>`;
 }
}
function renderDetail(mode){
 const s=scenes[turn], d=s[mode], host=$('discovery-detail');
 if(mode==='meaning'){
  host.innerHTML=`<h4>${escapeHtml(d.title)}</h4><p class="stage-sub">${escapeHtml(d.summary)}</p>${d.blocks.map(([ru,en])=>`<div class="example"><div class="ru" lang="ru">${escapeHtml(ru)}</div><div class="en">${escapeHtml(en)}</div></div>`).join('')}`;
 }else{
  host.innerHTML=`<h4>${escapeHtml(d.title)}</h4><p>${escapeHtml(d.intro)}</p><div class="stage-tiles">${d.compare.map(([ru,en])=>`<div class="stage-box"><small>${escapeHtml(en)}</small><strong lang="ru">${ru}</strong></div>`).join('')}</div><p class="rule">${escapeHtml(d.note)}</p><div class="anna-recall-row"><div class="anna-recall-prompt"><h5>See what you remember</h5><p>${escapeHtml(d.quiz.prompt)}</p></div><div class="practice-choices">${d.quiz.options.map((v,i)=>`<button type="button" data-quiz="${i}" lang="ru">${escapeHtml(v)}</button>`).join('')}</div></div><div class="practice-feedback" id="quiz-feedback" role="status"></div>`;
  host.querySelectorAll('[data-quiz]').forEach(btn=>btn.addEventListener('click',()=>{host.querySelectorAll('[data-quiz]').forEach(b=>b.classList.remove('selected'));btn.classList.add('selected');$('quiz-feedback').textContent=Number(btn.dataset.quiz)===d.quiz.correct?'Exactly! You spotted the pattern.':'Try the other form. Look at the highlighted change.';}));
 }
 host.hidden=false;
}
function toggleDetail(mode){if(activeDetail===mode){activeDetail=null;$('discovery-detail').hidden=true;}else{activeDetail=mode;renderDetail(mode);}updateButtons();}
function updateButtons(){for(const [id,mode] of [['show-meaning','meaning'],['show-discovery','discovery']])$(id).setAttribute('aria-expanded',String(activeDetail===mode));}
function renderAnswers(){const host=$('answers-panel'),s=scenes[turn];host.replaceChildren();for(const a of s.answers){const el=document.createElement('div');el.className='answer-item';const copy=document.createElement('div');copy.className='answer-copy';const ru=document.createElement('div');ru.className='answer-ru';ru.lang='ru';ru.textContent=a.ru;const en=document.createElement('div');en.className='answer-en';en.textContent=a.en;copy.append(ru,en);const level=document.createElement('div');level.className='answer-level';level.textContent=a.level;el.append(copy,level);host.append(el);}if(!s.answers.length)host.textContent='До скорого!';}
function setLine(key){turn=key;const s=scenes[key];$('russian').textContent=s.ru;$('translation').textContent=s.en;activeDetail=null;$('discovery-detail').hidden=true;updateButtons();$('answers-panel').hidden=true;$('show-answers').setAttribute('aria-expanded','false');renderAnswers();renderStage();$('practice-status').textContent='';$('answer').disabled=key==='closing';$('send').disabled=key==='closing';$('typed').disabled=key==='closing';}
function status(msg){$('feedback').textContent=msg;}
function speaking(on){$('light').classList.toggle('active',on);$('avatar-state').textContent=on?'Anna is speaking…':'Anna is ready';}
function speak(){if(!('speechSynthesis' in window)){status('Speech playback is unavailable in this browser.');return;}const token=++audioToken;window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(scenes[turn].ru);utterance.lang=anna.voiceLanguage||'ru-RU';utterance.rate=.86;const voice=window.speechSynthesis.getVoices().find(v=>v.lang.toLowerCase().startsWith('ru'));if(voice)utterance.voice=voice;else status('No Russian voice found. Install a Russian voice for accurate pronunciation.');utterance.onstart=()=>{if(token===audioToken)speaking(true)};utterance.onend=()=>{if(token===audioToken)speaking(false)};utterance.onerror=()=>{if(token===audioToken){speaking(false);status('Speech playback failed.')}};window.speechSynthesis.speak(utterance);}
function normalize(raw){return raw.toLocaleLowerCase('ru-RU').replace(/ё/g,'е').replace(/[.,!?;:«»]/g,' ').replace(/\s+/g,' ').trim();}
function detect(raw){const t=normalize(raw);if(!t)return null;
 if(turn==='opening'){
  if(/что такое|что это|что за/.test(t))return 'what';
  if(/никогда не проб|не пробовал|не пробовала/.test(t))return 'unknown';
  if(/\bнет\b|не люблю|не очень|не нравится|не хочу/.test(t))return 'no';
  if(/\bда\b|люблю|обожаю|нравится|очень/.test(t))return 'yes';return null;
 }
 if(turn==='yes'||turn==='what'||turn==='unknown'){
  if(/\bнет\b|не хочу|не надо|не нужно|не буду|не очень|сыт|сыта|больше не/.test(t))return 'no';
  if(/\bда\b|хочу|дай|дайте|можно|пожалуйста|попробую|конечно|немного/.test(t))return 'yes';return null;
 }
 if(turn==='no'){
  if(/а ты|а что ты/.test(t))return 'ask';
  if(/пельмен/.test(t))return 'pelmeni';if(/суп/.test(t))return 'soup';if(/пирог/.test(t))return 'pies';if(/картош/.test(t))return 'potatoes';if(/салат/.test(t))return 'salad';
  if(/люблю|нравится|предпочитаю/.test(t))return 'other';return null;
 }
 if(turn==='preference'&&/а ты|что ты любишь/.test(t))return 'ask';
 if(['moreYes','moreNo','preference'].includes(turn)&&/спасибо|пожалуйста|удовольствием|вкусно|обязательно|хорошо/.test(t))return 'thanks';
 return null;
}
function respond(raw){$('transcript').textContent=raw;
 if(practiceMode){practiceMode=false;$('practice-status').textContent=`I heard: ${raw}. Compare with Anna’s words; recognition is not a pronunciation score.`;status('');return;}
 const intent=detect(raw);if(!intent){status('Anna did not recognize that answer yet. Try another wording or see Possible Answers.');return;}
 let next;
 if(turn==='opening')next=intent==='yes'?'yes':intent==='no'?'no':intent;
 else if(['yes','what','unknown'].includes(turn))next=intent==='yes'?'moreYes':'moreNo';
 else if(turn==='no')next='preference';
 else if(['moreYes','moreNo','preference'].includes(turn))next='closing';
 if(!next)return;
 setLine(next);$('typed').value='';status(next==='closing'?'Conversation complete.':'');speak();
}
function listen(practice=false){if(!SpeechRecognition){status('Microphone recognition unavailable. You can type your response.');return;}window.speechSynthesis?.cancel();++audioToken;speaking(false);activeRecognition?.abort();practiceMode=practice;const rec=new SpeechRecognition();activeRecognition=rec;rec.lang='ru-RU';rec.interimResults=false;rec.maxAlternatives=1;rec.onstart=()=>{status(practice?'Listening to your repetition…':'Listening…');$('answer').disabled=true;};rec.onresult=e=>respond(e.results[0][0].transcript);rec.onerror=e=>{practiceMode=false;status(`Microphone: ${e.error}. You can type instead.`)};rec.onend=()=>{$('answer').disabled=turn==='closing';if(activeRecognition===rec)activeRecognition=null;};try{rec.start()}catch{practiceMode=false;status('Could not start the microphone.');$('answer').disabled=false;}}
function reset(){activeRecognition?.abort();activeRecognition=null;practiceMode=false;++audioToken;window.speechSynthesis?.cancel();speaking(false);setLine('opening');$('transcript').textContent='';$('typed').value='';status('');}
$('hear').addEventListener('click',speak);$('hear-again').addEventListener('click',speak);$('answer').addEventListener('click',()=>listen(false));$('practice-phrase').addEventListener('click',()=>listen(true));$('repeat').addEventListener('click',reset);$('show-meaning').addEventListener('click',()=>toggleDetail('meaning'));$('show-discovery').addEventListener('click',()=>toggleDetail('discovery'));$('show-answers').addEventListener('click',()=>{const show=$('answers-panel').hidden;$('answers-panel').hidden=!show;$('show-answers').setAttribute('aria-expanded',String(show));});$('send').addEventListener('click',()=>{const value=$('typed').value.trim();if(value){practiceMode=false;respond(value);}else status('Type a Russian response.');});$('typed').addEventListener('keydown',e=>{if(e.key==='Enter')$('send').click()});reset();

    $('anna-back-gallery').addEventListener('click', closeAnnaScenario);
    // Reuse the Gallery's existing return-to-desk behavior.
    $('anna-back-desk').addEventListener('click', () => {
        closeAnnaScenario();
        document.getElementById('rw-conversations-back')?.click();
    });
}
function openAnnaScenario() {
    const host = document.getElementById('anna-scenario-01');
    host.hidden = false;
    document.body.style.overflow = 'hidden';
}
function closeAnnaScenario() {
    const host = document.getElementById('anna-scenario-01');
    host.hidden = true;
    document.body.style.overflow = '';
    window.speechSynthesis?.cancel();
}
initAnnaScenario();
// END SCENARIO 01 — ANNA CONVERSATION LABORATORY
